package com.example.catpet

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.Drawable

/** Фон с «срезанными» углами в стиле киберпанк: заливка, тонкая рамка и оранжевый уголок-акцент. */
class CyberBg(private val fill: Int, private val stroke: Int, private val cut: Float,
              private val strokeW: Float, private val accent: Boolean, private val fill2: Int = 0) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        val k = minOf(cut, w / 3f, h / 3f)
        path.reset()
        path.moveTo(bounds.left + k, bounds.top.toFloat())
        path.lineTo(bounds.left + w, bounds.top.toFloat())
        path.lineTo(bounds.left + w, bounds.top + h - k)
        path.lineTo(bounds.left + w - k, bounds.top + h)
        path.lineTo(bounds.left.toFloat(), bounds.top + h)
        path.lineTo(bounds.left.toFloat(), bounds.top + k)
        path.close()
        p.style = Paint.Style.FILL
        p.color = fill
        if (fill2 != 0) p.shader = LinearGradient(bounds.left.toFloat(), 0f, bounds.left + w, 0f, fill, fill2, Shader.TileMode.CLAMP)
        c.drawPath(path, p)
        p.shader = null
        if (stroke != 0) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = strokeW
            p.color = stroke
            c.drawPath(path, p)
        }
        if (accent) {
            p.style = Paint.Style.STROKE
            p.strokeWidth = strokeW * 2.2f
            p.strokeCap = Paint.Cap.SQUARE
            p.color = Color.parseColor("#FF5A1F")
            val a = path
            val l = k * 1.6f
            val x = bounds.left.toFloat()
            val y = bounds.top.toFloat()
            c.drawLine(x + k, y, x + k + l, y, p)
            c.drawLine(x, y + k, x, y + k + l, p)
            c.drawLine(x + k, y, x, y + k, p)
        }
    }

    override fun setAlpha(alpha: Int) { p.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { p.colorFilter = cf }
    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}

/** Фон экрана: почти чёрный, тонкая сетка и тёплое оранжевое свечение сверху. */
class GridBg(private val d: Float) : Drawable() {
    private val bg = Paint()
    private val line = Paint()
    private val glow = Paint()

    init {
        bg.color = Color.parseColor("#05060A")
        line.color = Color.parseColor("#0E1220")
        line.strokeWidth = 1f
    }

    override fun draw(c: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        c.drawRect(0f, 0f, w, h, bg)
        val step = 36f * d
        var x = 0f
        while (x < w) { c.drawLine(x, 0f, x, h, line); x += step }
        var y = 0f
        while (y < h) { c.drawLine(0f, y, w, y, line); y += step }
        glow.shader = RadialGradient(w * 0.2f, 0f, w * 0.9f, Color.parseColor("#33FF5A1F"), Color.TRANSPARENT, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h * 0.6f, glow)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
