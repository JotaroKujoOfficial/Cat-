package com.example.catpet

enum class Anim { HOP, WIGGLE, STRETCH, SQUISH, SPIN_EYES, TILT, SHAKE, PURR, STARTLE, BOUNCE, WAVE_EARS, FLOP }

object Ev {
    const val CLICK = 0
    const val SCROLL = 1
    const val TEXT = 2
    const val WINDOW = 3
    const val NOTIF = 4
    const val DRAG = 5
    const val LAND = 6
    const val REAPPEAR = 7
    const val SLEEP = 8
    const val WAKE = 9
    const val PEEK = 10
    const val WALK = 11
    const val POKE = 12
    const val TRICK = 13
}

class Reaction(val mood: Int, val anim: Anim, val phrase: String)

/** Реакции собираются из сочетаний: настроение × анимация × фраза. Выходят тысячи вариантов. */
object Reactions {
    private val openers = listOf("Мяу", "Мрр", "Ого", "Хм", "Ой", "Ага", "Ух ты", "Мур", "Фыр", "Пф", "Ну надо же", "Так-так")
    private val suffix = listOf("", "", "", "!", " ♪", " ✦")

    private val endings: List<List<String>> = listOf(
        listOf("тыкнули!", "что там нажали?", "я всё видел", "кнопка — огонь", "щёлк — и готово", "ещё разок?", "палец засёк", "красота"),
        listOf("лента поехала", "вжух!", "куда так быстро?", "голова кругом", "листаем-листаем", "держусь лапками", "страница убегает", "это марафон"),
        listOf("кто-то пишет", "печатаешь — я слежу", "тук-тук-тук", "буквы побежали", "только без ошибок", "секретный текст?", "пальцы в танце", "ох уж эти клавиши"),
        listOf("новое окно!", "переехали", "что тут у нас?", "осматриваюсь", "другое приложение", "смена декораций", "интересно, интересно", "я тут новенький"),
        listOf("кто-то звонит в дверь", "пришла весточка", "дзынь!", "уведомление!", "почта прилетела", "проверим?", "вот это новости", "кого там принесло"),
        listOf("поехали!", "держите меня!", "уииии", "я лечу", "осторожно, уши!", "вжжж", "меня несут", "ой-ой-ой"),
        listOf("приземлился", "мягкая посадка", "ап!", "и снова на лапах", "бум", "я в порядке", "фух", "ровно встал"),
        listOf("я вернулся сверху!", "сюрприз с неба", "тук-тук, я из потолка", "падаю заново", "вынырнул", "не ждали?", "опять я", "через портал"),
        listOf("z-z-z", "засыпаю…", "пять минуточек", "мр-р-р", "сплю-сплю", "снится рыба", "хр-р-р", "не будить"),
        listOf("я не спал!", "что? где? кто?", "доброе утро", "уже вернулись?", "потягушки", "я бодрый", "кто тут?", "о, привет"),
        listOf("одним глазком", "просто смотрю", "ничего не вижу…", "заглянул", "я тихонечко", "кто тут что делает?", "записал в книжечку", "всё под контролем"),
        listOf("прогулка", "ищу, где посидеть", "иду-иду", "цок-цок", "патрулирую", "красота вокруг", "мимо кнопок", "тут уютно"),
        listOf("не щекотай", "мрр, приятно", "это я!", "что-что?", "слушаю", "чем помочь?", "я весь внимание", "тык-тык"),
        listOf("смотри, как могу", "ап-ап!", "фокус-покус", "тадам!", "а вот так?", "я артист", "аплодисменты", "ещё не всё")
    )

    private val moodsFor: List<List<Int>> = listOf(
        listOf(1, 1, 0, 4), listOf(2, 0, 4), listOf(0, 1, 4), listOf(2, 2, 4), listOf(2, 2, 1),
        listOf(2, 1, 1), listOf(0, 1, 2), listOf(2, 2, 1), listOf(3), listOf(2, 2, 1),
        listOf(4, 2, 0), listOf(0, 1), listOf(1, 1, 2), listOf(1, 4, 2)
    )

    private val animsFor: List<List<Anim>> = listOf(
        listOf(Anim.BOUNCE, Anim.WIGGLE, Anim.TILT, Anim.PURR, Anim.SQUISH),
        listOf(Anim.SPIN_EYES, Anim.WIGGLE, Anim.HOP, Anim.SHAKE),
        listOf(Anim.PURR, Anim.WAVE_EARS, Anim.TILT, Anim.SPIN_EYES),
        listOf(Anim.STARTLE, Anim.STRETCH, Anim.HOP, Anim.TILT),
        listOf(Anim.STARTLE, Anim.HOP, Anim.WAVE_EARS, Anim.SHAKE),
        listOf(Anim.SHAKE, Anim.WIGGLE, Anim.FLOP),
        listOf(Anim.SQUISH, Anim.BOUNCE, Anim.FLOP),
        listOf(Anim.STARTLE, Anim.STRETCH, Anim.SPIN_EYES),
        listOf(Anim.PURR, Anim.STRETCH),
        listOf(Anim.STARTLE, Anim.STRETCH, Anim.WAVE_EARS),
        listOf(Anim.SPIN_EYES, Anim.TILT),
        listOf(Anim.WIGGLE, Anim.HOP, Anim.WAVE_EARS),
        listOf(Anim.SQUISH, Anim.BOUNCE, Anim.WIGGLE),
        Anim.values().toList()
    )

    private val jokes = listOf(
        "Почему кот не играет в карты? Боится, что вытащат хвост.",
        "Я не ленивый. Я в режиме энергосбережения.",
        "Кот сказал: «Мяу». Весь интернет понял.",
        "Если что-то лежит на краю стола, это просьба его уронить.",
        "Мой любимый спорт: смотреть на курсор.",
        "Я не толстый. Я просто пушистый изнутри.",
        "Запускаю режим «мур». Загрузка… 100%.",
        "Спросите меня про рыбу. Я эксперт."
    )

    fun pick(ev: Int): Reaction {
        val e = ev.coerceIn(0, endings.size - 1)
        val end = endings[e].random()
        val phrase = if (e == Ev.SLEEP) end else openers.random() + ", " + end + suffix.random()
        return Reaction(moodsFor[e].random(), animsFor[e].random(), phrase)
    }

    fun joke(): String = jokes.random()

    /** Ответы без ИИ-ключа. */
    fun chat(t: String): String {
        val s = t.lowercase()
        val pool = when {
            s.contains("привет") || s.contains("здравств") || s.contains("хай") -> listOf("Мяу! Привет!", "Мрр, привет-привет!", "О, ты пришёл! Я рад.")
            s.contains("как дела") || s.contains("как ты") -> listOf("Отлично, гуляю по экрану!", "Мрр, всё прекрасно. А у тебя?", "Живу как кот: тепло и красиво.")
            s.contains("спасибо") -> listOf("Мур, пожалуйста!", "Всегда рад помочь лапкой.", "Не за что, мяу!")
            s.contains("пока") || s.contains("споко") -> listOf("Пока-пока, я тут посижу.", "Мрр, до встречи!", "Ложусь спать, зови если что.")
            s.contains("как тебя зовут") || s.contains("твоё имя") || s.contains("твое имя") -> listOf("Я Кики!", "Меня зовут Кики, а тебя?")
            s.contains("шутк") || s.contains("анекдот") -> listOf(joke())
            s.trim().endsWith("?") -> listOf(
                "Хороший вопрос! Без ИИ-ключа я знаю мало, но могу подумать лапкой.",
                "Мрр… Подключи ИИ в настройках, и я отвечу умнее.",
                "Не уверен, но очень хочу узнать!"
            )
            else -> listOf("Мяу.", "Мрр, продолжай.", "Я слушаю хвостом.", "Интересно! Расскажи ещё.")
        }
        return pool.random()
    }
}
