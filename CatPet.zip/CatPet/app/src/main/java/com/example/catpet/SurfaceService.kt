package com.example.catpet

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Build
import android.view.Display
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/** Поверхности, по которым ходит Кики: верхние грани кнопок, текста, картинок, окон и клавиатуры. */
object Surfaces {
    @Volatile var rects: List<Rect> = emptyList()
}

class SurfaceService : AccessibilityService() {
    companion object {
        @Volatile var instance: SurfaceService? = null
        @Volatile var lastPkg: String = ""
    }

    private var last = 0L

    override fun onServiceConnected() {
        instance = this
        Prefs.putB(this, "a11y_seen", true)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        Surfaces.rects = emptyList()
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        try { handleEvent(e) } catch (t: Throwable) {}
    }

    private fun handleEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: ""
        if (pkg == packageName) return
        if (pkg.isNotEmpty() && e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) lastPkg = pkg
        val r = Rect()
        try { e.source?.getBoundsInScreen(r) } catch (_: Exception) {}
        val cat = CatService.instance
        cat?.onEvent(e.eventType, r, pkg)
        if (cat == null || !cat.wantsSurfaces()) return
        val gap = if (e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) 1500L else 500L
        val now = SystemClock.uptimeMillis()
        if (now - last < gap) return
        last = now
        scanSurfaces()
    }

    /** Сканирует экран по таймеру: без этого на неподвижном экране Кики ничего не видел, потому что не было событий. */
    fun rescan() {
        try { scanSurfaces() } catch (t: Throwable) {}
    }

    private fun scanSurfaces() {
        val out = ArrayList<Rect>()
        val dm = resources.displayMetrics
        val minW = (40 * dm.density).toInt()
        val minH = (20 * dm.density).toInt()
        val topLimit = (80 * dm.density).toInt()
        val maxH = (dm.heightPixels * 0.9f).toInt()
        try {
            val ws = windows
            if (ws != null && ws.isNotEmpty()) {
                for (w in ws) {
                    val t = w.type
                    if (t != AccessibilityWindowInfo.TYPE_APPLICATION && t != AccessibilityWindowInfo.TYPE_INPUT_METHOD) continue
                    val b = Rect()
                    w.getBoundsInScreen(b)
                    val root = w.root
                    if (root != null && root.packageName?.toString() == packageName) continue
                    if (t == AccessibilityWindowInfo.TYPE_INPUT_METHOD) { out.add(b); continue }
                    if (b.top > topLimit && b.height() < maxH) out.add(b)
                    if (root != null) collect(root, out, 0, minW, minH)
                }
            } else {
                val root = rootInActiveWindow
                if (root != null) collect(root, out, 0, minW, minH)
            }
        } catch (_: Exception) {}
        Surfaces.rects = out
    }

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<Rect>, depth: Int, minW: Int, minH: Int) {
        if (depth > 25 || out.size > 220) return
        if (!n.isVisibleToUser) return
        val b = Rect()
        n.getBoundsInScreen(b)
        val cls = n.className?.toString() ?: ""
        val solid = n.isClickable || !n.text.isNullOrEmpty() || !n.contentDescription.isNullOrEmpty() ||
            cls.contains("Image") || cls.contains("Button") || cls.contains("Switch") || cls.contains("Edit") || cls.contains("Tab")
        if (solid && b.width() >= minW && b.height() >= minH) out.add(b)
        for (i in 0 until n.childCount) {
            val ch = n.getChild(i) ?: continue
            collect(ch, out, depth + 1, minW, minH)
        }
    }

    /** Текст экрана для ИИ и дневника. Поля паролей и исключённые приложения пропускаются. */
    /** Снимок экрана без записи экрана (Android 11+). Результат приходит в главном потоке; null, если снимок недоступен. */
    fun shot(cb: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null); return }
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val hb = result.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                        cb(bmp)
                    } catch (e: Throwable) { cb(null) }
                }
                override fun onFailure(errorCode: Int) { cb(null) }
            })
        } catch (e: Throwable) { cb(null) }
    }

    private fun inRegion(n: AccessibilityNodeInfo, r: Rect): Boolean {
        val b = Rect()
        n.getBoundsInScreen(b)
        return r.contains(b.centerX(), b.centerY())
    }

    /** Текст экрана. С region: только то, что попало в выделенную область. */
    fun screenText(region: Rect? = null): String? {
        if (!Prefs.b(this, "screen_read")) return null
        val excl = Prefs.s(this, "exclude_pkgs").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        val sb = StringBuilder()
        var count = 0

        fun walk(n: AccessibilityNodeInfo, d: Int) {
            if (d > 25 || count > 1500 || sb.length > 6000) return
            if (!n.isVisibleToUser) return
            count++
            if (!n.isPassword) {
                val t = n.text?.toString() ?: n.contentDescription?.toString()
                if (!t.isNullOrBlank() && (region == null || inRegion(n, region))) sb.append(t.trim()).append('\n')
            }
            for (i in 0 until n.childCount) {
                val ch = n.getChild(i) ?: continue
                walk(ch, d + 1)
            }
        }

        try {
            val roots = ArrayList<AccessibilityNodeInfo>()
            val ws = windows
            if (ws != null) {
                for (w in ws) {
                    if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION) {
                        val r = w.root
                        if (r != null) roots.add(r)
                    }
                }
            }
            if (roots.isEmpty()) {
                val r = rootInActiveWindow
                if (r != null) roots.add(r)
            }
            for (r in roots) {
                val p = r.packageName?.toString() ?: ""
                if (p == packageName || excl.contains(p)) continue
                walk(r, 0)
            }
        } catch (_: Exception) {}
        val s = sb.toString().trim()
        return if (s.isEmpty()) null else s
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        Surfaces.rects = emptyList()
        super.onDestroy()
    }
}
