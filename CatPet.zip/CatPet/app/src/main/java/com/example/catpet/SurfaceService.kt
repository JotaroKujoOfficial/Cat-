package com.example.catpet

import android.accessibilityservice.AccessibilityService
import android.graphics.Rect
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Поверхности, по которым ходит котик: верхние грани кнопок, карточек и текста на экране. */
object Surfaces {
    @Volatile var rects: List<Rect> = emptyList()
}

class SurfaceService : AccessibilityService() {
    private var last = 0L

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val r = Rect()
        e.source?.getBoundsInScreen(r)
        CatService.instance?.onEvent(e.eventType, r)

        val now = SystemClock.uptimeMillis()
        if (now - last < 400) return
        last = now
        val root = rootInActiveWindow ?: return
        val out = ArrayList<Rect>()
        collect(root, out, 0)
        Surfaces.rects = out
    }

    private fun collect(n: AccessibilityNodeInfo, out: MutableList<Rect>, depth: Int) {
        if (depth > 12 || out.size > 150) return
        val b = Rect()
        n.getBoundsInScreen(b)
        val solid = n.isClickable || !n.text.isNullOrEmpty()
        if (n.isVisibleToUser && solid && b.width() > 200 && b.height() in 60..1500) out.add(b)
        for (i in 0 until n.childCount) n.getChild(i)?.let { collect(it, out, depth + 1) }
    }

    override fun onInterrupt() {}
    override fun onDestroy() { Surfaces.rects = emptyList(); super.onDestroy() }
}
