package com.example.catpet

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.*
import android.util.DisplayMetrics
import android.view.*
import android.view.accessibility.AccessibilityEvent
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.random.Random

/** Оверлей с котиком поверх всех приложений: физика, прогулки по поверхностям, реакции, перетаскивание. */
class CatService : Service() {
    companion object { @Volatile var instance: CatService? = null }

    private lateinit var wm: WindowManager
    private lateinit var cat: CatView
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    private var size = 0
    private var screenW = 0
    private var screenH = 0
    private var x = 0f
    private var y = 0f
    private var vx = 0f
    private var vy = 0f
    private var dir = 1
    private var dragging = false
    private var actionAt = 0L
    private var moodUntil = 0L
    private var lookUntil = 0L
    private var lookTx = 0f
    private var lookTy = 0f

    private val loop = object : Runnable {
        override fun run() { tick(); handler.postDelayed(this, 16) }
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startForegroundCompat()
        if (instance == null) create()
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cat", "Котик", NotificationManager.IMPORTANCE_MIN))
        val n = Notification.Builder(this, "cat")
            .setContentTitle("Котик с тобой")
            .setSmallIcon(android.R.drawable.ic_dialog_info).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun create() {
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            screenW = b.width(); screenH = b.height()
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            screenW = m.widthPixels; screenH = m.heightPixels
        }
        size = dp(110f).toInt()
        x = screenW / 2f - size / 2f
        y = dp(120f)

        cat = CatView(this)
        lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(cat, lp)
        setupTouch()
        handler.post(loop)
    }

    private fun setupTouch() {
        var offX = 0f; var offY = 0f; var downX = 0f; var downY = 0f
        var downT = 0L; var moved = false
        cat.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = true; moved = false; downT = SystemClock.uptimeMillis()
                    downX = e.rawX; downY = e.rawY; offX = e.rawX - x; offY = e.rawY - y
                    cat.poke(-0.8f)
                }
                MotionEvent.ACTION_MOVE -> {
                    x = e.rawX - offX; y = e.rawY - offY
                    if (hypot(e.rawX - downX, e.rawY - downY) > dp(10f)) moved = true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false
                    val now = SystemClock.uptimeMillis()
                    if (!moved && now - downT < 300) {
                        startActivity(Intent(this, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    } else {
                        cat.mood = 1; moodUntil = now + 1200; cat.poke(0.8f)
                    }
                }
            }
            true
        }
    }

    /** Реакции на действия пользователя из службы спец. возможностей. */
    fun onEvent(type: Int, r: Rect) {
        if (instance == null) return
        val now = SystemClock.uptimeMillis()
        val onGround = vy == 0f
        when (type) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                look(r, now); cat.mood = 1; moodUntil = now + 1200; cat.poke(0.6f)
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> { look(r, now); cat.poke(0.3f) }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                cat.mood = 2; moodUntil = now + 800
                if (onGround && !dragging) vy = -dp(6f)
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                cat.mood = 2; moodUntil = now + 1000; cat.poke(-0.6f)
            }
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> {
                cat.mood = 2; moodUntil = now + 1500
                if (onGround && !dragging) vy = -dp(11f)
            }
        }
    }

    private fun look(r: Rect, now: Long) {
        if (r.isEmpty) return
        lookTx = r.exactCenterX(); lookTy = r.exactCenterY(); lookUntil = now + 1500
    }

    private fun chooseAction(now: Long) {
        val sp = dp(1.6f)
        val r = Random.nextInt(100)
        when {
            r < 50 -> { vx = dir * sp; actionAt = now + Random.nextLong(1500, 4000) }
            r < 70 -> { vx = 0f; actionAt = now + Random.nextLong(1200, 3000); cat.mood = 1; moodUntil = actionAt }
            r < 85 -> { vy = -dp(11f); vx = dir * sp; actionAt = now + 1500 }
            else -> { dir = -dir; vx = dir * sp; actionAt = now + 1000 }
        }
    }

    private fun tick() {
        val now = SystemClock.uptimeMillis()
        val s = size.toFloat()
        val floor = Rect(-5000, screenH - dp(56f).toInt(), screenW + 5000, screenH)
        val all = Surfaces.rects + floor

        if (dragging) {
            cat.mood = 2; vx = 0f; vy = 0f
        } else {
            val cx = x + s / 2
            val feet = y + s
            val sup = all.firstOrNull { abs(it.top - feet) < 3f && cx >= it.left && cx <= it.right }
            if (sup != null && vy >= 0f) {
                y = sup.top - s; vy = 0f
                if (now > actionAt) chooseAction(now)
                val nx = x + vx
                val ncx = nx + s / 2
                if (ncx < sup.left || ncx > sup.right) {
                    if (Random.nextBoolean()) { dir = -dir; vx = -vx } else x = nx
                } else x = nx
                cat.walkPhase += abs(vx) * 0.1f
            } else {
                vy += dp(0.45f)
                val ny = y + vy
                val nfeet = ny + s
                val land = all.filter { feet <= it.top + 1 && nfeet >= it.top && cx >= it.left && cx <= it.right }
                    .minByOrNull { it.top }
                if (land != null) { y = land.top - s; vy = 0f; cat.poke(0.7f) } else y = ny
            }
            if (x < 0f) { x = 0f; dir = 1; vx = abs(vx) }
            if (x > screenW - s) { x = screenW - s; dir = -1; vx = -abs(vx) }
            if (now > moodUntil) cat.mood = 0
        }

        if (now < lookUntil) {
            cat.lookX = ((lookTx - (x + s / 2)) / (screenW / 2f)).coerceIn(-1f, 1f)
            cat.lookY = ((lookTy - (y + s / 2)) / (screenH / 2f)).coerceIn(-1f, 1f)
        } else { cat.lookX = dir * 0.5f; cat.lookY = 0f }

        try {
            lp.x = x.toInt(); lp.y = y.toInt()
            wm.updateViewLayout(cat, lp)
            cat.step()
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        try { wm.removeView(cat) } catch (_: Exception) {}
        instance = null
        super.onDestroy()
    }
}
