package com.example.catpet

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.Base64
import java.io.ByteArrayOutputStream
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.random.Random

/** Кики поверх экрана: физика, прогулки по поверхностям, реакции, сон, маленькое меню и быстрый чат. */
class CatService : Service() {
    companion object {
        @Volatile var instance: CatService? = null
        const val ACT_SHOW = "com.example.catpet.SHOW"
        const val ACT_HIDE = "com.example.catpet.HIDE"
    }

    private val FLAGS_TOUCH = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
    private val FLAGS_GHOST = FLAGS_TOUCH or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
    private val TYPE_OVL = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    private lateinit var wm: WindowManager
    private lateinit var cat: CatView
    private lateinit var lp: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())

    private var created = false
    private var hidden = false
    private var screenOn = true
    private var lowPower = false
    private var sleeping = false
    private var dragging = false
    private var portal = false

    private var catPx = 0
    private var ws = 0
    private var margin = 0
    private var feetOff = 0f
    private var screenW = 0
    private var screenH = 0
    private var navH = 0f

    private var x = 0f
    private var y = 0f
    private var vx = 0f
    private var vy = 0f
    private var dir = 1

    private var lastTick = 0L
    private var actionAt = 0L
    private var moodUntil = 0L
    private var lookUntil = 0L
    private var lookTx = 0f
    private var lookTy = 0f
    private var lastActivity = 0L
    private var nextPeek = 0L
    private var lastReact = 0L
    private var lastScrollReact = 0L
    private var secCounter = 0f
    private var fingerX = 0f
    private var fingerY = 0f
    private var fingerOn = false
    private var longFired = false
    private var a11yWarnAt = 0L
    private var docked = false
    private var dockLeft = true
    private var dockOn = true
    private var dockMs = 20000L
    private var lastTouch = 0L
    private var picker: RegionPicker? = null

    private var bubble: TextView? = null
    private val menuViews = ArrayList<View>()
    private var quick: QuickChat? = null

    // настройки (кэш)
    private var walkSurf = true
    private var wrapFall = true
    private var followTaps = true
    private var wakeEv = true
    private var showZzz = true
    private var bubblesOn = true
    private var haptic = false
    private var rClick = true
    private var rScroll = true
    private var rText = true
    private var rWindow = true
    private var rNotif = true
    private var peekOn = false
    private var fps30 = true
    private var lowPowerOn = true
    private var sleepMs = 180000L
    private var peekMs = 600000L
    private var shakePow = 0.6f
    private var talk = 0.4f
    private var speedMul = 1f
    private var opacity = 1f
    private var sizeDp = 110

    private val bubbleCloser = Runnable { removeBubble() }
    private val menuCloser = Runnable { closeMenu() }
    private val longPress = Runnable { onLongPress() }

    private val loop = object : Runnable {
        override fun run() {
            if (hidden || !screenOn) return
            try { tick() } catch (t: Throwable) {}
            val calm = cat.settled() && !dragging && vy == 0f && vx == 0f
            val slow = fps30 || (lowPower && lowPowerOn)
            val delay = if (calm) 120L else if (slow) 33L else 16L
            handler.postDelayed(this, delay)
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            when (i?.action) {
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; handler.removeCallbacks(loop) }
                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    lastTick = SystemClock.uptimeMillis()
                    if (created && !hidden) { handler.removeCallbacks(loop); handler.post(loop) }
                }
                Intent.ACTION_BATTERY_LOW -> lowPower = true
                Intent.ACTION_BATTERY_OKAY -> lowPower = false
                else -> {}
            }
        }
    }

    private fun dp(v: Float): Float = v * resources.displayMetrics.density
    private fun dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startForegroundCompat()
        if (!created) create()
        when (i?.action) {
            ACT_HIDE -> hide()
            ACT_SHOW -> show()
            else -> {}
        }
        return START_STICKY
    }

    private fun startForegroundCompat() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cat", "Кики", NotificationManager.IMPORTANCE_MIN))
        val fl = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val showPi = PendingIntent.getService(this, 1, Intent(this, CatService::class.java).setAction(ACT_SHOW), fl)
        val hidePi = PendingIntent.getService(this, 2, Intent(this, CatService::class.java).setAction(ACT_HIDE), fl)
        val n = Notification.Builder(this, "cat")
            .setContentTitle("Кики с тобой")
            .setContentText("Спрятал котика? Нажми «Позвать Кики»")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_view), "Позвать Кики", showPi).build())
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Спрятать", hidePi).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- настройки ----------

    fun reloadPrefs() {
        val oldFeet = y + feetOff
        val oldCx = x + ws / 2f
        val c: Context = this
        walkSurf = Prefs.b(c, "walk_surfaces")
        wrapFall = Prefs.b(c, "wrap_fall")
        followTaps = Prefs.b(c, "follow_taps")
        wakeEv = Prefs.b(c, "wake_on_event")
        showZzz = Prefs.b(c, "show_zzz")
        bubblesOn = Prefs.b(c, "show_bubbles")
        haptic = Prefs.b(c, "haptic")
        rClick = Prefs.b(c, "react_click")
        rScroll = Prefs.b(c, "react_scroll")
        rText = Prefs.b(c, "react_text")
        rWindow = Prefs.b(c, "react_window")
        rNotif = Prefs.b(c, "react_notif")
        peekOn = Prefs.b(c, "peek_random")
        fps30 = Prefs.i(c, "fps") == 0
        lowPowerOn = Prefs.b(c, "low_power")
        sleepMs = Prefs.i(c, "sleep_min") * 60000L
        peekMs = Prefs.i(c, "peek_min") * 60000L
        shakePow = Prefs.i(c, "shake_power") / 100f
        talk = Prefs.i(c, "talk_rate") / 100f
        speedMul = when (Prefs.i(c, "activity")) { 0 -> 0.6f; 2 -> 1.5f; else -> 1f }
        opacity = Prefs.i(c, "cat_opacity") / 100f
        dockOn = Prefs.b(c, "dock_on")
        dockMs = Prefs.i(c, "dock_sec") * 1000L
        sizeDp = Prefs.i(c, "cat_size")
        applySize()
        if (created) {
            // при смене размера Кики остаётся стоять на том же месте
            x = oldCx - ws / 2f
            y = oldFeet - feetOff
            cat.alpha = if (docked) minOf(opacity, 0.45f) else opacity
            cat.applySkin(Skins.current(c))
            lp.width = ws
            lp.height = ws
            lp.x = x.toInt()
            lp.y = y.toInt()
            try { wm.updateViewLayout(cat, lp) } catch (_: Exception) {}
        }
    }

    private fun applySize() {
        catPx = dpi(sizeDp)
        ws = (catPx * 1.24f).toInt()
        margin = (catPx * 0.12f).toInt()
        val sp = Arts.spec(Skins.current(this).art)
        feetOff = ws - margin - sp.feetPad() * (catPx / sp.cw)
    }

    private fun readScreenSize() {
        navH = dp(24f)
        if (Build.VERSION.SDK_INT >= 30) {
            val m = wm.currentWindowMetrics
            screenW = m.bounds.width()
            screenH = m.bounds.height()
            try {
                val ins = m.windowInsets.getInsetsIgnoringVisibility(WindowInsets.Type.navigationBars())
                navH = maxOf(ins.bottom.toFloat(), dp(16f))
            } catch (_: Exception) {}
        } else {
            val m = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
            screenW = m.widthPixels
            screenH = m.heightPixels
            navH = dp(48f)
        }
    }

    fun screenWidthPx(): Int = screenW

    fun openApp() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(i)
    }

    // ---------- создание ----------

    private fun create() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        readScreenSize()
        reloadPrefs()
        cat = CatView(this)
        cat.alpha = opacity
        cat.applySkin(Skins.current(this))
        lp = WindowManager.LayoutParams(ws, ws, TYPE_OVL, FLAGS_TOUCH, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        x = screenW / 2f - ws / 2f
        y = dp(100f)
        lp.x = x.toInt()
        lp.y = y.toInt()
        wm.addView(cat, lp)
        setupTouch()
        val f = IntentFilter()
        f.addAction(Intent.ACTION_SCREEN_OFF)
        f.addAction(Intent.ACTION_SCREEN_ON)
        f.addAction(Intent.ACTION_BATTERY_LOW)
        f.addAction(Intent.ACTION_BATTERY_OKAY)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
        lastTick = SystemClock.uptimeMillis()
        lastActivity = lastTick
        lastTouch = lastTick
        nextPeek = lastTick + peekMs
        created = true
        instance = this
        handler.post(loop)
        react(Ev.REAPPEAR)
    }

    /** Указания от ИИ: настроение, анимация, взгляд, фраза, движение, сон, скин. Выполняется только то, что разрешено в настройках. */
    fun applyDirectives(d: Map<String, String>) {
        if (!created || hidden || d.isEmpty()) return
        undock()
        val c: Context = this
        val now = SystemClock.uptimeMillis()
        if (Control.allowed(c, "sleep")) {
            val sl = d["sleep"]
            if (sl == "1" || sl == "true") {
                sleeping = true
                cat.sleeping = true
                vx = 0f
            } else if (sl == "0" || sl == "false") {
                activity()
            }
        }
        if (!sleeping) lastActivity = now
        if (Control.allowed(c, "mood")) {
            val m = Control.moodOf(d["mood"])
            if (m >= 0) { cat.mood = m; moodUntil = now + 4000 }
        }
        if (Control.allowed(c, "anim")) {
            val a = Control.animOf(d["anim"])
            if (a != null) cat.playAnim(a)
        }
        if (Control.allowed(c, "look")) {
            val cx = x + ws / 2f
            val cy = y + ws / 2f
            var ok = true
            when (d["look"]) {
                "left" -> { lookTx = cx - screenW * 0.4f; lookTy = cy }
                "right" -> { lookTx = cx + screenW * 0.4f; lookTy = cy }
                "up" -> { lookTx = cx; lookTy = cy - screenH * 0.3f }
                "down" -> { lookTx = cx; lookTy = cy + screenH * 0.3f }
                "center" -> { lookTx = cx; lookTy = cy }
                else -> ok = false
            }
            if (ok) lookUntil = now + 3500
        }
        if (Control.allowed(c, "move") && !sleeping) {
            val sp = dp(75f) * speedMul
            when (d["move"]) {
                "left" -> { dir = -1; vx = -sp; actionAt = now + 2500 }
                "right" -> { dir = 1; vx = sp; actionAt = now + 2500 }
                "jump" -> if (vy == 0f && !dragging) vy = -dp(620f)
                "stop" -> { vx = 0f; actionAt = now + 3000 }
                else -> {}
            }
        }
        if (Control.allowed(c, "skin")) {
            val id = Skins.idOf(d["skin"])
            if (id >= 0) { Skins.applyPreset(c, id); reloadPrefs() }
        }
        if (Control.allowed(c, "say")) {
            val t = d["say"]
            if (t != null && t.isNotBlank()) say(t.take(60))
        }
    }

    fun wantsSurfaces(): Boolean = created && !hidden && screenOn && walkSurf

    fun statusText(): String = if (hidden) "спрятан" else if (sleeping) "спит" else "бодрый"

    fun peekNow() { peek() }

    fun openQuickFromApp() { openQuick(true, null) }

    /** Проверка чтения экрана: через 6 секунд сообщает, сколько опор и символов текста Кики увидел в приложении, куда ты перешёл. */
    fun diagnose() {
        val c = applicationContext
        Toast.makeText(c, "Перейди в любое приложение. Проверка через 6 секунд", Toast.LENGTH_LONG).show()
        handler.postDelayed({
            val svc = SurfaceService.instance
            val msg = if (svc == null) "Служба чтения экрана не подключена. Выключи и снова включи «Кики» в спец. возможностях."
            else {
                svc.rescan()
                val n = Surfaces.rects.size
                val len = svc.screenText()?.length ?: 0
                "Вижу опор: " + n + ", символов текста: " + len + if (n == 0 && len == 0) ". Экран не читается: проверь шаг «Чтение экрана»." else ". Чтение работает."
            }
            Toast.makeText(c, msg, Toast.LENGTH_LONG).show()
        }, 6000)
    }

    /** Запускает действие, которое попросил встроенный помощник (таймер, будильник). */
    fun runIntent(i: Intent) {
        try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        } catch (_: Exception) {
            say("Не получилось запустить: на телефоне нет подходящего приложения")
        }
    }

    private fun floorY(): Float = screenH - navH

    // ---------- касания ----------

    private fun setupTouch() {
        var offX = 0f
        var offY = 0f
        var downX = 0f
        var downY = 0f
        var lastRawX = 0f
        var downT = 0L
        var moved = false
        cat.setOnTouchListener { v, e ->
            fingerX = e.x
            fingerY = e.y
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = true
                    moved = false
                    longFired = false
                    fingerOn = true
                    portal = false
                    downT = SystemClock.uptimeMillis()
                    downX = e.rawX
                    downY = e.rawY
                    lastRawX = e.rawX
                    offX = e.rawX - x
                    offY = e.rawY - y
                    vx = 0f
                    vy = 0f
                    cat.kick(-3f, 0f)
                    activity()
                    touchActivity()
                    handler.removeCallbacks(longPress)
                    handler.postDelayed(longPress, 450)
                    if (haptic) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!longFired) {
                        x = e.rawX - offX
                        y = e.rawY - offY
                        val dx = e.rawX - lastRawX
                        lastRawX = e.rawX
                        if (hypot(e.rawX - downX, e.rawY - downY) > dp(10f) && !moved) {
                            moved = true
                            handler.removeCallbacks(longPress)
                            closeMenu()
                            react(Ev.DRAG)
                        }
                        cat.drag(dx, shakePow)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longPress)
                    dragging = false
                    fingerOn = false
                    cat.endDrag()
                    val now = SystemClock.uptimeMillis()
                    if (longFired) {
                        // долгое нажатие уже открыло чат
                    } else if (!moved && now - downT < 300) {
                        onTap()
                    } else {
                        cat.kick(5f, 0f)
                        // отпустили у самого низа: Кики проваливается вниз и выпадает сверху
                        if (wrapFall && y + feetOff > floorY() - dp(30f)) portal = true
                    }
                }
                else -> {}
            }
            true
        }
    }

    private fun onTap() {
        if (menuViews.isNotEmpty()) closeMenu() else { react(Ev.POKE); openMenu() }
    }

    private fun onLongPress() {
        longFired = true
        closeMenu()
        if (haptic) cat.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        openQuick(true, null)
    }

    private fun touchActivity() {
        lastTouch = SystemClock.uptimeMillis()
        undock()
    }

    /** Когда Кики не трогают, он уходит к краю экрана и становится полупрозрачным, чтобы не мешать. */
    private fun dock() {
        if (docked) return
        docked = true
        dockLeft = (x + ws / 2f) < screenW / 2f
        cat.animate().alpha(minOf(opacity, 0.45f)).setDuration(400).start()
    }

    private fun undock() {
        if (!docked) return
        docked = false
        cat.animate().alpha(opacity).setDuration(250).start()
    }

    private fun activity() {
        lastActivity = SystemClock.uptimeMillis()
        if (sleeping) {
            sleeping = false
            cat.sleeping = false
            react(Ev.WAKE)
        }
    }

    // ---------- события экрана ----------

    fun onEvent(type: Int, r: Rect, pkg: String) {
        try { onEventSafe(type, r) } catch (t: Throwable) {}
    }

    private fun onEventSafe(type: Int, r: Rect) {
        if (!created || hidden) return
        if (sleeping && !wakeEv) return
        val now = SystemClock.uptimeMillis()
        when (type) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> if (rClick) {
                activity()
                if (followTaps) look(r, now)
                react(Ev.CLICK)
            }
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> if (rText) {
                activity()
                if (followTaps) look(r, now)
                react(Ev.TEXT)
            }
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> if (rScroll) {
                activity()
                if (now - lastScrollReact > 2500) { lastScrollReact = now; react(Ev.SCROLL) }
            }
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> if (rWindow) {
                activity()
                react(Ev.WINDOW)
            }
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> if (rNotif) {
                activity()
                react(Ev.NOTIF)
                if (vy == 0f && !dragging) vy = -dp(380f)
            }
            else -> {}
        }
    }

    private fun look(r: Rect, now: Long) {
        if (r.isEmpty) return
        lookTx = r.exactCenterX()
        lookTy = r.exactCenterY()
        lookUntil = now + 1500
    }

    private fun react(ev: Int) {
        if (!created) return
        val now = SystemClock.uptimeMillis()
        if (ev != Ev.WAKE && ev != Ev.SLEEP && now - lastReact < 700) return
        lastReact = now
        val r = Reactions.pick(ev)
        cat.mood = r.mood
        moodUntil = now + 1600
        cat.playAnim(r.anim)
        if (ev == Ev.SLEEP) { if (showZzz) say(r.phrase) }
        else if (Random.nextFloat() < talk) say(r.phrase)
    }

    // ---------- физика и поведение ----------

    private fun chooseAction(now: Long) {
        val sp = dp(75f) * speedMul
        val r = Random.nextInt(100)
        when {
            r < 50 -> { vx = dir * sp; actionAt = now + Random.nextLong(1500, 4000) }
            r < 70 -> { vx = 0f; actionAt = now + Random.nextLong(1200, 3000); cat.mood = 1; moodUntil = actionAt }
            r < 85 -> { vy = -dp(620f); vx = dir * sp; actionAt = now + 1500 }
            else -> { dir = -dir; vx = dir * sp; actionAt = now + 1000 }
        }
    }

    private fun landed(impact: Float) {
        if (impact > dp(450f)) { cat.kick(impact / dp(260f), 0f); react(Ev.LAND) }
        else cat.kick(impact / dp(500f), 0f)
    }

    private fun tick() {
        val now = SystemClock.uptimeMillis()
        var dt = (now - lastTick) / 1000f
        lastTick = now
        if (dt > 0.05f) dt = 0.05f
        if (dt < 0.001f) dt = 0.001f
        val s = ws.toFloat()
        val floorY = floorY()
        val tol = dp(14f)
        val rects: List<Rect> = if (walkSurf && !portal) Surfaces.rects else emptyList()
        var standing = false

        if (dragging) {
            vx = 0f
            vy = 0f
        } else {
            val cx = x + s / 2f
            val feet = y + feetOff
            var hasSup = false
            var isRect = false
            var topY = 0f
            var supL = 0
            var supR = 0
            var bestD = tol + 0.01f
            for (r in rects) {
                if (cx >= r.left && cx <= r.right) {
                    val dd = abs(r.top - feet)
                    if (dd < bestD) {
                        bestD = dd
                        hasSup = true
                        isRect = true
                        topY = r.top.toFloat()
                        supL = r.left
                        supR = r.right
                    }
                }
            }
            if (!hasSup && !portal && abs(floorY - feet) <= tol) {
                hasSup = true
                topY = floorY
            }

            if (hasSup && vy >= 0f) {
                standing = true
                y = topY - feetOff
                vy = 0f
                if (sleeping || docked || menuViews.isNotEmpty() || (quick != null && quick!!.isOpen())) vx = 0f
                else if (now > actionAt) chooseAction(now)
                val nx = x + vx * dt
                val ncx = nx + s / 2f
                if (isRect && (ncx < supL || ncx > supR)) {
                    if (Random.nextBoolean()) { dir = -dir; vx = -vx } else x = nx
                } else x = nx
            } else {
                vy += dp(1700f) * dt
                val ny = y + vy * dt
                val nfeet = ny + feetOff
                var land = -1f
                for (r in rects) {
                    if (feet <= r.top + 1 && nfeet >= r.top && cx >= r.left && cx <= r.right) {
                        if (land < 0f || r.top < land) land = r.top.toFloat()
                    }
                }
                if (!portal && feet <= floorY + 1 && nfeet >= floorY) {
                    if (land < 0f || floorY < land) land = floorY
                }
                if (land >= 0f) {
                    val impact = vy
                    y = land - feetOff
                    vy = 0f
                    landed(impact)
                } else y = ny
            }

            if (docked) {
                val tx = if (dockLeft) -s * 0.62f else screenW - s * 0.38f
                x += (tx - x) * minOf(1f, dt * 6f)
            } else {
                val minX = -s * 0.15f
                val maxX = screenW - s * 0.85f
                if (x < minX) { x = minX; dir = 1; vx = abs(vx) }
                if (x > maxX) { x = maxX; dir = -1; vx = -abs(vx) }
            }

            // провалился ниже экрана: выпадает сверху
            if (y > screenH) {
                y = -s * 1.1f
                vy = dp(200f)
                portal = false
                react(Ev.REAPPEAR)
            }
        }

        cat.walking = standing && abs(vx) > 1f

        if (sleeping) cat.mood = 3
        else if (now > moodUntil) cat.mood = 0

        if (fingerOn) {
            cat.lookX = ((fingerX - s / 2f) / (s / 2f)).coerceIn(-1f, 1f)
            cat.lookY = ((fingerY - s / 2f) / (s / 2f)).coerceIn(-1f, 1f)
        } else if (now < lookUntil) {
            cat.lookX = ((lookTx - (x + s / 2f)) / (screenW / 2f)).coerceIn(-1f, 1f)
            cat.lookY = ((lookTy - (y + s / 2f)) / (screenH / 2f)).coerceIn(-1f, 1f)
        } else {
            cat.lookX = if (abs(vx) > 1f) dir * 0.6f else 0f
            cat.lookY = 0f
        }

        secCounter += dt
        if (secCounter >= 1f) { secCounter = 0f; periodic(now) }

        val ix = x.toInt()
        val iy = y.toInt()
        if (ix != lp.x || iy != lp.y) {
            lp.x = ix
            lp.y = iy
            try { wm.updateViewLayout(cat, lp) } catch (_: Exception) {}
        }
        cat.step(dt)
    }

    private fun periodic(now: Long) {
        if (!sleeping && !dragging && now - lastActivity > sleepMs) {
            sleeping = true
            cat.sleeping = true
            vx = 0f
            react(Ev.SLEEP)
        }
        if (now > a11yWarnAt && Prefs.b(this, "warn_a11y") && Prefs.b(this, "a11y_seen") && SurfaceService.instance == null) {
            a11yWarnAt = now + 3L * 3600L * 1000L
            warnA11yOff()
        } else if (a11yWarnAt == 0L) {
            a11yWarnAt = now + 60000L
        }
        if (walkSurf) SurfaceService.instance?.rescan()
        if (dockOn && !docked && !dragging && !sleeping && menuViews.isEmpty() && picker == null &&
            !(quick?.isOpen() ?: false) && now - lastTouch > dockMs) dock()
        if (peekOn && now > nextPeek && !dragging) {
            nextPeek = now + peekMs + Random.nextLong(0, 30000)
            peek()
        }
    }

    /** Система сама выключает службу чтения экрана, если приложение закрыли или перегрузили. Предупреждаем и даём одну кнопку. */
    private fun warnA11yOff() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("alert", "Предупреждения", NotificationManager.IMPORTANCE_DEFAULT))
            val open = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)
            open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val pi = PendingIntent.getActivity(this, 3, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, "alert")
                .setContentTitle("Кики не видит экран")
                .setContentText("Система выключила чтение экрана. Нажми, чтобы включить снова.")
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build()
            nm.notify(2, n)
        } catch (_: Exception) {}
    }

    /** Кики заглядывает в экран и, если включён дневник, записывает, чем ты занят. */
    private fun peek() {
        if (!created || !Prefs.b(this, "screen_read")) return
        val now = SystemClock.uptimeMillis()
        cat.mood = 2
        moodUntil = now + 1800
        cat.playAnim(Anim.SPIN_EYES)
        if (Random.nextFloat() < talk) say(Reactions.pick(Ev.PEEK).phrase)
        val c = applicationContext
        Thread {
            val text = SurfaceService.instance?.screenText()
            if (text != null && Prefs.b(c, "journal_on")) {
                val pkg = SurfaceService.lastPkg
                val entry = if (Prefs.b(c, "journal_ai") && Ai.ready(c)) {
                    try { Ai.summarize(c, text) } catch (_: Exception) { "Открыто: " + pkg }
                } else "Открыто: " + pkg
                Journal.add(c, pkg, entry)
            }
        }.start()
    }

    // ---------- облачко с фразой ----------

    private fun say(t: String) {
        cat.talk(minOf(6f, 1.2f + t.length * 0.06f))
        if (!bubblesOn || hidden || !created) return
        removeBubble()
        val tv = TextView(this)
        tv.text = t
        tv.setTextColor(Color.parseColor("#E8ECF4"))
        tv.typeface = Fonts.regular(this)
        tv.textSize = 13f
        tv.setPadding(dpi(10), dpi(6), dpi(10), dpi(6))
        tv.background = CyberBg(Color.parseColor("#0B0D14"), Color.parseColor("#FF5A1F"), dp(7f), dp(1.2f), false)
        tv.maxWidth = (screenW * 0.7f).toInt()
        tv.measure(View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val w = tv.measuredWidth
        val h = tv.measuredHeight
        val p = WindowManager.LayoutParams(w, h, TYPE_OVL, FLAGS_GHOST, PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.START
        p.x = (x + ws / 2f - w / 2f).toInt().coerceIn(0, maxOf(0, screenW - w))
        var by = (y + catPx * 0.2f - h).toInt()
        if (by < dpi(24)) by = (y + ws - margin).toInt()
        p.y = by
        try {
            wm.addView(tv, p)
            bubble = tv
            handler.postDelayed(bubbleCloser, 2300)
        } catch (_: Exception) {}
    }

    private fun removeBubble() {
        handler.removeCallbacks(bubbleCloser)
        val b = bubble
        if (b != null) { try { wm.removeView(b) } catch (_: Exception) {} }
        bubble = null
    }

    // ---------- три маленькие кнопки рядом с Кики ----------

    private fun openMenu() {
        closeMenu()
        activity()
        touchActivity()
        val icons = arrayOf("chat", "select", "scan", "spark")
        val cx = x + ws / 2f
        val cy = y + ws / 2f
        val below = cy < dp(150f)
        val angles = if (below) doubleArrayOf(160.0, 115.0, 65.0, 20.0) else doubleArrayOf(200.0, 245.0, 295.0, 340.0)
        val rad = catPx * 0.55f + dp(30f)
        val size = dpi(46)
        for (i in 0..3) {
            val b = android.widget.ImageView(this)
            b.setImageDrawable(Ic(icons[i], Color.parseColor("#FF8A3D"), dpi(22)))
            b.scaleType = android.widget.ImageView.ScaleType.CENTER
            val g = GradientDrawable()
            g.shape = GradientDrawable.OVAL
            g.setColor(Color.parseColor("#E6070910"))
            g.setStroke(dpi(2), Color.parseColor("#FF5A1F"))
            b.background = g
            val idx = i
            b.setOnClickListener { onMenuPick(idx) }
            val rr = Math.toRadians(angles[i])
            val p = WindowManager.LayoutParams(size, size, TYPE_OVL, FLAGS_TOUCH, PixelFormat.TRANSLUCENT)
            p.gravity = Gravity.TOP or Gravity.START
            p.x = (cx + rad * cos(rr).toFloat() - size / 2f).toInt().coerceIn(0, maxOf(0, screenW - size))
            p.y = (cy + rad * sin(rr).toFloat() - size / 2f).toInt().coerceIn(dpi(24), maxOf(dpi(24), screenH - size))
            try {
                wm.addView(b, p)
                menuViews.add(b)
                b.scaleX = 0.3f
                b.scaleY = 0.3f
                b.alpha = 0f
                b.animate().scaleX(1f).scaleY(1f).alpha(1f)
                    .setStartDelay(i * 50L).setDuration(240).setInterpolator(OvershootInterpolator(1.8f)).start()
            } catch (_: Exception) {}
        }
        handler.postDelayed(menuCloser, 3500)
    }

    private fun closeMenu() {
        handler.removeCallbacks(menuCloser)
        for (v in menuViews) { try { wm.removeView(v) } catch (_: Exception) {} }
        menuViews.clear()
    }

    private fun onMenuPick(i: Int) {
        closeMenu()
        when (i) {
            0 -> openQuick(true, null)
            1 -> startRegionPick()
            2 -> runExplain()
            else -> trick()
        }
    }

    // ---------- быстрый чат и разбор экрана ----------

    private fun openQuick(focus: Boolean, screen: String?) {
        activity()
        touchActivity()
        val q = quick ?: QuickChat(this, wm)
        quick = q
        q.open(focus, screen)
    }

    /** Читает текст экрана и отдаёт его быстрому чату на разбор. */
    fun runExplain() {
        cat.mood = 2
        moodUntil = SystemClock.uptimeMillis() + 1800
        cat.playAnim(Anim.SPIN_EYES)
        val c = applicationContext
        Thread {
            val text = SurfaceService.instance?.screenText()
            handler.post {
                if (text == null) {
                    val why = if (SurfaceService.instance == null) "Не вижу экран: включи «Кики» в спец. возможностях" else "Не нашёл текста на экране"
                    say(why)
                } else {
                    if (Prefs.b(c, "journal_on")) {
                        val pkg = SurfaceService.lastPkg
                        val short = "Разбор задачи: " + text.take(80)
                        Thread { Journal.add(c, pkg, short) }.start()
                    }
                    openQuick(false, text)
                }
            }
        }.start()
    }

    /** Выделение области, как «Обведи для поиска»: снимок экрана, затемнение и обводка пальцем. Дальше текст области и картинка уходят на разбор. */
    fun startRegionPick() {
        touchActivity()
        closeMenu()
        val svc = SurfaceService.instance
        if (svc == null) { say("Включи чтение экрана, и я смогу смотреть"); return }
        quick?.close()
        cat.visibility = View.INVISIBLE
        handler.postDelayed({
            svc.shot { bmp ->
                cat.visibility = View.VISIBLE
                if (bmp == null) say("Снимок экрана не получился. Выключи и снова включи «Кики» в спец. возможностях")
                showPicker(bmp)
            }
        }, 200)
    }

    private fun showPicker(bmp: Bitmap?) {
        hidePicker()
        val pv = RegionPicker(this, bmp) { rect, vw, vh ->
            hidePicker()
            if (rect != null) onRegion(rect, bmp, vw, vh)
        }
        val p = WindowManager.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT, TYPE_OVL,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        if (Build.VERSION.SDK_INT >= 28) p.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        try { wm.addView(pv, p); picker = pv } catch (_: Exception) {}
    }

    private fun hidePicker() {
        val p = picker
        if (p != null) { try { wm.removeView(p) } catch (_: Exception) {} }
        picker = null
    }

    private fun onRegion(r: Rect, bmp: Bitmap?, vw: Int, vh: Int) {
        val c = applicationContext
        val sw = if (vw > 0) vw else screenW
        val sh = if (vh > 0) vh else screenH
        lookTx = r.exactCenterX()
        lookTy = r.exactCenterY()
        lookUntil = SystemClock.uptimeMillis() + 5000
        Thread {
            val svc2 = SurfaceService.instance
            var text = try { svc2?.screenText(r) } catch (e: Throwable) { null }
            if (text == null) {
                val wide = Rect(r)
                wide.inset(-dpi(24), -dpi(24))
                text = try { svc2?.screenText(wide) } catch (e: Throwable) { null }
            }
            var b64: String? = null
            var thumb: Bitmap? = null
            if (bmp != null) {
                try {
                    val sx = bmp.width.toFloat() / sw
                    val sy = bmp.height.toFloat() / sh
                    val l = (r.left * sx).toInt().coerceIn(0, bmp.width - 1)
                    val t = (r.top * sy).toInt().coerceIn(0, bmp.height - 1)
                    val w = (r.width() * sx).toInt().coerceIn(1, bmp.width - l)
                    val h = (r.height() * sy).toInt().coerceIn(1, bmp.height - t)
                    var crop = Bitmap.createBitmap(bmp, l, t, w, h)
                    val tk = 480f / maxOf(crop.width, crop.height)
                    thumb = if (tk < 1f) Bitmap.createScaledBitmap(crop, (crop.width * tk).toInt().coerceAtLeast(1), (crop.height * tk).toInt().coerceAtLeast(1), true) else crop
                    val m = maxOf(crop.width, crop.height)
                    if (m > 1024) {
                        val k = 1024f / m
                        crop = Bitmap.createScaledBitmap(crop, (crop.width * k).toInt().coerceAtLeast(1), (crop.height * k).toInt().coerceAtLeast(1), true)
                    }
                    if (Ai.ready(c)) {
                        val bo = ByteArrayOutputStream()
                        crop.compress(Bitmap.CompressFormat.JPEG, 80, bo)
                        b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
                    }
                } catch (e: Throwable) {}
            }
            val img = b64
            val found = text
            val th = thumb
            handler.post {
                touchActivity()
                val q = quick ?: QuickChat(this, wm)
                quick = q
                q.openRegion(found, img, th)
            }
        }.start()
    }

    private fun trick() {
        val r = Reactions.pick(Ev.TRICK)
        cat.mood = r.mood
        moodUntil = SystemClock.uptimeMillis() + 2200
        cat.playAnim(r.anim)
        if (vy == 0f && !dragging) vy = -dp(520f)
        say(Reactions.joke())
    }

    // ---------- спрятать / позвать ----------

    private fun hide() {
        if (hidden) return
        hidden = true
        closeMenu()
        removeBubble()
        quick?.close()
        cat.visibility = View.GONE
        handler.removeCallbacks(loop)
    }

    private fun show() {
        if (!hidden) return
        hidden = false
        cat.visibility = View.VISIBLE
        val now = SystemClock.uptimeMillis()
        lastTick = now
        lastActivity = now
        lastTouch = now
        docked = false
        sleeping = false
        cat.sleeping = false
        portal = false
        y = -ws * 1.1f
        vy = 0f
        handler.removeCallbacks(loop)
        handler.post(loop)
        react(Ev.REAPPEAR)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        closeMenu()
        removeBubble()
        quick?.close()
        hidePicker()
        if (created) { try { wm.removeView(cat) } catch (_: Exception) {} }
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        instance = null
        super.onDestroy()
    }
}
