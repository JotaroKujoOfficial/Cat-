package com.example.catpet

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable

/** Линейные иконки, нарисованные кодом на сетке 24x24. Заменяют эмодзи и текстовые значки. */
class Ic(private val kind: String, private val color: Int, private val px: Int) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.9f
        p.strokeCap = Paint.Cap.ROUND
        p.strokeJoin = Paint.Join.ROUND
        p.color = color
    }

    override fun getIntrinsicWidth(): Int = px
    override fun getIntrinsicHeight(): Int = px

    override fun draw(c: Canvas) {
        val s = bounds.width() / 24f
        c.save()
        c.translate(bounds.left.toFloat(), bounds.top.toFloat())
        c.scale(s, s)
        val path = Path()
        when (kind) {
            "chat" -> {
                c.drawRoundRect(RectF(3f, 4f, 21f, 16.5f), 4.5f, 4.5f, p)
                path.moveTo(8.5f, 16.5f); path.lineTo(7f, 20.5f); path.lineTo(12.5f, 16.5f)
                c.drawPath(path, p)
            }
            "select" -> {
                for (sx in intArrayOf(0, 1)) for (sy in intArrayOf(0, 1)) {
                    val x = if (sx == 0) 4f else 20f
                    val y = if (sy == 0) 4f else 20f
                    val dx = if (sx == 0) 5f else -5f
                    val dy = if (sy == 0) 5f else -5f
                    path.reset(); path.moveTo(x, y + dy); path.lineTo(x, y); path.lineTo(x + dx, y)
                    c.drawPath(path, p)
                }
                c.drawPoint(12f, 12f, p)
            }
            "scan" -> {
                path.moveTo(2.5f, 12f); path.quadTo(12f, 3.5f, 21.5f, 12f); path.quadTo(12f, 20.5f, 2.5f, 12f)
                c.drawPath(path, p)
                c.drawCircle(12f, 12f, 3.2f, p)
            }
            "spark" -> {
                path.moveTo(12f, 2.5f); path.quadTo(13f, 11f, 21.5f, 12f); path.quadTo(13f, 13f, 12f, 21.5f)
                path.quadTo(11f, 13f, 2.5f, 12f); path.quadTo(11f, 11f, 12f, 2.5f)
                c.drawPath(path, p)
            }
            "home" -> {
                path.moveTo(3.5f, 11f); path.lineTo(12f, 3.5f); path.lineTo(20.5f, 11f)
                path.moveTo(6f, 9.5f); path.lineTo(6f, 20f); path.lineTo(18f, 20f); path.lineTo(18f, 9.5f)
                c.drawPath(path, p)
                c.drawLine(10f, 20f, 10f, 14.5f, p); c.drawLine(14f, 20f, 14f, 14.5f, p)
            }
            "face" -> {
                path.moveTo(4.5f, 20f); path.lineTo(4.5f, 6f); path.lineTo(9f, 9.5f)
                path.quadTo(12f, 8.5f, 15f, 9.5f); path.lineTo(19.5f, 6f); path.lineTo(19.5f, 20f)
                path.close()
                c.drawPath(path, p)
                c.drawPoint(9.5f, 14f, p); c.drawPoint(14.5f, 14f, p)
            }
            "tune" -> {
                c.drawLine(4f, 7f, 20f, 7f, p); c.drawLine(4f, 12f, 20f, 12f, p); c.drawLine(4f, 17f, 20f, 17f, p)
                val f = Paint(p); f.style = Paint.Style.FILL
                c.drawCircle(15f, 7f, 2.4f, f); c.drawCircle(8f, 12f, 2.4f, f); c.drawCircle(13f, 17f, 2.4f, f)
            }
            "chip" -> {
                c.drawRoundRect(RectF(6.5f, 6.5f, 17.5f, 17.5f), 2.5f, 2.5f, p)
                for (t in floatArrayOf(9.5f, 14.5f)) {
                    c.drawLine(t, 3f, t, 6.5f, p); c.drawLine(t, 17.5f, t, 21f, p)
                    c.drawLine(3f, t, 6.5f, t, p); c.drawLine(17.5f, t, 21f, t, p)
                }
                c.drawPoint(12f, 12f, p)
            }
            "more" -> {
                c.drawLine(4f, 7f, 20f, 7f, p); c.drawLine(4f, 12f, 15f, 12f, p); c.drawLine(4f, 17f, 18f, 17f, p)
            }
            "close" -> {
                c.drawLine(6f, 6f, 18f, 18f, p); c.drawLine(18f, 6f, 6f, 18f, p)
            }
            "send" -> {
                path.moveTo(3.5f, 11.5f); path.lineTo(20.5f, 3.5f); path.lineTo(13.5f, 20.5f); path.lineTo(11f, 13f); path.close()
                c.drawPath(path, p)
                c.drawLine(11f, 13f, 20.5f, 3.5f, p)
            }
        }
        c.restore()
    }

    override fun setAlpha(alpha: Int) { p.alpha = alpha }
    override fun setColorFilter(cf: ColorFilter?) { p.colorFilter = cf }
    @Suppress("DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
