package com.example.catpet

import android.content.Context
import java.io.File

/** Дневник задач: хранится в файле на телефоне и никуда не отправляется. */
object Journal {
    class Entry(val time: Long, val app: String, val text: String)

    private fun file(c: Context) = File(c.filesDir, "journal.txt")

    @Synchronized
    fun add(c: Context, app: String, text: String) {
        val clean = { s: String -> s.replace('\t', ' ').replace('\n', ' ').replace('\r', ' ') }
        file(c).appendText(System.currentTimeMillis().toString() + "\t" + clean(app) + "\t" + clean(text) + "\n")
        prune(c)
    }

    @Synchronized
    fun all(c: Context): List<Entry> {
        val f = file(c)
        if (!f.exists()) return emptyList()
        val out = ArrayList<Entry>()
        for (line in f.readLines()) {
            val p = line.split("\t", limit = 3)
            if (p.size == 3) out.add(Entry(p[0].toLongOrNull() ?: 0L, p[1], p[2]))
        }
        return out
    }

    @Synchronized
    private fun prune(c: Context) {
        val limit = System.currentTimeMillis() - Prefs.i(c, "journal_days") * 86400000L
        val keep = all(c).filter { it.time >= limit }
        val sb = StringBuilder()
        for (e in keep) sb.append(e.time).append('\t').append(e.app).append('\t').append(e.text).append('\n')
        file(c).writeText(sb.toString())
    }

    @Synchronized
    fun clear(c: Context) { file(c).delete() }
}
