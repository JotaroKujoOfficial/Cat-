package com.example.catpet

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor
import kotlin.math.pow
import kotlin.math.sqrt

class BrainReply(val text: String, val dirs: Map<String, String> = emptyMap(), val action: Intent? = null)

/**
 * Встроенный помощник без интернета и ключей. Это не нейросеть: он умеет считать, переводить единицы,
 * говорить время и дату, ставить таймер и будильник, помнить заметки и имя, отвечать про само приложение,
 * разбирать текст с экрана и поддерживать разговор. Для сложных вопросов нужен подключённый ИИ.
 */
object LocalBrain {
    private val ru = Locale("ru")

    fun reply(c: Context, input: String): BrainReply {
        val raw = input.trim()
        val low = raw.lowercase(ru)
        memory(c, raw, low)?.let { return it }
        timer(low)?.let { return it }
        dateTime(low)?.let { return BrainReply(it, mapOf("mood" to "happy")) }
        units(low)?.let { return BrainReply(it, mapOf("mood" to "happy", "anim" to "bounce")) }
        math(low)?.let { return BrainReply(it, mapOf("mood" to "happy", "anim" to "bounce")) }
        help(low)?.let { return BrainReply(it) }
        emotion(low)?.let { return it }
        return small(c, raw, low)
    }

    /** Быстрые умения без нейросети: вычисления, единицы, время, таймер, заметки, справка. Null, если подходящего умения нет. */
    fun tool(c: Context, input: String): BrainReply? {
        val raw = input.trim()
        val low = raw.lowercase(ru)
        memory(c, raw, low)?.let { return it }
        timer(low)?.let { return it }
        dateTime(low)?.let { return BrainReply(it, mapOf("mood" to "happy")) }
        units(low)?.let { return BrainReply(it, mapOf("mood" to "happy", "anim" to "bounce")) }
        math(low)?.let { return BrainReply(it, mapOf("mood" to "happy", "anim" to "bounce")) }
        help(low)?.let { return BrainReply(it) }
        return null
    }

    // ---------- заметки и имя ----------

    private fun notes(c: Context): List<String> =
        Prefs.s(c, "brain_notes").split("\n").filter { it.isNotBlank() }

    private fun memory(c: Context, raw: String, low: String): BrainReply? {
        val nm = Regex("(?:меня зовут|моё имя|мое имя)\\s+([\\p{L}-]{2,20})").find(low)
        if (nm != null) {
            val name = nm.groupValues[1].replaceFirstChar { it.uppercase() }
            Prefs.putS(c, "brain_name", name)
            return BrainReply("Приятно познакомиться, " + name + "! Буду звать тебя так.", mapOf("mood" to "happy", "anim" to "hop"))
        }
        if (low.contains("как меня зовут")) {
            val name = Prefs.s(c, "brain_name")
            return BrainReply(if (name.isEmpty()) "Пока не знаю. Скажи: «меня зовут …»." else "Тебя зовут " + name + ".")
        }
        val rem = Regex("^запомни[,:]?\\s+(.+)").find(low)
        if (rem != null) {
            val note = rem.groupValues[1].replace('\n', ' ').trim().replaceFirstChar { it.uppercase() }
            Prefs.putS(c, "brain_notes", (notes(c) + note).takeLast(40).joinToString("\n"))
            return BrainReply("Запомнил: " + note, mapOf("mood" to "happy", "anim" to "bounce"))
        }
        if (low.contains("что ты помнишь") || low.contains("мои заметки") || low.contains("покажи заметки")) {
            val n = notes(c)
            return BrainReply(if (n.isEmpty()) "Пока ничего. Скажи «запомни …»." else "Я помню:\n" + n.mapIndexed { i, s -> "" + (i + 1) + ". " + s }.joinToString("\n"))
        }
        if (low.contains("забудь все") || low.contains("забудь всё") || low.contains("очисти заметки")) {
            Prefs.putS(c, "brain_notes", "")
            return BrainReply("Всё забыл. Чистый лист.", mapOf("mood" to "surprised"))
        }
        return null
    }

    // ---------- таймер и будильник ----------

    private fun timer(low: String): BrainReply? {
        val t = Regex("(?:таймер|засеки).*?(\\d+)\\s*(сек|мин|час|ч\\b)").find(low)
        if (t != null) {
            val v = t.groupValues[1].toInt()
            val unit = t.groupValues[2]
            val secs = if (unit.startsWith("сек")) v else if (unit.startsWith("мин")) v * 60 else v * 3600
            val i = Intent(AlarmClock.ACTION_SET_TIMER)
            i.putExtra(AlarmClock.EXTRA_LENGTH, secs)
            i.putExtra(AlarmClock.EXTRA_MESSAGE, "Кики")
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            val what = if (unit.startsWith("сек")) plural(v, "секунду", "секунды", "секунд")
            else if (unit.startsWith("мин")) plural(v, "минуту", "минуты", "минут") else plural(v, "час", "часа", "часов")
            return BrainReply("Ставлю таймер на " + v + " " + what + ".", mapOf("mood" to "happy", "anim" to "hop"), i)
        }
        val a = Regex("(?:будильник|разбуди).*?(\\d{1,2})(?:[:.](\\d{2}))?\\s*(утра|вечера|ночи|дня)?").find(low)
        if (a != null) {
            var h = a.groupValues[1].toInt()
            val m = if (a.groupValues[2].isEmpty()) 0 else a.groupValues[2].toInt()
            val part = a.groupValues[3]
            if ((part == "вечера" || part == "дня") && h < 12) h += 12
            if (h > 23 || m > 59) return BrainReply("Не понял время. Скажи, например: «разбуди в 7:30».")
            val i = Intent(AlarmClock.ACTION_SET_ALARM)
            i.putExtra(AlarmClock.EXTRA_HOUR, h)
            i.putExtra(AlarmClock.EXTRA_MINUTES, m)
            i.putExtra(AlarmClock.EXTRA_MESSAGE, "Кики")
            i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            return BrainReply("Ставлю будильник на " + String.format("%02d:%02d", h, m) + ".", mapOf("mood" to "happy", "anim" to "hop"), i)
        }
        return null
    }

    // ---------- время и дата ----------

    private fun plural(n: Int, one: String, two: String, five: String): String {
        val a = abs(n) % 100
        val b = a % 10
        return if (a in 11..19) five else if (b == 1) one else if (b in 2..4) two else five
    }

    private fun stripTime(c: Calendar) {
        c.set(Calendar.HOUR_OF_DAY, 0)
        c.set(Calendar.MINUTE, 0)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
    }

    private fun daysUntil(month: Int, day: Int, year: Int?): Long {
        val now = Calendar.getInstance()
        stripTime(now)
        val t = Calendar.getInstance()
        stripTime(t)
        t.set(year ?: now.get(Calendar.YEAR), month - 1, day)
        if (year == null && t.before(now)) t.add(Calendar.YEAR, 1)
        return (t.timeInMillis - now.timeInMillis) / 86400000L
    }

    private fun dateTime(low: String): String? {
        if (low.contains("сколько времени") || low.contains("который час") || low.contains("сколько сейчас")) {
            return "Сейчас " + SimpleDateFormat("HH:mm", ru).format(Date()) + "."
        }
        if (low.contains("какое число") || low.contains("какая дата") || low.contains("какой сегодня день") ||
            low.contains("какой день недели") || low.contains("какое сегодня")) {
            return "Сегодня " + SimpleDateFormat("EEEE, d MMMM yyyy", ru).format(Date()) + "."
        }
        if (low.contains("до нового года")) {
            val d = daysUntil(1, 1, null).toInt()
            return "До Нового года " + d + " " + plural(d, "день", "дня", "дней") + "."
        }
        val m = Regex("сколько дней до\\s+(\\d{1,2})[.](\\d{1,2})(?:[.](\\d{4}))?").find(low)
        if (m != null) {
            val y = if (m.groupValues[3].isEmpty()) null else m.groupValues[3].toInt()
            val d = daysUntil(m.groupValues[2].toInt(), m.groupValues[1].toInt(), y).toInt()
            return if (d < 0) "Эта дата уже прошла." else "Осталось " + d + " " + plural(d, "день", "дня", "дней") + "."
        }
        return null
    }

    // ---------- единицы ----------

    private class U(val cat: String, val f: Double, val names: List<String>)

    private val table = listOf(
        U("len", 0.001, listOf("миллиметр", "мм")), U("len", 0.01, listOf("сантиметр", "см")),
        U("len", 1.0, listOf("метр", "м")), U("len", 1000.0, listOf("километр", "км")),
        U("len", 0.0254, listOf("дюйм")), U("len", 0.3048, listOf("фут")),
        U("len", 1609.344, listOf("миль", "миля")), U("len", 0.9144, listOf("ярд")),
        U("mass", 0.001, listOf("грамм", "г")), U("mass", 1.0, listOf("килограмм", "кг")),
        U("mass", 1000.0, listOf("тонн", "т")), U("mass", 0.45359237, listOf("фунт")), U("mass", 0.0283495, listOf("унци")),
        U("vol", 0.001, listOf("миллилитр", "мл")), U("vol", 1.0, listOf("литр", "л")), U("vol", 3.78541, listOf("галлон")),
        U("spd", 1.0, listOf("м/с")), U("spd", 0.277778, listOf("км/ч")), U("spd", 0.44704, listOf("миль/ч", "mph")),
        U("time", 1.0, listOf("секунд", "сек")), U("time", 60.0, listOf("минут", "мин")), U("time", 3600.0, listOf("час", "ч")),
        U("time", 86400.0, listOf("сут", "день", "дн")), U("time", 604800.0, listOf("недел")),
        U("data", 1.0, listOf("байт")), U("data", 1024.0, listOf("кб", "килобайт")),
        U("data", 1048576.0, listOf("мб", "мегабайт")), U("data", 1073741824.0, listOf("гб", "гигабайт"))
    )

    private fun findUnit(w: String): U? {
        for (u in table) for (n in u.names) if (w == n || (n.length >= 3 && w.startsWith(n))) return u
        return null
    }

    private fun temp(w: String): String? = when {
        w.startsWith("цельс") || w == "c" || w == "°c" || w == "с" || w == "градус" || w == "градусов" -> "C"
        w.startsWith("фаренг") || w == "f" || w == "°f" -> "F"
        w.startsWith("кельв") || w == "k" -> "K"
        else -> null
    }

    private fun fmt(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return "не число"
        if (abs(v - floor(v)) < 1e-9 && abs(v) < 1e15) return v.toLong().toString()
        val s = String.format(Locale.US, "%.6f", v).trimEnd('0').trimEnd('.')
        return s.replace('.', ',')
    }

    private fun num(s: String): Double = s.replace(',', '.').toDouble()

    private fun units(low: String): String? {
        val m = Regex("(-?\\d+(?:[.,]\\d+)?)\\s*([\\p{L}°/]+)\\s+(?:в|to|на)\\s+([\\p{L}°/]+)").find(low) ?: return null
        val v = num(m.groupValues[1])
        val a = m.groupValues[2]
        val b = m.groupValues[3]
        val ta = temp(a)
        val tb = temp(b)
        if (ta != null && tb != null) {
            val c = when (ta) { "C" -> v; "F" -> (v - 32) * 5 / 9; else -> v - 273.15 }
            val r = when (tb) { "C" -> c; "F" -> c * 9 / 5 + 32; else -> c + 273.15 }
            return fmt(v) + "° = " + fmt(r) + "° (" + tb + ")"
        }
        val ua = findUnit(a)
        val ub = findUnit(b)
        if (ua == null || ub == null || ua.cat != ub.cat) return null
        return fmt(v) + " " + a + " = " + fmt(v * ua.f / ub.f) + " " + b
    }

    // ---------- вычисления ----------

    private class Parser(val s: String) {
        var i = 0
        fun run(): Double {
            val v = expr()
            skip()
            if (i != s.length) throw IllegalArgumentException("лишнее")
            return v
        }
        fun skip() { while (i < s.length && s[i] == ' ') i++ }
        fun peek(): Char { skip(); return if (i < s.length) s[i] else '\u0000' }
        fun expr(): Double {
            var v = term()
            while (true) {
                val ch = peek()
                if (ch == '+') { i++; v += term() } else if (ch == '-') { i++; v -= term() } else return v
            }
        }
        fun term(): Double {
            var v = power()
            while (true) {
                val ch = peek()
                if (ch == '*') { i++; v *= power() } else if (ch == '/') { i++; v /= power() } else return v
            }
        }
        fun power(): Double {
            val b = unary()
            if (peek() == '^') { i++; return b.pow(power()) }
            return b
        }
        fun unary(): Double {
            val ch = peek()
            if (ch == '-') { i++; return -unary() }
            if (ch == '+') { i++; return unary() }
            return atom()
        }
        fun atom(): Double {
            val ch = peek()
            if (ch == '(') {
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("скобка")
                i++
                return v
            }
            if (s.startsWith("sqrt", i)) {
                i += 4
                if (peek() != '(') throw IllegalArgumentException("sqrt")
                i++
                val v = expr()
                if (peek() != ')') throw IllegalArgumentException("скобка")
                i++
                return sqrt(v)
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("число")
            var v = s.substring(st, i).toDouble()
            if (peek() == '%') { i++; v /= 100.0 }
            return v
        }
    }

    private fun solveMath(text: String): String? {
        var s = text.lowercase(ru)
        val pct = Regex("(\\d+(?:[.,]\\d+)?)\\s*%\\s*(?:от|of)\\s*(\\d+(?:[.,]\\d+)?)").find(s)
        if (pct != null) {
            val a = num(pct.groupValues[1])
            val b = num(pct.groupValues[2])
            return pct.groupValues[1] + "% от " + pct.groupValues[2] + " = " + fmt(a * b / 100.0)
        }
        for (w in listOf("сколько будет", "сколько", "посчитай", "вычисли", "реши", "равно", "=", "?")) s = s.replace(w, " ")
        s = s.replace("плюс", "+").replace("минус", "-").replace("умножить на", "*").replace("разделить на", "/")
            .replace("в степени", "^").replace("÷", "/").replace("×", "*")
        s = s.replace(Regex("корень из\\s*(\\d+(?:[.,]\\d+)?)"), "sqrt(\$1)")
        s = s.replace(Regex("(?<=\\d)\\s*[xх]\\s*(?=\\d)"), "*").replace(Regex("(?<=\\d)\\s*:\\s*(?=\\d)"), "/")
        s = s.replace(',', '.').trim()
        val chk = s.replace("sqrt", "")
        if (s.length < 3 || !Regex("^[0-9+\\-*/^().%\\s]+$").matches(chk)) return null
        if (!s.any { it.isDigit() } || !Regex("[+\\-*/^%]|sqrt").containsMatchIn(s)) return null
        return try { s.replace(" ", "") + " = " + fmt(Parser(s).run()) } catch (e: Exception) { null }
    }

    private fun math(low: String): String? = solveMath(low)

    // ---------- про приложение ----------

    private val faq = listOf(
        Pair("ключ|api|подключить ии|подключи ии|нейросет", "Открой вкладку «ИИ»: скопируй ключ на сайте сервиса (там есть кнопки), вернись и нажми «Вставить ключ и подключить». Адрес и модель я найду сам."),
        Pair("не вижу экран|читать экран|чтение экрана|спец.? возможност|служб", "Вкладка «Главная» → шаг «Чтение экрана». Если переключатель серый, открой «Сведения о приложении», нажми ⋮ и «Разрешить ограниченные настройки»."),
        Pair("падает|провалива|не сидит|не стоит", "Я стою на элементах экрана и на нижней границе. Если ты опустил меня к самому низу, я провалюсь и упаду сверху. Это настраивается во вкладке «Поведение»."),
        Pair("скин|цвет|облик|внешн", "Вкладка «Облик»: семь готовых скинов, свои цвета и ошейник с бубенчиком."),
        pairOf("ретранслятор|впн|vpn|не открывается|заблокирован|недоступен", "Если сервис ИИ закрыт в твоей стране: вкладка «ИИ» → «Настроить по шагам». Или возьми ключ OpenRouter или DeepSeek: они часто открываются без этого."),
        Pair("дневник", "Дневник включается во вкладке «Ещё». Он хранится только на телефоне."),
        Pair("спрятать|позвать|пропал", "Позвать меня можно кнопкой в уведомлении или на вкладке «Главная».")
    )

    private fun pairOf(a: String, b: String) = Pair(a, b)

    private fun help(low: String): String? {
        if (!(low.contains("как ") || low.contains("где ") || low.contains("почему") || low.contains("что делать") || low.contains("не работает") || low.contains("помоги"))) return null
        for ((k, v) in faq) if (Regex(k).containsMatchIn(low)) return v
        return null
    }

    // ---------- настроение ----------

    private fun emotion(low: String): BrainReply? {
        if (Regex("грустно|тоскливо|одиноко|мне плохо|тяжело|устал").containsMatchIn(low))
            return BrainReply("Мне жаль, что так. Я рядом. Хочешь, расскажи, что случилось, или давай просто посидим вместе.", mapOf("mood" to "sleepy", "anim" to "purr", "say" to "Я рядом"))
        if (Regex("злюсь|бесит|раздража|достало").containsMatchIn(low))
            return BrainReply("Понимаю. Сделай три медленных вдоха, а я пока посижу рядом. Потом расскажешь, что бесит.", mapOf("mood" to "normal", "anim" to "wiggle"))
        if (Regex("скучно|нечего делать").containsMatchIn(low))
            return BrainReply("Давай развлечёмся: могу пошутить, рассказать факт, посчитать что-нибудь или побегать по экрану. Скажи «шутка» или «факт».", mapOf("mood" to "smug", "anim" to "hop"))
        if (Regex("ура|круто|классно|я рад|отлично|супер|получилось").containsMatchIn(low))
            return BrainReply("Здорово! Я тоже рад. Мррр.", mapOf("mood" to "happy", "anim" to "hop", "say" to "Ура!"))
        if (Regex("спокойной ночи|хочу спать|пойду спать").containsMatchIn(low))
            return BrainReply("Спокойной ночи. Я тоже прикорну.", mapOf("mood" to "sleepy", "anim" to "stretch", "sleep" to "1"))
        return null
    }

    // ---------- разговор ----------

    private val facts = listOf(
        "Кошки спят 12–16 часов в сутки.",
        "У каждой кошки свой неповторимый узор на носу.",
        "Усы помогают кошке оценить, пролезет ли она в узкое место.",
        "Кошки не различают сладкий вкус.",
        "Кошачье мурлыканье лежит примерно в диапазоне 25–150 герц.",
        "Кошка видит в темноте намного лучше человека.",
        "Кошки могут прыгнуть в высоту в несколько раз выше собственного роста."
    )

    private val jokes = listOf(
        "Я не ленивый, я в режиме энергосбережения.",
        "Если что-то лежит на краю стола, это просьба его уронить.",
        "Мой любимый спорт: смотреть на курсор.",
        "Я не толстый, я просто пушистый изнутри."
    )

    private fun small(c: Context, raw: String, low: String): BrainReply {
        val name = Prefs.s(c, "brain_name")
        val who = if (name.isEmpty()) "" else ", " + name
        if (Regex("^(привет|здравств|хай|добрый|доброе|здорово|ку\\b)").containsMatchIn(low))
            return BrainReply("Привет" + who + "! Рад тебя видеть. Чем помочь?", mapOf("mood" to "happy", "anim" to "wave_ears"))
        if (low.contains("как дела") || low.contains("как ты"))
            return BrainReply("Отлично: гуляю по экрану, ничего не уронил. А у тебя как" + who + "?", mapOf("mood" to "happy", "anim" to "purr"))
        if (low.contains("кто ты") || low.contains("как тебя зовут") || low.contains("твоё имя") || low.contains("твое имя"))
            return BrainReply("Я Кики, ИИ-помощник, который живёт на твоём экране.", mapOf("mood" to "happy", "anim" to "bounce"))
        if (low.contains("что ты умеешь") || low.contains("помощь") || low.contains("команды") || low.contains("что можешь"))
            return BrainReply("Без подключённого ИИ я умею: считать («2+2*3», «15% от 2300»), переводить единицы («5 км в мили»), называть время и дату, ставить таймер («таймер на 5 минут») и будильник («разбуди в 7:30»), помнить заметки («запомни …»), разбирать текст с экрана, шутить и рассказывать факты. Для сложных вопросов подключи ИИ во вкладке «ИИ».")
        if (low.contains("спасибо") || low.contains("благодар"))
            return BrainReply("Мур, пожалуйста" + who + "!", mapOf("mood" to "happy", "anim" to "purr"))
        if (low.contains("шутк") || low.contains("анекдот") || low.contains("рассмеши"))
            return BrainReply(jokes.random(), mapOf("mood" to "smug", "anim" to "shake"))
        if (low.contains("факт") || low.contains("расскажи что") || low.contains("интересное"))
            return BrainReply(facts.random(), mapOf("mood" to "surprised", "anim" to "tilt"))
        if (Regex("молодец|умница|хороший|красав|лучший").containsMatchIn(low))
            return BrainReply("Мррр, приятно слышать!", mapOf("mood" to "happy", "anim" to "purr", "say" to "Мур!"))
        if (Regex("^(пока|до свидания|до встречи|увидимся)").containsMatchIn(low))
            return BrainReply("До встречи" + who + "! Я буду тут.", mapOf("mood" to "sleepy", "anim" to "wave_ears"))
        if (low.contains("погод"))
            return BrainReply("Погоду я без интернета не знаю. Открой приложение погоды, а я пока посижу рядом.")
        val q = low.endsWith("?") || Regex("^(что|кто|как|почему|где|когда|зачем|сколько|какой|какая|какое)\\b").containsMatchIn(low)
        if (q) return BrainReply("Хороший вопрос. Сам я без нейросети отвечаю только на то, что умею (напиши «помощь»). Подключи ИИ во вкладке «ИИ», и я смогу ответить на что угодно.", mapOf("mood" to "smug", "anim" to "tilt"))
        return BrainReply(Reactions.chat(raw), mapOf("mood" to "normal"))
    }

    // ---------- разбор экрана ----------

    private val stop = setOf("и", "в", "во", "на", "с", "со", "по", "к", "у", "о", "об", "от", "до", "за", "из", "для", "что", "как", "это", "не", "но", "а", "или",
        "же", "бы", "ли", "то", "так", "его", "её", "их", "мы", "вы", "я", "он", "она", "они", "the", "a", "an", "of", "to", "in", "and", "is", "for", "on", "with")

    fun explainScreen(text: String): String {
        val lines = text.lines().map { it.trim() }.filter { it.length > 1 }
        val sb = StringBuilder()

        val maths = lines.mapNotNull { solveMath(it) }.distinct().take(3)
        if (maths.isNotEmpty()) sb.append("Нашёл вычисления:\n").append(maths.joinToString("\n")).append("\n\n")

        val err = lines.firstOrNull { Regex("(?i)ошибк|error|exception|failed|не удалось|нет подключения|no internet|timeout|denied|отказано").containsMatchIn(it) }
        if (err != null) sb.append("Похоже на ошибку: «").append(err.take(90)).append("».\nПопробуй: проверить интернет, перезапустить приложение, обновить его или повторить позже.\n\n")

        val low = text.lowercase(ru)
        if (Regex("пароль|войти|вход|log in|sign in|password").containsMatchIn(low)) sb.append("Это экран входа. Проверь логин и пароль. Если забыл, ищи «Забыли пароль?».\n\n")
        else if (Regex("оплат|заплат|карт[аы]|к оплате|checkout|pay\\b|итого").containsMatchIn(low)) sb.append("Это оплата. Проверь сумму и получателя перед подтверждением.\n\n")
        else if (Regex("разреш|allow|доступ к|permission").containsMatchIn(low)) sb.append("Приложение просит разрешение. Давай его только если понимаешь, зачем оно нужно.\n\n")

        val sentences = text.split(Regex("(?<=[.!?])\\s+|\\n")).map { it.trim() }.filter { it.length in 25..220 }
        if (sentences.isNotEmpty()) {
            val freq = HashMap<String, Int>()
            for (s in sentences) for (w in Regex("[\\p{L}]{4,}").findAll(s.lowercase(ru))) if (w.value !in stop) freq[w.value] = (freq[w.value] ?: 0) + 1
            val scored = sentences.withIndex().map { (i, s) ->
                var sc = 0.0
                for (w in Regex("[\\p{L}]{4,}").findAll(s.lowercase(ru))) sc += (freq[w.value] ?: 0).toDouble()
                Triple(i, s, sc / sqrt(s.length.toDouble()))
            }.sortedByDescending { it.third }.take(2).sortedBy { it.first }
            sb.append("Главное:\n").append(scored.joinToString("\n") { "· " + it.second }).append("\n\n")
        } else if (lines.isNotEmpty() && maths.isEmpty() && err == null) {
            sb.append("На экране: ").append(lines.take(5).joinToString("; ") { it.take(40) }).append("\n\n")
        }

        val links = Regex("https?://\\S+|[\\w.+-]+@[\\w-]+\\.[\\w.]+|\\+?\\d[\\d\\s()-]{8,}\\d").findAll(text).map { it.value }.distinct().take(3).toList()
        if (links.isNotEmpty()) sb.append("Контакты и ссылки: ").append(links.joinToString(", ")).append("\n\n")

        val sums = Regex("\\d[\\d\\s]*(?:[.,]\\d+)?\\s*(?:₽|руб|\\$|€|usd|eur)").findAll(text).map { it.value.trim() }.distinct().take(3).toList()
        if (sums.isNotEmpty()) sb.append("Суммы: ").append(sums.joinToString(", ")).append("\n\n")

        if (sb.isEmpty()) return "Текста на экране мало, поэтому я мало что понял. Подключи ИИ во вкладке «ИИ», и я смогу разбирать задачи глубже."
        sb.append("Для глубокого разбора подключи ИИ во вкладке «ИИ».")
        return sb.toString().trim()
    }
}
