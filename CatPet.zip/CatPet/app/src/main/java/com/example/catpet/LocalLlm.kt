package com.example.catpet

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class LlmPreset(val id: String, val name: String, val note: String, val mb: Int, val url: String, val family: Int)

/** Клиент встроенной нейросети: общается со службой LlmService в отдельном процессе. Можно хранить несколько моделей и выбирать активную. */
object LocalLlm {
    private const val HF = "https://huggingface.co/litert-community/"
    val presets = listOf(
        LlmPreset("qwen05", "Qwen2.5 0,5B", "Самая лёгкая и быстрая. По-русски слабая, отвечает просто.", 550,
            HF + "Qwen2.5-0.5B-Instruct/resolve/main/Qwen2.5-0.5B-Instruct_multi-prefill-seq_q8_ekv1280.task", 1),
        LlmPreset("qwen15", "Qwen2.5 1,5B", "Заметно лучше и по-русски понятнее. Нужно 6 ГБ памяти или больше.", 1524,
            HF + "Qwen2.5-1.5B-Instruct/resolve/main/Qwen2.5-1.5B-Instruct_multi-prefill-seq_q8_ekv1280.task", 1),
        LlmPreset("phi4", "Phi-4 mini 3,8B", "Самая умная из открытых без входа на сайт. Нужно 8 ГБ памяти или больше, отвечает очень медленно.", 3940,
            HF + "Phi-4-mini-instruct/resolve/main/Phi-4-mini-instruct_multi-prefill-seq_q8_ekv1280.task", 2)
    )

    private var messenger: Messenger? = null
    private var connLatch = CountDownLatch(1)
    @Volatile private var latch: CountDownLatch? = null
    @Volatile private var result: Bundle? = null
    private val hist = ArrayList<Pair<String, String>>()

    private val replyMessenger = Messenger(Handler(Looper.getMainLooper()) { m ->
        result = m.data
        latch?.countDown()
        true
    })

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            messenger = Messenger(b)
            connLatch.countDown()
        }
        override fun onServiceDisconnected(n: ComponentName?) { messenger = null }
    }

    fun fileFor(c: Context, id: String): File {
        val dir = c.getExternalFilesDir(null) ?: c.filesDir
        return File(dir, if (id == "custom") "model.task" else "model_" + id + ".task")
    }

    fun activeId(c: Context): String {
        val v = Prefs.s(c, "llm_model")
        return if (v.isEmpty()) "custom" else v
    }

    fun modelFile(c: Context): File = fileFor(c, activeId(c))

    fun installed(c: Context, id: String): Boolean {
        val f = fileFor(c, id)
        return f.exists() && f.length() > 50_000_000L
    }

    /** Делает модель активной и подставляет её настройки. */
    fun activate(c: Context, id: String) {
        Prefs.putS(c, "llm_model", id)
        val p = presets.firstOrNull { it.id == id }
        if (p != null) { Prefs.putI(c, "llm_family", p.family); Prefs.putI(c, "llm_ctx", 1280) }
        Prefs.putB(c, "llm_on", true)
        synchronized(hist) { hist.clear() }
    }

    fun ready(c: Context): Boolean = Prefs.b(c, "llm_on") && installed(c, activeId(c))

    @Synchronized
    private fun ask(c: Context, prompt: String): String {
        val app = c.applicationContext
        if (messenger == null) {
            val cl = CountDownLatch(1)
            connLatch = cl
            app.bindService(Intent(app, LlmService::class.java), conn, Context.BIND_AUTO_CREATE)
            if (!cl.await(8, TimeUnit.SECONDS)) throw IllegalStateException("Не запустилась служба нейросети")
        }
        val l = CountDownLatch(1)
        latch = l
        result = null
        val m = Message.obtain(null, 1)
        val b = Bundle()
        b.putString("path", modelFile(app).absolutePath)
        b.putString("prompt", prompt)
        b.putInt("ctx", Prefs.i(app, "llm_ctx"))
        m.data = b
        m.replyTo = replyMessenger
        messenger!!.send(m)
        if (!l.await(300, TimeUnit.SECONDS)) {
            messenger = null
            throw IllegalStateException("Нейросеть не ответила. Скорее всего, телефону не хватило памяти: возьми модель поменьше.")
        }
        val r = result ?: throw IllegalStateException("Пустой ответ нейросети")
        val err = r.getString("error")
        if (err != null) throw IllegalStateException("Ошибка нейросети: " + err)
        return r.getString("text") ?: ""
    }

    private fun clean(s: String): String =
        s.replace("<end_of_turn>", "").replace("<|im_end|>", "").replace("<|end|>", "").replace("<start_of_turn>model", "")
            .replace("<|endoftext|>", "").trim()

    fun screenPrompt(screen: String): String =
        "Вот текст с экрана телефона:\n---\n" + screen.take(1200) + "\n---\nОпредели, какая тут задача, и коротко объясни, как её решить."

    /** Короткая подсказка без служебных тегов: маленькие модели с ними путаются. */
    private fun sys(c: Context): String {
        val name = Prefs.s(c, "brain_name")
        return "Ты Кики, дружелюбный ИИ-помощник на экране телефона. Отвечай по-русски, коротко, простыми словами и по делу. Если не знаешь ответа, так и скажи." +
            (if (name.isNotEmpty()) " Пользователя зовут " + name + "." else "")
    }

    /** Ответ нейросети на сообщение с учётом короткой истории разговора. */
    fun chat(c: Context, user: String): String {
        val s = sys(c)
        val family = Prefs.i(c, "llm_family")
        val h = synchronized(hist) { ArrayList(hist) }
        val sb = StringBuilder()
        when (family) {
            1 -> {
                sb.append("<|im_start|>system\n").append(s).append("<|im_end|>\n")
                for (p in h) sb.append("<|im_start|>user\n").append(p.first).append("<|im_end|>\n<|im_start|>assistant\n").append(p.second).append("<|im_end|>\n")
                sb.append("<|im_start|>user\n").append(user).append("<|im_end|>\n<|im_start|>assistant\n")
            }
            2 -> {
                sb.append("<|system|>").append(s).append("<|end|>")
                for (p in h) sb.append("<|user|>").append(p.first).append("<|end|><|assistant|>").append(p.second).append("<|end|>")
                sb.append("<|user|>").append(user).append("<|end|><|assistant|>")
            }
            else -> {
                var first = true
                for (p in h) {
                    sb.append("<start_of_turn>user\n").append(if (first) s + "\n\n" else "").append(p.first)
                        .append("<end_of_turn>\n<start_of_turn>model\n").append(p.second).append("<end_of_turn>\n")
                    first = false
                }
                sb.append("<start_of_turn>user\n").append(if (first) s + "\n\n" else "").append(user).append("<end_of_turn>\n<start_of_turn>model\n")
            }
        }
        val out = clean(ask(c, sb.toString()))
        synchronized(hist) {
            hist.add(Pair(user.take(300), out.take(600)))
            while (hist.size > 3) hist.removeAt(0)
        }
        return out
    }
}
