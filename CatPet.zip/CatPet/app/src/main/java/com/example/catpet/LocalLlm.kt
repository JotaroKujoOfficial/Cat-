package com.example.catpet

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Клиент встроенной нейросети: общается со службой LlmService в отдельном процессе. */
object LocalLlm {
    private var messenger: Messenger? = null
    private var connLatch = CountDownLatch(1)
    @Volatile private var latch: CountDownLatch? = null
    @Volatile private var result: Bundle? = null
    private val hist = ArrayList<Pair<String, String>>()

    private val replyMessenger = Messenger(Handler(Looper.getMainLooper()) { m ->
        result = m.data
        latch?.countDown()
        true
    })

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName?, b: IBinder?) {
            messenger = Messenger(b)
            connLatch.countDown()
        }
        override fun onServiceDisconnected(n: ComponentName?) { messenger = null }
    }

    fun modelFile(c: Context): File = File(c.getExternalFilesDir(null) ?: c.filesDir, "model.task")

    fun ready(c: Context): Boolean {
        val f = modelFile(c)
        return Prefs.b(c, "llm_on") && f.exists() && f.length() > 50_000_000L
    }

    @Synchronized
    private fun ask(c: Context, prompt: String): String {
        val app = c.applicationContext
        if (messenger == null) {
            val cl = CountDownLatch(1)
            connLatch = cl
            app.bindService(Intent(app, LlmService::class.java), conn, Context.BIND_AUTO_CREATE)
            if (!cl.await(8, TimeUnit.SECONDS)) throw IllegalStateException("Не запустилась служба нейросети")
        }
        val l = CountDownLatch(1)
        latch = l
        result = null
        val m = Message.obtain(null, 1)
        val b = Bundle()
        b.putString("path", modelFile(app).absolutePath)
        b.putString("prompt", prompt)
        b.putInt("ctx", Prefs.i(app, "llm_ctx"))
        m.data = b
        m.replyTo = replyMessenger
        messenger!!.send(m)
        if (!l.await(240, TimeUnit.SECONDS)) {
            messenger = null
            throw IllegalStateException("Нейросеть не ответила. Скорее всего, телефону не хватило памяти: возьми модель поменьше.")
        }
        val r = result ?: throw IllegalStateException("Пустой ответ нейросети")
        val err = r.getString("error")
        if (err != null) throw IllegalStateException("Ошибка нейросети: " + err)
        return r.getString("text") ?: ""
    }

    private fun clean(s: String): String =
        s.replace("<end_of_turn>", "").replace("<|im_end|>", "").replace("<start_of_turn>model", "").trim()

    fun screenPrompt(screen: String): String =
        "Вот текст с экрана телефона:\n---\n" + screen.take(1200) + "\n---\nОпредели, какая тут задача, и коротко объясни, как её решить."

    /** Ответ нейросети на сообщение с учётом короткой истории разговора. */
    fun chat(c: Context, user: String): String {
        val sys = Ai.system(c)
        val qwen = Prefs.i(c, "llm_family") == 1
        val sb = StringBuilder()
        if (qwen) {
            sb.append("<|im_start|>system\n").append(sys).append("<|im_end|>\n")
            for (p in hist) sb.append("<|im_start|>user\n").append(p.first).append("<|im_end|>\n<|im_start|>assistant\n").append(p.second).append("<|im_end|>\n")
            sb.append("<|im_start|>user\n").append(user).append("<|im_end|>\n<|im_start|>assistant\n")
        } else {
            var first = true
            for (p in hist) {
                sb.append("<start_of_turn>user\n").append(if (first) sys + "\n\n" else "").append(p.first)
                    .append("<end_of_turn>\n<start_of_turn>model\n").append(p.second).append("<end_of_turn>\n")
                first = false
            }
            sb.append("<start_of_turn>user\n").append(if (first) sys + "\n\n" else "").append(user).append("<end_of_turn>\n<start_of_turn>model\n")
        }
        val out = clean(ask(c, sb.toString()))
        hist.add(Pair(user.take(300), out.take(600)))
        while (hist.size > 3) hist.removeAt(0)
        return out
    }
}
