package com.example.catpet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View

/** Выделение области пальцем: просто светящаяся линия, без рамки. Область внутри линии подсвечивается мягко. */
class RegionPicker(c: Context, private val shot: Bitmap?, private val onDone: (Rect?, Int, Int) -> Unit) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val orange = Color.parseColor("#FF5A1F")
    private val dim = Paint().apply { color = Color.argb(96, 4, 5, 9) }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(30, 255, 90, 31) }
    private val glowA = pen(20f, orange)
    private val glowB = pen(11f, orange)
    private val core = pen(4.5f, orange)
    private val hot = pen(1.7f, Color.parseColor("#FFE6D6"))
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E8ECF4"); textSize = 15f * d; textAlign = Paint.Align.CENTER
    }
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(225, 11, 13, 20) }
    private val path = Path()
    private val closed = Path()
    private val cancel = RectF()
    private val dst = Rect()
    private var minX = 0f
    private var maxX = 0f
    private var minY = 0f
    private var maxY = 0f
    private var drawing = false
    private var has = false
    private var doneAt = 0L
    private var result: Rect? = null
    private var fired = false

    private fun pen(w: Float, col: Int): Paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = w * d; color = col
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (shot != null) {
            dst.set(0, 0, width, height)
            cv.drawBitmap(shot, null, dst, null)
        }
        cv.drawRect(0f, 0f, w, h, dim)
        var k = 1f
        if (doneAt != 0L) {
            val t = ((SystemClock.uptimeMillis() - doneAt) / 420f).coerceIn(0f, 1f)
            k = 1f - 0.55f * t
            if (t >= 1f && !fired) {
                fired = true
                val r = result
                post { onDone(r, width, height) }
            } else if (!fired) postInvalidateOnAnimation()
        }
        if (has) {
            closed.set(path)
            closed.close()
            cv.drawPath(closed, fillP)
            glowA.alpha = (34 * k).toInt()
            glowB.alpha = (84 * k).toInt()
            core.alpha = (255 * k).toInt()
            cv.drawPath(path, glowA)
            cv.drawPath(path, glowB)
            cv.drawPath(path, core)
            cv.drawPath(path, hot)
        } else {
            cv.drawText("Обведи пальцем то, на что нужно посмотреть", w / 2f, 90f * d, text)
        }
        cancel.set(w / 2f - 70f * d, h - 110f * d, w / 2f + 70f * d, h - 60f * d)
        cv.drawRoundRect(cancel, 25f * d, 25f * d, pill)
        cv.drawText("Отмена", w / 2f, cancel.centerY() + 5.5f * d, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (doneAt != 0L) return true
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                if (cancel.contains(e.x, e.y)) { onDone(null, width, height); return true }
                path.reset()
                path.moveTo(e.x, e.y)
                minX = e.x; maxX = e.x; minY = e.y; maxY = e.y
                drawing = true
                has = true
            }
            MotionEvent.ACTION_MOVE -> if (drawing) {
                path.lineTo(e.x, e.y)
                minX = minOf(minX, e.x); maxX = maxOf(maxX, e.x)
                minY = minOf(minY, e.y); maxY = maxOf(maxY, e.y)
            }
            MotionEvent.ACTION_UP -> if (drawing) {
                drawing = false
                val pad = 14f * d
                val r = Rect((minX - pad).toInt().coerceAtLeast(0), (minY - pad).toInt().coerceAtLeast(0),
                    (maxX + pad).toInt().coerceAtMost(width), (maxY + pad).toInt().coerceAtMost(height))
                if (r.width() < 40 * d || r.height() < 40 * d) {
                    has = false
                    path.reset()
                } else {
                    result = r
                    doneAt = SystemClock.uptimeMillis()
                }
            }
            MotionEvent.ACTION_CANCEL -> { drawing = false; has = false; path.reset() }
            else -> {}
        }
        invalidate()
        return true
    }
}
