package com.example.catpet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View

/** Выделение области пальцем, как «Обведи для поиска»: замороженный снимок экрана, затемнение и оранжевый контур. */
class RegionPicker(c: Context, private val shot: Bitmap?, private val onDone: (Rect?) -> Unit) : View(c) {
    private val d = c.resources.displayMetrics.density
    private val dim = Paint().apply { color = Color.argb(140, 0, 0, 0) }
    private val hole = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3f * d; color = Color.parseColor("#ED4A1D")
        strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val box = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.WHITE }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 15f * d; textAlign = Paint.Align.CENTER }
    private val pill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(225, 15, 14, 17) }
    private val path = Path()
    private val cancel = RectF()
    private val dst = Rect()
    private var minX = 0f
    private var maxX = 0f
    private var minY = 0f
    private var maxY = 0f
    private var drawing = false
    private var has = false

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (shot != null) {
            dst.set(0, 0, width, height)
            cv.drawBitmap(shot, null, dst, null)
        }
        val layer = cv.saveLayer(0f, 0f, w, h, null)
        cv.drawRect(0f, 0f, w, h, dim)
        if (has) cv.drawRect(minX, minY, maxX, maxY, hole)
        cv.restoreToCount(layer)
        if (has) {
            cv.drawRect(minX, minY, maxX, maxY, box)
            cv.drawPath(path, stroke)
        } else {
            cv.drawText("Обведи то, на что нужно посмотреть", w / 2f, 90f * d, text)
        }
        cancel.set(w / 2f - 70f * d, h - 110f * d, w / 2f + 70f * d, h - 60f * d)
        cv.drawRoundRect(cancel, 25f * d, 25f * d, pill)
        cv.drawText("Отмена", w / 2f, cancel.centerY() + 5.5f * d, text)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                if (cancel.contains(e.x, e.y)) { onDone(null); return true }
                path.reset()
                path.moveTo(e.x, e.y)
                minX = e.x; maxX = e.x; minY = e.y; maxY = e.y
                drawing = true
                has = true
            }
            MotionEvent.ACTION_MOVE -> if (drawing) {
                path.lineTo(e.x, e.y)
                minX = minOf(minX, e.x); maxX = maxOf(maxX, e.x)
                minY = minOf(minY, e.y); maxY = maxOf(maxY, e.y)
            }
            MotionEvent.ACTION_UP -> if (drawing) {
                drawing = false
                val pad = 10f * d
                val r = Rect((minX - pad).toInt().coerceAtLeast(0), (minY - pad).toInt().coerceAtLeast(0),
                    (maxX + pad).toInt().coerceAtMost(width), (maxY + pad).toInt().coerceAtMost(height))
                if (r.width() < 40 * d || r.height() < 40 * d) { has = false; path.reset() } else onDone(r)
            }
            MotionEvent.ACTION_CANCEL -> { drawing = false; has = false }
            else -> {}
        }
        invalidate()
        return true
    }
}
