package com.example.catpet

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Чат с котиком. Ответы даёт Claude через Anthropic API. */
class ChatActivity : Activity() {
    companion object {
        val history = JSONArray()
        const val SYSTEM = "Ты озорной чёрный котик-помощник, который живёт на экране телефона пользователя. " +
            "Отвечай по-русски, коротко (1–3 предложения), тепло и с юмором, иногда мяукай. " +
            "Помогай по существу, если просят."
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val p = (16 * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(p, p, p, p); setBackgroundColor(Color.parseColor("#0B0B0B"))
        }
        val log = TextView(this).apply { setTextColor(Color.WHITE); textSize = 16f }
        val scroll = ScrollView(this).apply { addView(log) }
        val input = EditText(this).apply { hint = "Скажи котику…"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        val send = Button(this).apply { text = "Отправить"; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#FF4A1C")) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(input, LinearLayout.LayoutParams(-1, -2))
        root.addView(send, LinearLayout.LayoutParams(-1, -2))
        setContentView(root)

        for (i in 0 until history.length()) {
            val m = history.getJSONObject(i)
            log.append((if (m.getString("role") == "user") "Ты: " else "Котик: ") + m.getString("content") + "\n\n")
        }

        send.setOnClickListener {
            val text = input.text.toString().trim()
            val key = getSharedPreferences("cat", MODE_PRIVATE).getString("key", "") ?: ""
            if (text.isEmpty()) return@setOnClickListener
            if (key.isEmpty()) { log.append("Котик: добавь ключ API в приложении.\n\n"); return@setOnClickListener }
            input.setText(""); log.append("Ты: $text\n\n"); send.isEnabled = false
            Thread {
                val reply = try { ask(key, text) } catch (e: Exception) { "Мяу, ошибка: ${e.message}" }
                runOnUiThread {
                    log.append("Котик: $reply\n\n"); send.isEnabled = true
                    scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
                }
            }.start()
        }
    }

    private fun ask(key: String, text: String): String {
        history.put(JSONObject().put("role", "user").put("content", text))
        val body = JSONObject().put("model", "claude-sonnet-5-5").put("max_tokens", 400)
            .put("system", SYSTEM).put("messages", history)
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15000; c.readTimeout = 60000
        c.setRequestProperty("x-api-key", key)
        c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode in 200..299
        val resp = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) { history.remove(history.length() - 1); throw RuntimeException("API ${c.responseCode}") }
        val reply = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        history.put(JSONObject().put("role", "assistant").put("content", reply))
        return reply
    }
}
