package com.example.catpet

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/** Чат с Кики. Если пришёл текст экрана, Кики сразу разбирает задачу. */
class ChatActivity : Activity() {
    private val history = JSONArray()
    private lateinit var log: TextView
    private lateinit var scroll: ScrollView
    private lateinit var send: Button
    private var screenCtx: String? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val p = (16 * d).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(p, p, p, p)
        root.setBackgroundColor(Color.parseColor("#0B0B0B"))

        val title = TextView(this)
        title.text = "КИКИ"
        title.typeface = Typeface.MONOSPACE
        title.textSize = 14f
        title.setTextColor(Color.parseColor("#FF4A1C"))
        root.addView(title)

        log = TextView(this)
        log.setTextColor(Color.WHITE)
        log.textSize = 16f
        scroll = ScrollView(this)
        scroll.addView(log)
        root.addView(scroll, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))

        val input = EditText(this)
        input.hint = "Скажи Кики…"
        input.setTextColor(Color.WHITE)
        input.setHintTextColor(Color.GRAY)
        root.addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        send = Button(this)
        send.text = "Отправить"
        send.setTextColor(Color.WHITE)
        send.setBackgroundColor(Color.parseColor("#FF4A1C"))
        root.addView(send, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        setContentView(root)

        send.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isNotEmpty()) {
                input.setText("")
                submit(text, text)
            }
        }

        val sc = intent.getStringExtra("screen")
        screenCtx = sc
        if (sc != null) {
            submit("Разбери задачу на моём экране",
                "Вот текст с моего экрана:\n---\n" + sc + "\n---\nОпредели, какая тут задача, и коротко объясни, как её решить.")
        } else {
            input.requestFocus()
        }
    }

    private fun submit(shown: String, real: String) {
        log.append("Ты: " + shown + "\n\n")
        send.isEnabled = false
        val c = applicationContext
        val useAi = Ai.ready(c)
        val sc = screenCtx
        if (useAi) history.put(JSONObject().put("role", "user").put("content", real))
        Thread {
            val reply = try {
                if (useAi) {
                    Ai.ask(c, history)
                } else if (sc != null && shown.startsWith("Разбери")) {
                    "Мрр, чтобы разбирать задачи, мне нужен ИИ: добавь ключ в настройках. А пока вот что я вижу на экране:\n" + sc.take(300)
                } else {
                    Reactions.chat(real)
                }
            } catch (e: Exception) {
                "Мяу, ошибка: " + (e.message ?: "неизвестно")
            }
            runOnUiThread {
                if (useAi) {
                    if (reply.startsWith("Мяу, ошибка")) {
                        history.remove(history.length() - 1)
                    } else {
                        history.put(JSONObject().put("role", "assistant").put("content", reply))
                    }
                    while (history.length() > 12) { history.remove(0); history.remove(0) }
                }
                log.append("Кики: " + reply + "\n\n")
                send.isEnabled = true
                scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
            }
        }.start()
    }
}
