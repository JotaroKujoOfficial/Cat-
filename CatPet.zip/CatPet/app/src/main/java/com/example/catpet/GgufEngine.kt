package com.example.catpet

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.launch
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Движок llama.cpp (как в PocketPal): запускает модели формата GGUF. Работает внутри процесса :llm. */
object GgufEngine {
    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val flow = MutableSharedFlow<LlamaHelper.LLMEvent>(
        replay = 0, extraBufferCapacity = 256, onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    private var helper: LlamaHelper? = null
    private var loadedPath = ""
    private var loadedCtx = 0

    @Synchronized
    fun ask(c: Context, path: String, prompt: String, ctx: Int): String {
        var h = helper
        if (h == null) {
            h = LlamaHelper(contentResolver = c.contentResolver, scope = scope, sharedFlow = flow)
            helper = h
        }
        if (path != loadedPath || ctx != loadedCtx) {
            if (loadedPath.isNotEmpty()) { try { h.release() } catch (_: Throwable) {} ; h = LlamaHelper(contentResolver = c.contentResolver, scope = scope, sharedFlow = flow); helper = h }
            val l = CountDownLatch(1)
            h.load(path = Uri.fromFile(File(path)).toString(), contextLength = ctx) { l.countDown() }
            if (!l.await(180, TimeUnit.SECONDS)) throw IllegalStateException("Модель не загрузилась за 3 минуты")
            loadedPath = path
            loadedCtx = ctx
        }
        val sb = StringBuilder()
        val done = CountDownLatch(1)
        var err: String? = null
        val job = scope.launch(start = CoroutineStart.UNDISPATCHED) {
            flow.collect { e ->
                when (e) {
                    is LlamaHelper.LLMEvent.Ongoing -> sb.append(e.word)
                    is LlamaHelper.LLMEvent.Done -> done.countDown()
                    is LlamaHelper.LLMEvent.Error -> { err = e.message; done.countDown() }
                    else -> {}
                }
            }
        }
        h.predict(prompt)
        val ok = done.await(280, TimeUnit.SECONDS)
        try { h.stopPrediction() } catch (_: Throwable) {}
        job.cancel()
        if (!ok) throw IllegalStateException("Нейросеть не успела ответить")
        if (err != null && sb.isEmpty()) throw IllegalStateException(err)
        return sb.toString()
    }
}
