package com.example.catpet

/** Форма Кики: набор слоёв и их положение на холсте. Слои плоские, цвета накладываются при рисовании. */
class ArtSpec(val prefix: String, val name: String, val cw: Float, val ch: Float, val rects: Map<String, FloatArray>) {
    /** Сколько единиц холста остаётся под телом: нужно, чтобы Кики стоял ногами на поверхности. */
    fun feetPad(): Float {
        val b = rects["body"] ?: return 0f
        return ch - (b[1] + b[3])
    }
}

object Arts {
    val specs: List<ArtSpec> = listOf(
        ArtSpec("cat", "Классика", 566f, 539f, mapOf(
            "body" to floatArrayOf(23f, 23f, 521f, 494f),
            "ear_l" to floatArrayOf(64f, 52f, 95f, 167f),
            "ear_r" to floatArrayOf(407f, 52f, 95f, 168f),
            "eye_l" to floatArrayOf(65f, 200f, 201f, 131f),
            "eye_r" to floatArrayOf(301f, 200f, 193f, 131f),
            "pupil_l" to floatArrayOf(103f, 233f, 132f, 61f),
            "pupil_r" to floatArrayOf(320f, 233f, 132f, 61f),
            "nose" to floatArrayOf(260f, 293f, 45f, 31f),
            "mouth" to floatArrayOf(146f, 320f, 274f, 83f)
        )),
        ArtSpec("a1", "Гладкий", 591f, 563f, mapOf(
            "outline" to floatArrayOf(23f, 23f, 546f, 518f),
            "body" to floatArrayOf(29f, 29f, 534f, 506f),
            "ear_l" to floatArrayOf(71f, 59f, 98f, 172f),
            "ear_r" to floatArrayOf(423f, 59f, 98f, 172f),
            "eye_l" to floatArrayOf(88f, 242f, 166f, 97f),
            "eye_r" to floatArrayOf(337f, 242f, 166f, 97f),
            "mouth" to floatArrayOf(148f, 306f, 297f, 92f)
        )),
        ArtSpec("a2", "Хмурый", 591f, 563f, mapOf(
            "outline" to floatArrayOf(23f, 23f, 546f, 518f),
            "body" to floatArrayOf(29f, 29f, 534f, 506f),
            "ear_l" to floatArrayOf(71f, 59f, 98f, 172f),
            "ear_r" to floatArrayOf(423f, 59f, 98f, 172f),
            "eye_l" to floatArrayOf(105f, 255f, 149f, 90f),
            "pupil_l" to floatArrayOf(169f, 271f, 39f, 49f),
            "eye_r" to floatArrayOf(337f, 255f, 150f, 90f),
            "pupil_r" to floatArrayOf(385f, 271f, 38f, 49f),
            "mouth" to floatArrayOf(242f, 332f, 108f, 94f)
        )),
        ArtSpec("a3", "Геометрия", 562f, 599f, mapOf(
            "body" to floatArrayOf(23f, 23f, 516f, 554f),
            "eye_l" to floatArrayOf(79f, 278f, 160f, 97f),
            "eye_r" to floatArrayOf(323f, 278f, 159f, 98f),
            "nose" to floatArrayOf(243f, 346f, 76f, 48f)
        )),
        ArtSpec("a4", "Геометрия II", 561f, 599f, mapOf(
            "body" to floatArrayOf(23f, 23f, 516f, 554f),
            "eye_l" to floatArrayOf(79f, 279f, 160f, 97f),
            "pupil_l" to floatArrayOf(149f, 298f, 32f, 47f),
            "eye_r" to floatArrayOf(323f, 278f, 160f, 98f),
            "pupil_r" to floatArrayOf(381f, 297f, 32f, 47f),
            "nose" to floatArrayOf(243f, 346f, 76f, 48f)
        )),
        ArtSpec("a5", "Милаш", 620f, 640f, mapOf(
            "outline" to floatArrayOf(20f, 84f, 580f, 536f),
            "body" to floatArrayOf(35f, 98f, 550f, 507f),
            "ear_l" to floatArrayOf(108f, 153f, 104f, 106f),
            "ear_r" to floatArrayOf(408f, 153f, 104f, 106f),
            "eye_l" to floatArrayOf(117f, 290f, 166f, 190f),
            "eye_r" to floatArrayOf(337f, 290f, 166f, 190f),
            "pupil_l" to floatArrayOf(153f, 331f, 106f, 134f),
            "pupil_r" to floatArrayOf(373f, 331f, 106f, 134f),
            "shine_l" to floatArrayOf(153f, 331f, 106f, 134f),
            "shine_r" to floatArrayOf(373f, 331f, 106f, 134f),
            "blush_l" to floatArrayOf(73f, 428f, 90f, 54f),
            "blush_r" to floatArrayOf(457f, 428f, 90f, 54f),
            "nose" to floatArrayOf(289f, 426f, 43f, 31f),
            "mouth" to floatArrayOf(259f, 448f, 102f, 40f),
            "pawo_l" to floatArrayOf(91f, 487f, 128f, 152f),
            "pawo_r" to floatArrayOf(401f, 487f, 128f, 152f),
            "paw_l" to floatArrayOf(102f, 497f, 106f, 131f),
            "paw_r" to floatArrayOf(412f, 497f, 106f, 131f),
            "pad_l" to floatArrayOf(119f, 529f, 72f, 78f),
            "pad_r" to floatArrayOf(429f, 529f, 72f, 78f)
        ))
    )

    fun spec(i: Int): ArtSpec = specs[i.coerceIn(0, specs.size - 1)]
}
