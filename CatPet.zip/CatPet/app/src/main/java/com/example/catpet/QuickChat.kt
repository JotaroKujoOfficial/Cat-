package com.example.catpet

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject

/** Маленький плавающий чат с Кики. Не закрывает экран: компактная карточка сверху. */
class QuickChat(private val svc: CatService, private val wm: WindowManager) {
    private class Panel(c: Context, val onBack: () -> Unit) : FrameLayout(c) {
        override fun dispatchKeyEvent(e: KeyEvent): Boolean {
            if (e.keyCode == KeyEvent.KEYCODE_BACK) {
                if (e.action == KeyEvent.ACTION_UP) onBack()
                return true
            }
            return super.dispatchKeyEvent(e)
        }
    }

    private var panel: Panel? = null
    private var log: LinearLayout? = null
    private var scroll: ScrollView? = null
    private var input: EditText? = null
    private val history = JSONArray()
    private var busy = false

    private val ORANGE = Color.parseColor("#ED4A1D")
    private val CARD = Color.parseColor("#0F0E11")

    fun isOpen(): Boolean = panel != null

    private fun shape(color: Int, stroke: Int, r: Float, d: Float): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = r * d
        if (stroke != 0) g.setStroke((d).toInt().coerceAtLeast(1), stroke)
        return g
    }

    fun open(focusInput: Boolean, screenText: String?) {
        if (panel != null) {
            if (screenText != null) explain(screenText)
            return
        }
        val c: Context = svc
        val d = c.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * d).toInt()

        val root = Panel(c) { close() }
        val card = LinearLayout(c)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(12))
        card.background = shape(CARD, Color.parseColor("#2A2A2F"), 16f, d)

        val head = LinearLayout(c)
        head.gravity = Gravity.CENTER_VERTICAL
        val title = TextView(c)
        title.text = "●  КИКИ"
        title.textSize = 11f
        title.typeface = Typeface.MONOSPACE
        title.setTextColor(ORANGE)
        head.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val gear = TextView(c)
        gear.text = "⚙"
        gear.textSize = 18f
        gear.setTextColor(Color.parseColor("#9A9AA2"))
        gear.setPadding(dp(10), dp(4), dp(10), dp(4))
        gear.setOnClickListener { svc.openApp() }
        head.addView(gear)
        val x = TextView(c)
        x.text = "✕"
        x.textSize = 17f
        x.setTextColor(Color.parseColor("#9A9AA2"))
        x.setPadding(dp(10), dp(4), dp(6), dp(4))
        x.setOnClickListener { close() }
        head.addView(x)
        card.addView(head)

        val lg = LinearLayout(c)
        lg.orientation = LinearLayout.VERTICAL
        val sc = ScrollView(c)
        sc.addView(lg)
        card.addView(sc, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(190)))
        log = lg
        scroll = sc

        val chip = TextView(c)
        chip.text = "🧠  Разобрать задачу с экрана"
        chip.textSize = 12f
        chip.setTextColor(Color.WHITE)
        chip.setPadding(dp(12), dp(7), dp(12), dp(7))
        chip.background = shape(Color.parseColor("#1B1A1F"), Color.parseColor("#2A2A2F"), 14f, d)
        chip.setOnClickListener { svc.runExplain() }
        val chipLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        chipLp.topMargin = dp(8)
        card.addView(chip, chipLp)

        val row = LinearLayout(c)
        row.gravity = Gravity.CENTER_VERTICAL
        val et = EditText(c)
        et.hint = "Спросить Кики…"
        et.setHintTextColor(Color.parseColor("#6A6A72"))
        et.setTextColor(Color.WHITE)
        et.textSize = 14f
        et.setSingleLine(true)
        et.imeOptions = EditorInfo.IME_ACTION_SEND
        et.setPadding(dp(12), dp(8), dp(12), dp(8))
        et.background = shape(Color.parseColor("#09090B"), Color.parseColor("#2A2A2F"), 12f, d)
        et.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { send(); true } else false
        }
        row.addView(et, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val go = TextView(c)
        go.text = "➤"
        go.textSize = 16f
        go.gravity = Gravity.CENTER
        go.setTextColor(Color.WHITE)
        val gb = GradientDrawable()
        gb.shape = GradientDrawable.OVAL
        gb.setColor(ORANGE)
        go.background = gb
        go.setOnClickListener { send() }
        val goLp = LinearLayout.LayoutParams(dp(40), dp(40))
        goLp.leftMargin = dp(8)
        row.addView(go, goLp)
        val rowLp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        rowLp.topMargin = dp(8)
        card.addView(row, rowLp)
        input = et

        root.addView(card)
        val w = minOf(svc.screenWidthPx() - dp(24), dp(420))
        val p = WindowManager.LayoutParams(w, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT)
        p.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        p.y = dp(56)
        p.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING
        wm.addView(root, p)
        panel = root

        addMsg("Привет! Я Кики. Спрашивай или нажми «Разобрать задачу».", false)
        if (!Ai.ready(c)) addMsg("Сейчас я отвечаю попроще. Подключи ИИ в приложении (вкладка «ИИ»), и я стану умнее.", false)
        if (focusInput) {
            et.requestFocus()
            root.postDelayed({
                val imm = c.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT)
            }, 250)
        }
        if (screenText != null) explain(screenText)
    }

    fun close() {
        val p = panel ?: return
        try {
            val imm = svc.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(p.windowToken, 0)
        } catch (_: Exception) {}
        try { wm.removeView(p) } catch (_: Exception) {}
        panel = null
        log = null
        scroll = null
        input = null
    }

    private fun addMsg(text: String, mine: Boolean): TextView? {
        val lg = log ?: return null
        val c: Context = svc
        val d = c.resources.displayMetrics.density
        val tv = TextView(c)
        tv.text = text
        tv.textSize = 14f
        tv.setTextColor(Color.WHITE)
        tv.setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
        tv.background = shape(if (mine) ORANGE else Color.parseColor("#1B1A1F"), 0, 14f, d)
        tv.maxWidth = (svc.screenWidthPx() * 0.72f).toInt()
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = (6 * d).toInt()
        lp.gravity = if (mine) Gravity.END else Gravity.START
        lg.addView(tv, lp)
        scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
        return tv
    }

    private fun send() {
        val et = input ?: return
        val t = et.text.toString().trim()
        if (t.isEmpty() || busy) return
        et.setText("")
        submit(t, t, false)
    }

    private fun explain(screen: String) {
        submit("Разобрать задачу с экрана",
            "Вот текст с моего экрана:\n---\n" + screen + "\n---\nОпредели, какая тут задача, и коротко объясни, как её решить.", true)
    }

    private fun submit(shown: String, real: String, isScreen: Boolean) {
        if (busy) return
        addMsg(shown, true)
        val bubble = addMsg("…", false)
        busy = true
        val c = svc.applicationContext
        val useAi = Ai.ready(c)
        if (useAi) history.put(JSONObject().put("role", "user").put("content", real))
        Thread {
            val failed: Boolean
            val reply: String
            var r = ""
            var f = false
            try {
                r = if (useAi) Ai.ask(c, history)
                else if (isScreen) "Мрр, чтобы разбирать задачи, мне нужен ИИ: подключи его во вкладке «ИИ». Без него я только болтаю."
                else Reactions.chat(real)
            } catch (e: Exception) {
                f = true
                r = e.message ?: "Что-то пошло не так."
            }
            failed = f
            val parsed = if (useAi && !f) Control.parse(r) else Pair(r, emptyMap<String, String>())
            reply = if (parsed.first.isBlank()) "…" else parsed.first
            val dirs = parsed.second
            val view = panel
            view?.post {
                if (useAi) {
                    if (failed) {
                        history.remove(history.length() - 1)
                    } else {
                        history.put(JSONObject().put("role", "assistant").put("content", reply))
                    }
                    while (history.length() > 12) { history.remove(0); history.remove(0) }
                }
                if (bubble != null) bubble.text = reply
                if (!failed && dirs.isNotEmpty()) svc.applyDirectives(dirs)
                busy = false
                scroll?.post { scroll?.fullScroll(View.FOCUS_DOWN) }
            }
            if (view == null) busy = false
        }.start()
    }
}
