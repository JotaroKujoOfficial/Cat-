package com.example.catpet

import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.abs
import kotlin.math.sin

/** Чёрный «жидкий» котик: тело пружинит, глаза следят, настроение меняет мордочку. */
class CatView(c: Context) : View(c) {
    var lookX = 0f
    var lookY = 0f
    var mood = 0            // 0 обычный, 1 доволен, 2 удивлён
    var walkPhase = 0f

    private var squash = 0f
    private var squashV = 0f
    private var t = 0f
    private var frames = 0

    private val black = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val whiteLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }
    private val blackLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK; style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND
    }

    fun poke(s: Float) { squashV += s }

    fun step() {
        t += 0.05f
        frames++
        squashV += -squash * 0.22f
        squashV *= 0.86f
        squash += squashV
        invalidate()
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        whiteLine.strokeWidth = w * 0.022f
        blackLine.strokeWidth = w * 0.03f
        val blink = if (frames % 200 < 6) 0.1f else 1f
        val wob = sin(t * 2) * h * 0.01f

        cv.save()
        cv.translate(0f, -abs(sin(walkPhase)) * h * 0.03f)
        cv.scale(1f + squash * 0.3f, 1f - squash * 0.3f, w / 2, h * 0.95f)

        // уши
        for (side in intArrayOf(-1, 1)) {
            val cx = w / 2 + side * w * 0.27f
            val ear = Path().apply {
                moveTo(cx - w * 0.12f, h * 0.42f); lineTo(cx + side * w * 0.03f, h * 0.08f + wob)
                lineTo(cx + w * 0.12f, h * 0.42f); close()
            }
            cv.drawPath(ear, black)
            val inner = Path().apply {
                moveTo(cx - w * 0.07f, h * 0.40f); lineTo(cx + side * w * 0.03f, h * 0.17f + wob)
                lineTo(cx + w * 0.07f, h * 0.40f); close()
            }
            cv.drawPath(inner, white)
        }
        // тело
        cv.drawRoundRect(RectF(w * 0.08f, h * 0.30f + wob, w * 0.92f, h * 0.95f), w * 0.36f, h * 0.3f, black)

        // глаза
        for (side in intArrayOf(-1, 1)) {
            val cx = w / 2 + side * w * 0.22f
            val cy = h * 0.58f
            cv.drawOval(RectF(cx - w * 0.15f, cy - h * 0.09f, cx + w * 0.15f, cy + h * 0.09f), white)
            if (mood == 1) {
                cv.drawArc(RectF(cx - w * 0.09f, cy - h * 0.04f, cx + w * 0.09f, cy + h * 0.06f), 180f, 180f, false, blackLine)
            } else {
                val ph = h * 0.065f * (if (mood == 2) 1.35f else 1f) * blink
                val pw = w * 0.10f * (if (mood == 2) 1.2f else 1f)
                val px = cx + lookX * w * 0.045f
                val py = cy + lookY * h * 0.03f
                cv.drawOval(RectF(px - pw, py - ph, px + pw, py + ph), black)
            }
        }
        // нос и рот
        val nose = Path().apply {
            moveTo(w * 0.46f, h * 0.69f); lineTo(w * 0.54f, h * 0.69f); lineTo(w * 0.5f, h * 0.73f); close()
        }
        cv.drawPath(nose, white)
        if (mood == 2) {
            cv.drawOval(RectF(w * 0.46f, h * 0.76f, w * 0.54f, h * 0.84f), white)
        } else {
            val m = Path().apply {
                moveTo(w * 0.5f, h * 0.73f)
                quadTo(w * 0.42f, h * 0.84f, w * 0.30f, h * 0.80f)
                moveTo(w * 0.5f, h * 0.73f)
                quadTo(w * 0.58f, h * 0.84f, w * 0.70f, h * 0.80f)
            }
            cv.drawPath(m, whiteLine)
        }
        cv.restore()
    }
}
