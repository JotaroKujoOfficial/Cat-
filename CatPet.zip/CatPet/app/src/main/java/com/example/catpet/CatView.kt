package com.example.catpet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffColorFilter
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Кики из частей рисунка. Форма (ArtSpec) задаёт слои: тело, контур, уши, глаза, зрачки, нос, рот.
 * Тело «желейное» (сетка), части отстают при движении, зрачки следят. Веки настоящие:
 * глаз закрывается шторкой сверху, а при сне и радости рисуется дуга.
 * Кот рисуется в центре с запасом по краям, поэтому при сплющивании ничего не обрезается.
 */
class CatView(c: Context) : View(c) {
    var lookX = 0f
    var lookY = 0f
    var mood = 0            // 0 обычный, 1 довольный, 2 удивлён, 3 сонный, 4 хитрый
    var sleeping = false
    var walking = false

    private var walkPhase = 0f
    private var sq = 0f
    private var sqV = 0f
    private var jx = 0f
    private var jxV = 0f
    private var lean = 0f
    private var leanTarget = 0f
    private var cover = 0f          // 0 глаз открыт, 1 закрыт веком
    private var lx = 0f
    private var ly = 0f
    private var blinkLeft = 0f
    private var blinkIn = 3f
    private var anim: Anim? = null
    private var animT = 0f
    private var dragging = false
    private var breathe = 0f
    private var velSmooth = 0f

    // лапки и жесты (скин «Милаш»)
    var pawsOn = true
    var gestFreq = 1
    private var pawT = 0f
    private var talkT = 0f
    private var gest = 0
    private var gestT = 0f
    private var gestIn = 3f
    private var pDx = 0f
    private var pDy = 0f
    private var pRot = 0f

    private val P = Math.PI.toFloat()
    private fun newPaint(): Paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val pBody = newPaint()
    private val pOutline = newPaint()
    private val pInner = newPaint()
    private val pEye = newPaint()
    private val pPupil = newPaint()
    private val pLine = newPaint()
    private val pBlush = newPaint()
    private val pShine = newPaint()
    private val pPlain = newPaint()
    private val lidPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val collarPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val bellPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lidPath = Path()
    private val arcRect = RectF()
    private val collarRect = RectF()
    private val verts = FloatArray(2 * 2 * 9)
    private var collarOn = false

    private var artIdx = -1
    private var art: ArtSpec = Arts.spec(0)
    private val bm = HashMap<String, Bitmap>()

    init {
        lidPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        arcPaint.style = Paint.Style.STROKE
        arcPaint.strokeCap = Paint.Cap.ROUND
        arcPaint.strokeWidth = 9f
        collarPaint.style = Paint.Style.STROKE
        collarPaint.strokeWidth = 30f
        collarPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        bellPaint.color = Color.rgb(255, 200, 61)
        bellPaint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP)
        applySkin(Skins.classic)
    }

    private fun loadArt(i: Int) {
        artIdx = i
        art = Arts.spec(i)
        bm.clear()
        for (key in art.rects.keys) {
            val id = resources.getIdentifier(art.prefix + "_" + key, "drawable", context.packageName)
            if (id != 0) {
                val o = BitmapFactory.Options()
                o.inScaled = false
                val b = BitmapFactory.decodeResource(resources, id, o)
                if (b != null) bm[key] = b
            }
        }
    }

    /** Форма и цвета Кики. Слои плоские, поэтому цвет накладывается на форму. */
    fun applySkin(sk: Skin) {
        if (sk.art != artIdx) loadArt(sk.art)
        pBody.colorFilter = PorterDuffColorFilter(sk.body, PorterDuff.Mode.SRC_IN)
        pOutline.colorFilter = PorterDuffColorFilter(sk.outline, PorterDuff.Mode.SRC_IN)
        pInner.colorFilter = PorterDuffColorFilter(sk.inner, PorterDuff.Mode.SRC_IN)
        pEye.colorFilter = PorterDuffColorFilter(sk.eye, PorterDuff.Mode.SRC_IN)
        pPupil.colorFilter = PorterDuffColorFilter(sk.pupil, PorterDuff.Mode.SRC_IN)
        pLine.colorFilter = PorterDuffColorFilter(sk.line, PorterDuff.Mode.SRC_IN)
        pBlush.colorFilter = PorterDuffColorFilter(sk.inner, PorterDuff.Mode.SRC_IN)
        pBlush.alpha = 120
        pawsOn = Prefs.b(context, "paws_on")
        gestFreq = Prefs.i(context, "gest_freq")
        lidPaint.color = sk.body
        arcPaint.color = sk.line
        collarOn = sk.collarOn
        collarPaint.color = sk.collar
        invalidate()
    }

    fun kick(sqImp: Float, jxImp: Float) { sqV += sqImp; jxV += jxImp }
    fun playAnim(a: Anim) { anim = a; animT = 0f }

    fun drag(dx: Float, power: Float) {
        dragging = true
        velSmooth = velSmooth * 0.7f + dx * 0.3f
        leanTarget = (velSmooth * 1.2f).coerceIn(-16f, 16f)
        jxV += -dx * 14f * power
    }

    fun endDrag() { dragging = false; leanTarget = 0f }

    private fun coverTarget(): Float {
        if (sleeping) return 1f
        return when (mood) { 1 -> 1f; 3 -> 0.5f; 4 -> 0.38f; else -> 0f }
    }

    fun settled(): Boolean =
        abs(sq) < 0.01f && abs(sqV) < 0.05f && abs(jx) < 0.3f && abs(jxV) < 1f && anim == null && !walking &&
            abs(lean) < 0.2f && abs(leanTarget) < 0.2f && abs(lookX - lx) < 0.02f && abs(lookY - ly) < 0.02f &&
            blinkLeft <= 0f && abs(cover - coverTarget()) < 0.02f && !dragging && !sleeping

    fun step(dt: Float) {
        sqV += (-120f * sq - 9f * sqV) * dt
        sq += sqV * dt
        jxV += (-90f * jx - 6f * jxV) * dt
        jxV = jxV.coerceIn(-700f, 700f)
        jx += jxV * dt
        jx = jx.coerceIn(-45f, 45f)
        if (!dragging) { leanTarget = 0f; velSmooth *= 0.8f }
        lean += (leanTarget - lean) * min(1f, dt * 10f)
        lx += (lookX - lx) * min(1f, dt * 10f)
        ly += (lookY - ly) * min(1f, dt * 10f)
        if (walking) walkPhase += dt * 9f

        var target = coverTarget()
        if (!sleeping) {
            blinkIn -= dt
            if (blinkIn <= 0f) { blinkLeft = 0.13f; blinkIn = 2.5f + Random.nextFloat() * 3.5f }
        }
        if (blinkLeft > 0f) { blinkLeft -= dt; target = 1f }
        cover += (target - cover) * min(1f, dt * 20f)

        if (anim != null) {
            animT += dt / 0.9f
            if (animT >= 1f) { anim = null; animT = 0f }
        }
        pawT += dt
        if (talkT > 0f) talkT -= dt
        if (pawsOn && (bm.containsKey("paw_l") || bm.containsKey("pawfull_l"))) {
            if (gest == 0) {
                gestIn -= dt
                if (gestIn <= 0f) {
                    if (!sleeping && !walking && anim == null && !dragging) { gest = 1 + Random.nextInt(5); gestT = 0f }
                    else gestIn = 1f
                }
            } else {
                gestT += dt
                if (gestT >= 1.8f) {
                    gest = 0
                    gestT = 0f
                    gestIn = when (gestFreq) { 0 -> 9f + Random.nextFloat() * 8f; 2 -> 2.5f + Random.nextFloat() * 3f; else -> 5f + Random.nextFloat() * 5f }
                }
            }
        }
        breathe += dt * (if (sleeping) 1.6f else 2.6f)
        invalidate()
    }

    fun talk(sec: Float) { talkT = sec }

    private fun env(x: Float): Float = sin(P * x.coerceIn(0f, 1f))

    /** Положение лапки: side -1 левая, +1 правая. Результат в pDx, pDy, pRot (pRot по часовой). */
    private fun pawPose(side: Int) {
        var dx = 0f
        var dy = sin(breathe + side) * 2f
        var rot = 0f
        if (sleeping) { pDx = 0f; pDy = 10f; pRot = 0f; return }
        val a = anim
        val ae = if (a != null) env(animT) else 0f
        if (walking) dy -= maxOf(0f, sin(walkPhase + (if (side < 0) 0f else P))) * 22f
        if (talkT > 0f) {
            val s = maxOf(0f, sin(pawT * 5.3f + (if (side < 0) 0f else 2.1f)))
            dy -= s * 80f
            dx -= side * s * 22f
            rot += side * s * 16f
        }
        val ge = env(gestT / 1.8f)
        when (gest) {
            1 -> if (side > 0) { dy -= 200f * ge; dx += 30f * ge; rot += (20f + sin(gestT * 14f) * 20f) * ge }
            2 -> { dy -= 175f * ge; dx -= side * (80f + sin(gestT * 11f) * 16f) * ge; rot -= side * 25f * ge }
            3 -> { dy -= 240f * ge; dx += side * 35f * ge; rot += side * 18f * ge }
            4 -> { dy -= 160f * ge; dx -= side * (58f + sin(gestT * 17f) * 22f) * ge }
            5 -> if (side > 0) { dy -= 120f * ge; dx -= 95f * ge; rot -= 22f * ge }
        }
        if (a != null) when (a) {
            Anim.HOP -> { dy -= 240f * ae; dx += side * 30f * ae; rot += side * 18f * ae }
            Anim.STARTLE -> { dy -= 190f * ae; dx -= side * 80f * ae }
            Anim.BOUNCE -> { dy -= 160f * ae; dx -= side * (55f + sin(animT * 20f) * 20f) * ae }
            Anim.WAVE_EARS, Anim.WIGGLE -> { dy -= 200f * ae; rot += side * sin(animT * 20f) * 22f * ae; dx += side * 35f * ae }
            Anim.PURR -> dy -= maxOf(0f, sin(animT * 40f + (if (side < 0) 0f else P))) * 18f
            else -> {}
        }
        if (mood == 2) { dy -= 150f; dx -= side * 70f }
        pDx = dx
        pDy = dy
        pRot = rot
    }

    private fun drawPaw(cv: Canvas, s: String, side: Int) {
        val full = bm["pawfull_" + s]
        val r = art.rects["paw_" + s] ?: art.rects["pawfull_" + s] ?: return
        if (bm["paw_" + s] == null && full == null) return
        pawPose(side)
        val pivY = r[1] + r[3]
        cv.save()
        cv.translate(pDx, pDy)
        cv.rotate(pRot, r[0] + r[2] / 2f + wob(pivY), pivY)
        if (full != null) {
            layer(cv, full, r, 0f, 0f, pPlain)
        } else {
            layer(cv, bm["pawo_" + s], art.rects["pawo_" + s], 0f, 0f, pOutline)
            layer(cv, bm["paw_" + s], r, 0f, 0f, pBody)
            layer(cv, bm["pad_" + s], art.rects["pad_" + s], 0f, 0f, pInner)
        }
        cv.restore()
    }

    private fun wob(y: Float): Float = jx * (1f - y / art.ch).coerceIn(0f, 1f)

    private fun layer(cv: Canvas, b: Bitmap?, r: FloatArray?, dx: Float, dy: Float, p: Paint) {
        if (b == null || r == null) return
        cv.drawBitmap(b, r[0] + dx + wob(r[1] + r[3] / 2f), r[1] + dy, p)
    }

    private fun meshLayer(cv: Canvas, b: Bitmap?, r: FloatArray?, px: Float, p: Paint) {
        if (b == null || r == null) return
        val rows = 8
        var vi = 0
        for (j in 0..rows) {
            val yy = r[1] + r[3] * j / rows
            val dx = wob(yy)
            val bulge = 1f + sq.coerceIn(-1f, 1f) * 0.05f * sin(P * j / rows)
            for (i in 0..1) {
                val xx = r[0] + r[2] * i
                verts[vi++] = px + (xx - px) * bulge + dx
                verts[vi++] = yy
            }
        }
        cv.drawBitmapMesh(b, 1, rows, verts, 0, null, 0, p)
    }

    private fun drawEar(cv: Canvas, key: String, deg: Float) {
        val b = bm[key]
        val r = art.rects[key]
        if (b == null || r == null) return
        cv.save()
        cv.rotate(deg, r[0] + r[2] / 2f + wob(r[1] + r[3]), r[1] + r[3])
        layer(cv, b, r, 0f, 0f, pInner)
        cv.restore()
    }

    private fun drawEye(cv: Canvas, side: String, lookXv: Float, lookYv: Float,
                        eScale: Float, pScale: Float, showArc: Boolean, happy: Boolean) {
        val eye = bm["eye_" + side]
        val er = art.rects["eye_" + side]
        if (eye == null || er == null) return
        val pup = bm["pupil_" + side]
        val pr = art.rects["pupil_" + side]
        val w = wob(er[1] + er[3] / 2f)
        val l = er[0] + w
        val t = er[1]
        val r = l + er[2]
        val b = t + er[3]
        val ecx = (l + r) / 2f
        val ecy = (t + b) / 2f
        val shift = if (pup == null || pr == null) lookXv * 3f else 0f
        cv.save()
        cv.scale(eScale, eScale, ecx, ecy)
        val layerId = cv.saveLayer(l - 4f, t - 4f, r + 4f, b + 4f, null)
        cv.drawBitmap(eye, l + shift, t, pEye)
        if (pup != null && pr != null) {
            val pdx = lookXv * min((er[2] - pr[2]) * 0.35f, 30f)
            val pdy = lookYv * min((er[3] - pr[3]) * 0.12f, 10f)
            cv.save()
            cv.scale(pScale, pScale, pr[0] + pr[2] / 2f + pdx + w, pr[1] + pr[3] / 2f + pdy)
            cv.drawBitmap(pup, pr[0] + pdx + w, pr[1] + pdy, pPupil)
            val sh = bm["shine_" + side]
            if (sh != null) cv.drawBitmap(sh, pr[0] + pdx + w, pr[1] + pdy, pShine)
            cv.restore()
        }
        if (cover > 0.02f) {
            // веко опускается сверху вниз и закрывает только белок глаза (SRC_ATOP)
            val y0 = t - 4f + (er[3] + 8f) * cover
            lidPath.reset()
            lidPath.moveTo(l - 4f, t - 4f)
            lidPath.lineTo(r + 4f, t - 4f)
            lidPath.lineTo(r + 4f, y0)
            lidPath.quadTo(ecx, y0 + 12f * cover, l - 4f, y0)
            lidPath.close()
            cv.drawPath(lidPath, lidPaint)
        }
        cv.restoreToCount(layerId)
        if (cover > 0.9f && showArc) {
            val aw = er[2] * 0.27f
            val ah = er[3] * 0.13f
            arcRect.set(ecx - aw, ecy - ah, ecx + aw, ecy + ah)
            if (happy) cv.drawArc(arcRect, 200f, 140f, false, arcPaint)
            else cv.drawArc(arcRect, 20f, 140f, false, arcPaint)
        }
        cv.restore()
    }

    override fun onDraw(cv: Canvas) {
        val body = bm["body"]
        val br = art.rects["body"]
        if (body == null || br == null) return
        val cw = art.cw
        val ch = art.ch
        val catW = width / 1.24f
        val k = catW / cw
        val margin = catW * 0.12f
        val ox = (width - catW) / 2f
        val oy = height - margin - ch * k

        val a = anim
        val t = animT
        var aSq = 0f
        var aTilt = 0f
        var aDy = 0f
        var aDx = 0f
        var aEar = 0f
        var aMouth = 1f
        var lookXv = lx
        var lookYv = ly
        var eScale = 1f
        var pScale = 1f
        if (mood == 2 && !sleeping) eScale = 1.07f
        if (a != null) {
            val s = sin(P * t)
            when (a) {
                Anim.HOP -> { aDy = -s * 38f; aSq = -0.3f * s }
                Anim.WIGGLE -> aTilt = sin(t * 6f * P) * 7f * (1f - t)
                Anim.STRETCH -> aSq = -0.8f * s
                Anim.SQUISH -> aSq = 0.9f * s
                Anim.SPIN_EYES -> { lookXv = cos(t * 4f * P); lookYv = sin(t * 4f * P) * 0.7f }
                Anim.TILT -> aTilt = 12f * s
                Anim.SHAKE -> aDx = sin(t * 14f * P) * 10f * (1f - t)
                Anim.PURR -> { aDx = sin(t * 60f) * 1.5f; aMouth = 1.1f + sin(t * 50f) * 0.1f }
                Anim.STARTLE -> { aSq = -1f * (1f - t); aDy = -s * 20f; eScale = 1.12f; pScale = 0.8f }
                Anim.BOUNCE -> aSq = sin(t * 4f * P) * 0.6f * (1f - t)
                Anim.WAVE_EARS -> aEar = sin(t * 8f * P) * 5f
                Anim.FLOP -> { aTilt = 18f * s; aSq = 0.5f * s }
            }
        }

        cv.save()
        cv.translate(ox + aDx * k, oy + aDy * k)
        cv.scale(k, k)
        val bob = if (walking) -abs(sin(walkPhase)) * 9f else 0f
        cv.translate(0f, bob)
        val px = cw / 2f
        val py = br[1] + br[3] - 8f
        val breath = if (sleeping) sin(breathe) * 0.04f else sin(breathe) * 0.012f
        val sqT = sq + aSq + breath
        cv.translate(px, py)
        cv.rotate(lean + aTilt + (if (walking) sin(walkPhase) * 3f else 0f))
        cv.scale(1f + sqT * 0.22f, 1f - sqT * 0.22f)
        cv.translate(-px, -py)

        meshLayer(cv, bm["outline"], art.rects["outline"], px, pOutline)
        if (collarOn) {
            // тело и ошейник рисуются в отдельном слое: ошейник не выходит за контур тела
            val bodyLayer = cv.saveLayer(-90f, -50f, cw + 90f, ch + 50f, null)
            meshLayer(cv, body, br, px, pBody)
            val ty = br[1] + br[3] * 0.62f
            collarRect.set(br[0] - 30f, ty, br[0] + br[2] + 30f, ty + 150f)
            cv.save()
            cv.translate(wob(ty + 75f), 0f)
            cv.drawArc(collarRect, 25f, 130f, false, collarPaint)
            cv.drawCircle(px, ty + 150f, 17f, bellPaint)
            cv.restore()
            cv.restoreToCount(bodyLayer)
        } else {
            meshLayer(cv, body, br, px, pBody)
        }

        val lag = (-jxV * 0.012f).coerceIn(-5f, 5f)
        drawEar(cv, "ear_l", lag + aEar)
        drawEar(cv, "ear_r", lag - aEar)

        val happy = mood == 1 && !sleeping
        val showArc = blinkLeft <= 0f
        drawEye(cv, "l", lookXv, lookYv, eScale, pScale, showArc, happy)
        drawEye(cv, "r", lookXv, lookYv, eScale, pScale, showArc, happy)

        layer(cv, bm["x_hi"], art.rects["x_hi"], 0f, 0f, pPlain)
        if (!sleeping) layer(cv, bm["x_mouth"], art.rects["x_mouth"], lx * 5f, ly * 2f, pPlain)
        layer(cv, bm["blush_l"], art.rects["blush_l"], lx * 2f, 0f, pBlush)
        layer(cv, bm["blush_r"], art.rects["blush_r"], lx * 2f, 0f, pBlush)
        layer(cv, bm["nose"], art.rects["nose"], lx * 5f, ly * 3f, pLine)
        val mr = art.rects["mouth"]
        if (mr != null) {
            val baseM = when {
                sleeping -> 0.6f
                mood == 2 -> 1.5f
                mood == 1 -> 1.2f
                else -> 1f
            }
            val mcx = mr[0] + mr[2] / 2f
            val mcy = mr[1] + mr[3] / 2f
            cv.save()
            cv.scale(1f, baseM * aMouth, mcx, mcy)
            layer(cv, bm["mouth"], mr, lx * 3f, ly * 2f, pLine)
            cv.restore()
        }

        if (pawsOn) {
            drawPaw(cv, "l", -1)
            drawPaw(cv, "r", 1)
        }

        cv.restore()
    }
}
