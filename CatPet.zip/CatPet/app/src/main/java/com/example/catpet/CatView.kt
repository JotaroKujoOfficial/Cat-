package com.example.catpet

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/**
 * Кики, собранный из частей твоего рисунка: тело, уши, глаза, зрачки, нос, рот.
 * Тело «желейное» (сетка), части двигаются и отстают, глаза моргают и следят.
 * Вид рисует котика в центре с запасом по краям, поэтому при сплющивании ничего не обрезается.
 */
class CatView(c: Context) : View(c) {
    var lookX = 0f
    var lookY = 0f
    var mood = 0            // 0 обычный, 1 довольный, 2 удивлён, 3 сонный, 4 хитрый
    var sleeping = false
    var walking = false

    private var walkPhase = 0f
    private var sq = 0f
    private var sqV = 0f
    private var jx = 0f
    private var jxV = 0f
    private var lean = 0f
    private var leanTarget = 0f
    private var eo = 1f
    private var lx = 0f
    private var ly = 0f
    private var blinkLeft = 0f
    private var blinkIn = 3f
    private var anim: Anim? = null
    private var animT = 0f
    private var dragging = false
    private var breathe = 0f
    private var velSmooth = 0f

    private val P = Math.PI.toFloat()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val verts = FloatArray(2 * 2 * 9)

    private fun bmp(id: Int): Bitmap {
        val o = BitmapFactory.Options()
        o.inScaled = false
        return BitmapFactory.decodeResource(resources, id, o)
    }

    private val body = bmp(R.drawable.cat_body)
    private val earL = bmp(R.drawable.cat_ear_l)
    private val earR = bmp(R.drawable.cat_ear_r)
    private val eyeL = bmp(R.drawable.cat_eye_l)
    private val eyeR = bmp(R.drawable.cat_eye_r)
    private val pupL = bmp(R.drawable.cat_pupil_l)
    private val pupR = bmp(R.drawable.cat_pupil_r)
    private val nose = bmp(R.drawable.cat_nose)
    private val mouth = bmp(R.drawable.cat_mouth)

    // Положения частей на холсте 566×539: x, y, ширина, высота
    private val CW = 566f
    private val CH = 539f
    private val B = floatArrayOf(23f, 23f, 520f, 493f)
    private val EARL = floatArrayOf(64f, 53f, 95f, 168f)
    private val EARR = floatArrayOf(407f, 53f, 95f, 168f)
    private val EYEL = floatArrayOf(65f, 201f, 200f, 130f)
    private val PUPL = floatArrayOf(104f, 233f, 131f, 60f)
    private val EYER = floatArrayOf(301f, 201f, 191f, 130f)
    private val PUPR = floatArrayOf(320f, 233f, 131f, 60f)
    private val NOSE = floatArrayOf(261f, 293f, 44f, 30f)
    private val MOUTH = floatArrayOf(147f, 321f, 272f, 81f)

    fun kick(sqImp: Float, jxImp: Float) { sqV += sqImp; jxV += jxImp }
    fun playAnim(a: Anim) { anim = a; animT = 0f }

    fun drag(dx: Float, power: Float) {
        dragging = true
        velSmooth = velSmooth * 0.7f + dx * 0.3f
        leanTarget = (velSmooth * 1.2f).coerceIn(-16f, 16f)
        jxV += -dx * 14f * power
    }

    fun endDrag() { dragging = false; leanTarget = 0f }

    fun settled(): Boolean =
        abs(sq) < 0.01f && abs(sqV) < 0.05f && abs(jx) < 0.3f && abs(jxV) < 1f && anim == null && !walking &&
            abs(lean) < 0.2f && abs(leanTarget) < 0.2f && abs(lookX - lx) < 0.02f && abs(lookY - ly) < 0.02f &&
            blinkLeft <= 0f && !dragging && !sleeping

    fun step(dt: Float) {
        sqV += (-120f * sq - 9f * sqV) * dt
        sq += sqV * dt
        jxV += (-90f * jx - 6f * jxV) * dt
        jxV = jxV.coerceIn(-700f, 700f)
        jx += jxV * dt
        jx = jx.coerceIn(-45f, 45f)
        if (!dragging) { leanTarget = 0f; velSmooth *= 0.8f }
        lean += (leanTarget - lean) * min(1f, dt * 10f)
        lx += (lookX - lx) * min(1f, dt * 10f)
        ly += (lookY - ly) * min(1f, dt * 10f)
        if (walking) walkPhase += dt * 9f

        var target = when (mood) { 1 -> 0.32f; 2 -> 1.12f; 3 -> 0.45f; 4 -> 0.6f; else -> 1f }
        if (sleeping) target = 0.1f
        if (!sleeping) {
            blinkIn -= dt
            if (blinkIn <= 0f) { blinkLeft = 0.14f; blinkIn = 2.5f + Random.nextFloat() * 3.5f }
        }
        if (blinkLeft > 0f) { blinkLeft -= dt; target = min(target, 0.1f) }
        eo += (target - eo) * min(1f, dt * 16f)

        if (anim != null) {
            animT += dt / 0.9f
            if (animT >= 1f) { anim = null; animT = 0f }
        }
        breathe += dt * (if (sleeping) 1.6f else 2.6f)
        invalidate()
    }

    private fun wob(y: Float): Float = jx * (1f - y / CH).coerceIn(0f, 1f)

    private fun layer(cv: Canvas, b: Bitmap, r: FloatArray, dx: Float, dy: Float) {
        cv.drawBitmap(b, r[0] + dx + wob(r[1] + r[3] / 2f), r[1] + dy, paint)
    }

    private fun drawEar(cv: Canvas, b: Bitmap, r: FloatArray, deg: Float) {
        cv.save()
        cv.rotate(deg, r[0] + r[2] / 2f + wob(r[1] + r[3]), r[1] + r[3])
        layer(cv, b, r, 0f, 0f)
        cv.restore()
    }

    private fun drawEye(cv: Canvas, eye: Bitmap, er: FloatArray, pup: Bitmap, pr: FloatArray,
                        pdx: Float, pdy: Float, eScale: Float, pScale: Float) {
        val w = wob(er[1] + er[3] / 2f)
        val ecx = er[0] + er[2] / 2f + w
        val ecy = er[1] + er[3] / 2f
        cv.save()
        cv.scale(eScale, eScale * eo.coerceIn(0.08f, 1.2f), ecx, ecy)
        cv.drawBitmap(eye, er[0] + w, er[1], paint)
        cv.save()
        cv.scale(pScale, pScale, pr[0] + pr[2] / 2f + pdx + w, pr[1] + pr[3] / 2f + pdy)
        cv.drawBitmap(pup, pr[0] + pdx + w, pr[1] + pdy, paint)
        cv.restore()
        cv.restore()
    }

    override fun onDraw(cv: Canvas) {
        val catW = width / 1.4f
        val k = catW / CW
        val margin = catW * 0.2f
        val ox = (width - catW) / 2f
        val oy = height - margin - CH * k

        val a = anim
        val t = animT
        var aSq = 0f
        var aTilt = 0f
        var aDy = 0f
        var aDx = 0f
        var aEar = 0f
        var aMouth = 1f
        var lookXv = lx
        var lookYv = ly
        var eScale = 1f
        var pScale = 1f
        if (a != null) {
            val s = sin(P * t)
            when (a) {
                Anim.HOP -> { aDy = -s * 38f; aSq = -0.3f * s }
                Anim.WIGGLE -> aTilt = sin(t * 6f * P) * 7f * (1f - t)
                Anim.STRETCH -> aSq = -0.8f * s
                Anim.SQUISH -> aSq = 0.9f * s
                Anim.SPIN_EYES -> { lookXv = cos(t * 4f * P); lookYv = sin(t * 4f * P) * 0.7f }
                Anim.TILT -> aTilt = 12f * s
                Anim.SHAKE -> aDx = sin(t * 14f * P) * 10f * (1f - t)
                Anim.PURR -> { aDx = sin(t * 60f) * 1.5f; aMouth = 1.1f + sin(t * 50f) * 0.1f }
                Anim.STARTLE -> { aSq = -1f * (1f - t); aDy = -s * 20f; eScale = 1.12f; pScale = 0.8f }
                Anim.BOUNCE -> aSq = sin(t * 4f * P) * 0.6f * (1f - t)
                Anim.WAVE_EARS -> aEar = sin(t * 8f * P) * 5f
                Anim.FLOP -> { aTilt = 18f * s; aSq = 0.5f * s }
            }
        }

        cv.save()
        cv.translate(ox + aDx * k, oy + aDy * k)
        cv.scale(k, k)
        val bob = if (walking) -abs(sin(walkPhase)) * 9f else 0f
        cv.translate(0f, bob)
        val px = CW / 2f
        val py = B[1] + B[3] - 8f
        val breath = if (sleeping) sin(breathe) * 0.04f else sin(breathe) * 0.012f
        val sqT = sq + aSq + breath
        cv.translate(px, py)
        cv.rotate(lean + aTilt + (if (walking) sin(walkPhase) * 3f else 0f))
        cv.scale(1f + sqT * 0.22f, 1f - sqT * 0.22f)
        cv.translate(-px, -py)

        // тело: сетка 1×8, строки смещаются волной
        val rows = 8
        var vi = 0
        for (j in 0..rows) {
            val yy = B[1] + B[3] * j / rows
            val dx = wob(yy)
            val bulge = 1f + sq.coerceIn(-1f, 1f) * 0.05f * sin(P * j / rows)
            for (i in 0..1) {
                val xx = B[0] + B[2] * i
                verts[vi++] = px + (xx - px) * bulge + dx
                verts[vi++] = yy
            }
        }
        cv.drawBitmapMesh(body, 1, rows, verts, 0, null, 0, paint)

        // уши отстают от головы
        val lag = (-jxV * 0.012f).coerceIn(-5f, 5f)
        drawEar(cv, earL, EARL, lag + aEar)
        drawEar(cv, earR, EARR, lag - aEar)

        // глаза и зрачки
        val pdx = lookXv * 24f
        val pdy = lookYv * 9f
        drawEye(cv, eyeL, EYEL, pupL, PUPL, pdx, pdy, eScale, pScale)
        drawEye(cv, eyeR, EYER, pupR, PUPR, pdx, pdy, eScale, pScale)

        // нос и рот чуть смещаются в сторону взгляда
        layer(cv, nose, NOSE, lx * 5f, ly * 3f)
        val mood2 = mood == 2
        val baseM = when {
            sleeping -> 0.6f
            mood2 -> 1.5f
            mood == 1 -> 1.2f
            else -> 1f
        }
        val mcx = MOUTH[0] + MOUTH[2] / 2f
        val mcy = MOUTH[1] + MOUTH[3] / 2f
        cv.save()
        cv.scale(1f, baseM * aMouth, mcx, mcy)
        layer(cv, mouth, MOUTH, lx * 3f, ly * 2f)
        cv.restore()

        cv.restore()
    }
}
