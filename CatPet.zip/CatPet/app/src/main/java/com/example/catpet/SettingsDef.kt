package com.example.catpet

sealed class Item(val key: String, val title: String, val desc: String)
class Toggle(key: String, title: String, desc: String, val def: Boolean) : Item(key, title, desc)
class Choice(key: String, title: String, desc: String, val options: List<String>, val def: Int) : Item(key, title, desc)
class Slider(key: String, title: String, desc: String, val min: Int, val max: Int, val def: Int, val unit: String) : Item(key, title, desc)
class Field(key: String, title: String, desc: String, val hint: String, val def: String, val secret: Boolean = false) : Item(key, title, desc)
class Info(title: String, desc: String) : Item("", title, desc)

/** tab: 0 Главная, 1 Облик, 2 Поведение, 3 ИИ, 4 Ещё */
class Section(val tab: Int, val title: String, val items: List<Item>)

object SettingsDef {
    val tabNames = listOf("Главная", "Облик", "Поведение", "ИИ", "Ещё")

    val sections: List<Section> = listOf(
        Section(1, "РАЗМЕР И ВИД", listOf(
            Slider("cat_size", "Размер Кики", "", 70, 180, 110, " dp"),
            Slider("cat_opacity", "Прозрачность", "", 40, 100, 100, "%"),
            Toggle("show_bubbles", "Фразы в облачках", "Короткие реплики над Кики", true),
            Toggle("show_zzz", "«Z-z-z» во сне", "", true)
        )),
        Section(2, "ПОВЕДЕНИЕ", listOf(
            Choice("activity", "Активность", "Как быстро он бегает", listOf("Спокойный", "Обычный", "Шустрый"), 1),
            Toggle("walk_surfaces", "Ходить по кнопкам и окнам", "Нужно чтение экрана. Без него Кики ходит только по низу", true),
            Toggle("wrap_fall", "Выпадать сверху", "Если опустить Кики к самому низу, он провалится и упадёт сверху", true),
            Toggle("follow_taps", "Смотреть, куда ты нажал", "", true),
            Slider("sleep_min", "Засыпать через", "Минут без твоих действий", 1, 30, 3, " мин"),
            Toggle("wake_on_event", "Просыпаться от действий на экране", "", true),
            Toggle("dock_on", "Прятаться у края", "Когда ты не трогаешь Кики, он уходит к краю экрана и становится полупрозрачным", true),
            Slider("dock_sec", "Прятаться через", "Секунд без касаний", 5, 120, 20, " с")
        )),
        Section(2, "РЕАКЦИИ", listOf(
            Toggle("react_click", "На нажатия", "", true),
            Toggle("react_scroll", "На прокрутку", "", true),
            Toggle("react_text", "На ввод текста", "", true),
            Toggle("react_window", "На смену окна", "", true),
            Toggle("react_notif", "На уведомления", "", true),
            Slider("shake_power", "Тряска при перетаскивании", "Насколько Кики «желейный»", 0, 100, 60, "%"),
            Slider("talk_rate", "Болтливость", "Как часто Кики говорит фразы", 0, 100, 40, "%"),
            Toggle("haptic", "Вибро-отклик", "Лёгкая вибрация при касании", false)
        )),
        Section(3, "ОТВЕТЫ КИКИ", listOf(
            Choice("ai_tone", "Характер", "", listOf("Игривый", "Спокойный", "Деловой", "Едкий"), 0),
            Slider("ai_len", "Длина ответа", "Лимит на один ответ", 100, 800, 300, "")
        )),
        Section(3, "УПРАВЛЕНИЕ КИКИ ЧЕРЕЗ ИИ", listOf(
            Choice("ai_ctl_level", "Что разрешено ИИ", "Выкл: ИИ только пишет. Эмоции: ещё настроение, анимации, взгляд, фразы. Полностью: ещё движение, сон и смена облика", listOf("Выкл", "Эмоции", "Полностью"), 2),
            Toggle("ai_ctl_mood", "Настроение и мимика", "Радость, удивление, сонный и хитрый взгляд", true),
            Toggle("ai_ctl_anim", "Анимации", "Прыжки, тряска, мурчание и другие", true),
            Toggle("ai_ctl_look", "Взгляд", "Куда смотрит Кики", true),
            Toggle("ai_ctl_say", "Фразы в облачке", "Короткая реплика над Кики", true),
            Toggle("ai_ctl_move", "Движение и прыжки", "Только на уровне «Полностью»", true),
            Toggle("ai_ctl_sleep", "Сон и пробуждение", "Только на уровне «Полностью»", true),
            Toggle("ai_ctl_skin", "Смена облика", "Только на уровне «Полностью»", true)
        )),
        Section(3, "РЕТРАНСЛЯТОР И ПРОКСИ ВРУЧНУЮ", listOf(
            Field("ai_relay", "Адрес ретранслятора", "Начинается с https://", "https://kiki-relay.твой-логин.workers.dev", ""),
            Field("ai_proxy", "Прокси", "Адрес и порт, например 1.2.3.4:1080", "host:port", ""),
            Choice("ai_proxy_type", "Тип прокси", "", listOf("HTTP", "SOCKS5"), 0),
            Field("ai_proxy_auth", "Логин и пароль прокси", "Через двоеточие, если нужны", "логин:пароль", "", true)
        )),
        Section(3, "ДЛЯ РАЗРАБОТЧИКОВ", listOf(
            Field("ai_url", "Адрес API", "Заполняется само при подключении", "https://…", ""),
            Field("ai_model", "Модель", "Заполняется само при подключении", "название модели", ""),
            Choice("ai_style", "Тип API", "Меняй, только если знаешь зачем", listOf("OpenAI-совместимый", "Anthropic"), 0)
        )),
        Section(4, "ЧТЕНИЕ ЭКРАНА", listOf(
            Toggle("screen_read", "Читать текст экрана", "Нужно для «Разобрать задачу» и дневника. Поля паролей не читаются никогда", true),
            Toggle("warn_a11y", "Предупреждать, если чтение экрана выключилось", "Система иногда выключает его сама. Придёт уведомление с кнопкой", true),
            Field("exclude_pkgs", "Не читать приложения", "Пакеты через запятую, например банковские", "com.bank.app, com.other", "")
        )),
        Section(4, "ДНЕВНИК ЗАДАЧ", listOf(
            Toggle("journal_on", "Вести дневник", "Записи хранятся только на телефоне", false),
            Toggle("journal_ai", "Подписывать записи через ИИ", "Текст экрана уйдёт в выбранный ИИ-сервис. Выключено: пишется только название приложения", false),
            Slider("journal_days", "Хранить", "", 1, 60, 14, " дн."),
            Toggle("peek_random", "Заглядывать в экран сам", "Кики иногда смотрит на экран без команды", false),
            Slider("peek_min", "Как часто заглядывать", "", 2, 60, 10, " мин")
        )),
        Section(4, "ЭКОНОМИЯ", listOf(
            Choice("fps", "Плавность анимации", "30 кадров экономнее", listOf("30 кадров", "60 кадров"), 0),
            Toggle("low_power", "Меньше анимаций при низком заряде", "", true),
            Info("Автоматически", "Когда экран выключен, Кики полностью замирает. Когда ничего не происходит, анимация замедляется.")
        )),
        Section(4, "ПРИВАТНОСТЬ", listOf(
            Info("Голос", "Кики не слушает и не записывает голос."),
            Info("Экран", "Текст экрана читается только по твоей просьбе или если ты сам включил заглядывание и дневник. Поля паролей не читаются никогда."),
            Info("Данные", "Пока ИИ не подключён, ничего никуда не отправляется. Когда подключён, уходит только твой вопрос и (по твоей кнопке) текст экрана.")
        ))
    )

    val defaults: Map<String, Any> by lazy {
        val m = HashMap<String, Any>()
        for (s in sections) for (item in s.items) {
            when (item) {
                is Toggle -> m[item.key] = item.def
                is Choice -> m[item.key] = item.def
                is Slider -> m[item.key] = item.def
                is Field -> m[item.key] = item.def
                is Info -> {}
            }
        }
        m
    }
}
