package com.example.catpet

sealed class Item(val key: String, val title: String, val desc: String)
class Toggle(key: String, title: String, desc: String, val def: Boolean) : Item(key, title, desc)
class Choice(key: String, title: String, desc: String, val options: List<String>, val def: Int) : Item(key, title, desc)
class Slider(key: String, title: String, desc: String, val min: Int, val max: Int, val def: Int, val unit: String) : Item(key, title, desc)
class Field(key: String, title: String, desc: String, val hint: String, val def: String, val secret: Boolean = false) : Item(key, title, desc)
class Info(title: String, desc: String) : Item("", title, desc)
class Section(val title: String, val items: List<Item>)

object SettingsDef {
    val sections: List<Section> = listOf(
        Section("ВНЕШНИЙ ВИД", listOf(
            Slider("cat_size", "Размер Кики", "", 70, 180, 110, " dp"),
            Slider("cat_opacity", "Прозрачность", "", 40, 100, 100, "%"),
            Toggle("show_bubbles", "Фразы в облачках", "Короткие фразы над Кики", true),
            Toggle("show_zzz", "«Z-z-z» во сне", "", true)
        )),
        Section("ПОВЕДЕНИЕ", listOf(
            Choice("activity", "Активность", "Как быстро он бегает", listOf("Спокойный", "Обычный", "Шустрый"), 1),
            Toggle("walk_surfaces", "Ходить по кнопкам и окнам", "Нужно чтение экрана. Без него Кики ходит только по низу", true),
            Toggle("wrap_fall", "Падать вниз и выпадать сверху", "Если уронить в самый низ, Кики вернётся сверху", true),
            Toggle("follow_taps", "Смотреть, куда ты нажал", "", true),
            Slider("sleep_min", "Засыпать через", "Минут без твоих действий", 1, 30, 3, " мин"),
            Toggle("wake_on_event", "Просыпаться от действий на экране", "", true)
        )),
        Section("РЕАКЦИИ", listOf(
            Toggle("react_click", "На нажатия", "", true),
            Toggle("react_scroll", "На прокрутку", "", true),
            Toggle("react_text", "На ввод текста", "", true),
            Toggle("react_window", "На смену окна", "", true),
            Toggle("react_notif", "На уведомления", "", true),
            Slider("shake_power", "Тряска при перетаскивании", "Насколько Кики «желейный»", 0, 100, 60, "%"),
            Slider("talk_rate", "Болтливость", "Как часто Кики говорит фразы", 0, 100, 40, "%"),
            Toggle("haptic", "Вибро-отклик при касании", "", false)
        )),
        Section("ИИ", listOf(
            Choice("ai_provider", "Сервис ИИ", "Без ключа работают встроенные ответы", listOf("Встроенные", "Anthropic", "OpenAI-совм."), 0),
            Field("ai_url", "Адрес API", "Пусто: адрес по умолчанию. Для других сервисов (Groq, OpenRouter, Gemini и т.д.) впиши их адрес до /v1", "https://api.openai.com/v1", ""),
            Field("ai_model", "Модель", "Для Anthropic по умолчанию claude-sonnet-5-5", "название модели", ""),
            Field("ai_key", "Ключ API", "Хранится только на этом телефоне", "ключ", "", true),
            Choice("ai_tone", "Характер Кики", "", listOf("Игривый", "Спокойный", "Деловой", "Саркастичный"), 0),
            Slider("ai_len", "Длина ответа", "", 100, 800, 300, " ток.")
        )),
        Section("ЭКРАН И ДНЕВНИК", listOf(
            Toggle("screen_read", "Читать текст экрана", "Нужно для «Разобрать задачу» и дневника. Поля паролей не читаются никогда", true),
            Toggle("peek_random", "Заглядывать в экран сам", "Кики иногда смотрит на экран без команды", false),
            Slider("peek_min", "Как часто заглядывать", "", 2, 60, 10, " мин"),
            Toggle("journal_on", "Вести дневник задач", "Записи хранятся только на телефоне", false),
            Toggle("journal_ai", "Подписывать записи через ИИ", "Текст экрана уйдёт в выбранный ИИ-сервис. Выключено: пишется только название приложения", false),
            Slider("journal_days", "Хранить дневник", "", 1, 60, 14, " дн."),
            Field("exclude_pkgs", "Не читать приложения", "Пакеты через запятую, например банковские", "com.bank.app, com.other", "")
        )),
        Section("ВЫЗОВ", listOf(
            Info("Позвать Кики", "Если спрятал Кики, нажми «Позвать Кики» в уведомлении. Голосовой вызов фразой «Кики, кис-кис» будет в следующей версии: только на самом телефоне, без записи и отправки голоса.")
        )),
        Section("ПРИВАТНОСТЬ", listOf(
            Info("Голос", "Кики не слушает и не записывает голос."),
            Info("Экран", "Текст экрана читается только когда ты просишь, либо если сам включил «Заглядывать в экран» и дневник. Поля паролей не читаются никогда."),
            Info("Данные", "Ничего не отправляется, пока не выбран ИИ-сервис и ключ. Тогда уходит только твой вопрос и (по твоей кнопке) текст экрана.")
        )),
        Section("ЭКОНОМИЯ", listOf(
            Choice("fps", "Плавность анимации", "30 кадров экономнее", listOf("30 кадров", "60 кадров"), 0),
            Toggle("low_power", "Меньше анимаций при низком заряде", "", true),
            Info("Автоматически", "Когда экран выключен, Кики полностью останавливается. Когда ничего не происходит, анимация замедляется.")
        ))
    )

    val defaults: Map<String, Any> by lazy {
        val m = HashMap<String, Any>()
        for (s in sections) for (item in s.items) {
            when (item) {
                is Toggle -> m[item.key] = item.def
                is Choice -> m[item.key] = item.def
                is Slider -> m[item.key] = item.def
                is Field -> m[item.key] = item.def
                is Info -> {}
            }
        }
        m
    }
}
