package com.example.catpet

import android.content.Context
import android.graphics.Typeface

/** Шрифты приложения: Inter для текста и JetBrains Mono для подписей (оба под лицензией SIL OFL). */
object Fonts {
    private var reg: Typeface? = null
    private var semi: Typeface? = null
    private var bold: Typeface? = null
    private var mono: Typeface? = null
    private var monoB: Typeface? = null

    private fun load(c: Context, id: Int, fallback: Typeface): Typeface =
        try { c.resources.getFont(id) } catch (e: Exception) { fallback }

    fun regular(c: Context): Typeface = reg ?: load(c, R.font.inter_regular, Typeface.SANS_SERIF).also { reg = it }
    fun semibold(c: Context): Typeface = semi ?: load(c, R.font.inter_semibold, Typeface.DEFAULT_BOLD).also { semi = it }
    fun bold(c: Context): Typeface = bold ?: load(c, R.font.inter_bold, Typeface.DEFAULT_BOLD).also { bold = it }
    fun mono(c: Context): Typeface = mono ?: load(c, R.font.jetbrains_mono, Typeface.MONOSPACE).also { mono = it }
    fun monoBold(c: Context): Typeface = monoB ?: load(c, R.font.jetbrains_mono_bold, Typeface.MONOSPACE).also { monoB = it }
}
