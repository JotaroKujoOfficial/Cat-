package com.example.catpet

import android.content.Context
import android.graphics.Color

/** Раскраска Кики: тело, внутренность ушей, белки глаз, зрачки, линии мордочки и необязательный ошейник. */
class Skin(val body: Int, val inner: Int, val eye: Int, val pupil: Int, val line: Int, val collarOn: Boolean, val collar: Int)

object Skins {
    private val ORANGE = Color.parseColor("#ED4A1D")
    val names = listOf("Классика", "Неон", "Снежок")

    private val presets = listOf(
        Skin(Color.parseColor("#000000"), Color.parseColor("#FFFFFF"), Color.parseColor("#FFFFFF"),
            Color.parseColor("#000000"), Color.parseColor("#FFFFFF"), false, ORANGE),
        Skin(Color.parseColor("#0A0D16"), Color.parseColor("#FF2E93"), Color.parseColor("#DDF8FF"),
            Color.parseColor("#0A0D16"), Color.parseColor("#2DE8FF"), false, Color.parseColor("#2DE8FF")),
        Skin(Color.parseColor("#F3F3F6"), Color.parseColor("#FFB3C8"), Color.parseColor("#C9D1E2"),
            Color.parseColor("#20202A"), Color.parseColor("#2A2A34"), false, ORANGE)
    )

    val classic: Skin = presets[0]

    val palette = intArrayOf(
        Color.parseColor("#000000"), Color.parseColor("#20202A"), Color.parseColor("#FFFFFF"), Color.parseColor("#F3F3F6"),
        Color.parseColor("#ED4A1D"), Color.parseColor("#FF2E93"), Color.parseColor("#A855F7"), Color.parseColor("#3B82F6"),
        Color.parseColor("#2DE8FF"), Color.parseColor("#22C55E"), Color.parseColor("#FACC15"), Color.parseColor("#FB923C"),
        Color.parseColor("#8B5E3C"), Color.parseColor("#94A3B8")
    )

    fun preset(i: Int): Skin = presets[i.coerceIn(0, presets.size - 1)]

    fun idOf(name: String?): Int {
        if (name == null) return -1
        return when (name.trim().lowercase()) {
            "classic", "классика" -> 0
            "neon", "неон" -> 1
            "snow", "снежок" -> 2
            else -> -1
        }
    }

    private fun collarColor(c: Context): Int {
        val v = Prefs.i(c, "skin_collar")
        return if (v == 0) ORANGE else v
    }

    fun current(c: Context): Skin {
        val id = Prefs.i(c, "skin_id")
        val on = Prefs.b(c, "skin_collar_on")
        val cc = collarColor(c)
        if (id in 0 until presets.size) {
            val p = presets[id]
            return Skin(p.body, p.inner, p.eye, p.pupil, p.line, on, cc)
        }
        return Skin(Prefs.i(c, "skin_body"), Prefs.i(c, "skin_inner"), Prefs.i(c, "skin_eye"),
            Prefs.i(c, "skin_pupil"), Prefs.i(c, "skin_line"), on, cc)
    }

    fun applyPreset(c: Context, id: Int) { Prefs.putI(c, "skin_id", id) }

    /** key: skin_body, skin_inner, skin_eye, skin_pupil, skin_line, skin_collar */
    fun colorOf(c: Context, key: String): Int {
        val s = current(c)
        return when (key) {
            "skin_body" -> s.body
            "skin_inner" -> s.inner
            "skin_eye" -> s.eye
            "skin_pupil" -> s.pupil
            "skin_line" -> s.line
            else -> s.collar
        }
    }

    fun setCustom(c: Context, key: String, color: Int) {
        if (key == "skin_collar") { Prefs.putI(c, key, color); return }
        if (Prefs.i(c, "skin_id") != 3) {
            val s = current(c)
            Prefs.putI(c, "skin_body", s.body)
            Prefs.putI(c, "skin_inner", s.inner)
            Prefs.putI(c, "skin_eye", s.eye)
            Prefs.putI(c, "skin_pupil", s.pupil)
            Prefs.putI(c, "skin_line", s.line)
            Prefs.putI(c, "skin_id", 3)
        }
        Prefs.putI(c, key, color)
    }
}
