package com.example.catpet

import android.content.Context
import android.graphics.Color

/** Облик Кики: форма (art) и цвета частей. */
class Skin(val art: Int, val body: Int, val outline: Int, val inner: Int, val eye: Int, val pupil: Int,
           val line: Int, val collarOn: Boolean, val collar: Int)

object Skins {
    private val ORANGE = Color.parseColor("#ED4A1D")
    private val BLACK = Color.parseColor("#000000")
    private val WHITE = Color.parseColor("#FFFFFF")
    const val CUSTOM = 9

    val names = listOf("Классика", "Неон", "Снежок", "Гладкий", "Хмурый", "Геометрия", "Геометрия II", "Кибер", "Милаш")

    private val presets = listOf(
        Skin(0, BLACK, WHITE, WHITE, WHITE, BLACK, WHITE, false, ORANGE),
        Skin(0, Color.parseColor("#0A0D16"), WHITE, Color.parseColor("#FF2E93"), Color.parseColor("#DDF8FF"),
            Color.parseColor("#0A0D16"), Color.parseColor("#2DE8FF"), false, Color.parseColor("#2DE8FF")),
        Skin(0, Color.parseColor("#F3F3F6"), WHITE, Color.parseColor("#FFB3C8"), Color.parseColor("#C9D1E2"),
            Color.parseColor("#20202A"), Color.parseColor("#2A2A34"), false, ORANGE),
        Skin(1, BLACK, WHITE, WHITE, WHITE, BLACK, WHITE, false, ORANGE),
        Skin(2, BLACK, WHITE, WHITE, WHITE, BLACK, WHITE, false, ORANGE),
        Skin(3, BLACK, WHITE, WHITE, WHITE, BLACK, WHITE, false, ORANGE),
        Skin(4, BLACK, WHITE, WHITE, WHITE, BLACK, WHITE, false, ORANGE),
        Skin(1, Color.parseColor("#090A10"), Color.parseColor("#FF5A1F"), Color.parseColor("#FF5A1F"), Color.parseColor("#FFB36B"),
            Color.parseColor("#090A10"), Color.parseColor("#FF5A1F"), false, Color.parseColor("#FF5A1F")),
        Skin(5, Color.parseColor("#15151B"), Color.parseColor("#FF8A1F"), Color.parseColor("#FF8FB1"), Color.parseColor("#FFD21F"),
            Color.parseColor("#0A0A0F"), Color.parseColor("#FF9DB8"), false, Color.parseColor("#FF5A1F"))
    )

    val classic: Skin = presets[0]

    val palette = intArrayOf(
        Color.parseColor("#000000"), Color.parseColor("#20202A"), Color.parseColor("#FFFFFF"), Color.parseColor("#F3F3F6"),
        Color.parseColor("#ED4A1D"), Color.parseColor("#FF2E93"), Color.parseColor("#A855F7"), Color.parseColor("#3B82F6"),
        Color.parseColor("#2DE8FF"), Color.parseColor("#22C55E"), Color.parseColor("#FACC15"), Color.parseColor("#FB923C"),
        Color.parseColor("#8B5E3C"), Color.parseColor("#94A3B8")
    )

    fun preset(i: Int): Skin = presets[i.coerceIn(0, presets.size - 1)]

    fun idOf(name: String?): Int {
        if (name == null) return -1
        return when (name.trim().lowercase()) {
            "classic", "классика" -> 0
            "neon", "неон" -> 1
            "snow", "снежок" -> 2
            "smooth", "гладкий" -> 3
            "grumpy", "хмурый" -> 4
            "geo", "геометрия" -> 5
            "geo2", "геометрия ii", "геометрия 2" -> 6
            "cyber", "кибер" -> 7
            "cute", "милаш" -> 8
            else -> -1
        }
    }

    private fun collarColor(c: Context): Int {
        val v = Prefs.i(c, "skin_collar")
        return if (v == 0) ORANGE else v
    }

    private val eyeColors = intArrayOf(0, Color.parseColor("#FFD21F"), Color.parseColor("#3DDC84"), Color.parseColor("#38BDF8"),
        Color.parseColor("#FF8A1F"), Color.parseColor("#FF4FA3"), Color.parseColor("#FF3B3B"), Color.parseColor("#FFFFFF"))

    /** Цвет глаз можно сменить в настройках для любого скина. */
    fun current(c: Context): Skin {
        val s = base(c)
        val ov = eyeColors.getOrElse(Prefs.i(c, "eye_color")) { 0 }
        return if (ov == 0) s else Skin(s.art, s.body, s.outline, s.inner, ov, s.pupil, s.line, s.collarOn, s.collar)
    }

    private fun base(c: Context): Skin {
        val id = Prefs.i(c, "skin_id")
        val on = Prefs.b(c, "skin_collar_on")
        val cc = collarColor(c)
        if (id in 0 until presets.size) {
            val p = presets[id]
            return Skin(p.art, p.body, p.outline, p.inner, p.eye, p.pupil, p.line, on, cc)
        }
        return Skin(Prefs.i(c, "skin_art"), Prefs.i(c, "skin_body"), Prefs.i(c, "skin_outline"), Prefs.i(c, "skin_inner"),
            Prefs.i(c, "skin_eye"), Prefs.i(c, "skin_pupil"), Prefs.i(c, "skin_line"), on, cc)
    }

    fun applyPreset(c: Context, id: Int) { Prefs.putI(c, "skin_id", id) }

    /** key: skin_body, skin_outline, skin_inner, skin_eye, skin_pupil, skin_line, skin_collar */
    fun colorOf(c: Context, key: String): Int {
        val s = current(c)
        return when (key) {
            "skin_body" -> s.body
            "skin_outline" -> s.outline
            "skin_inner" -> s.inner
            "skin_eye" -> s.eye
            "skin_pupil" -> s.pupil
            "skin_line" -> s.line
            else -> s.collar
        }
    }

    fun setCustom(c: Context, key: String, color: Int) {
        if (key == "skin_collar") { Prefs.putI(c, key, color); return }
        if (Prefs.i(c, "skin_id") != CUSTOM) {
            val s = current(c)
            Prefs.putI(c, "skin_art", s.art)
            Prefs.putI(c, "skin_body", s.body)
            Prefs.putI(c, "skin_outline", s.outline)
            Prefs.putI(c, "skin_inner", s.inner)
            Prefs.putI(c, "skin_eye", s.eye)
            Prefs.putI(c, "skin_pupil", s.pupil)
            Prefs.putI(c, "skin_line", s.line)
            Prefs.putI(c, "skin_id", CUSTOM)
        }
        Prefs.putI(c, key, color)
    }
}
