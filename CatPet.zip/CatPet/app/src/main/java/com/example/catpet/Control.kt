package com.example.catpet

import android.content.Context

/**
 * ИИ может управлять Кики: в начале ответа он добавляет служебный тег
 * <kiki mood="happy" anim="hop" look="left" say="Мур!" move="right" sleep="0" skin="neon"/>.
 * Тег вырезается из текста, а разрешённые части выполняются. Что именно разрешено, настраивается.
 */
object Control {
    private val tagRe = Regex("<kiki\\b([^>]*?)/?>", RegexOption.IGNORE_CASE)
    private val attrRe = Regex("(\\w+)\\s*=\\s*[\"“”']([^\"“”']*)[\"“”']")

    fun level(c: Context): Int = Prefs.i(c, "ai_ctl_level")

    /** Уровень 1: эмоции (настроение, анимации, взгляд, фразы). Уровень 2: ещё движение, сон и смена облика. */
    fun allowed(c: Context, ability: String): Boolean {
        val need = if (ability == "move" || ability == "sleep" || ability == "skin") 2 else 1
        return level(c) >= need && Prefs.b(c, "ai_ctl_" + ability)
    }

    fun moodOf(s: String?): Int = when (s?.trim()?.lowercase()) {
        "normal" -> 0
        "happy" -> 1
        "surprised" -> 2
        "sleepy" -> 3
        "smug" -> 4
        else -> -1
    }

    fun animOf(s: String?): Anim? {
        if (s == null) return null
        val k = s.trim().uppercase()
        return Anim.values().firstOrNull { it.name == k }
    }

    /** Часть системного запроса: что ИИ разрешено делать с Кики. */
    fun prompt(c: Context): String {
        if (level(c) == 0) return ""
        val parts = ArrayList<String>()
        if (allowed(c, "mood")) parts.add("mood (normal, happy, surprised, sleepy, smug)")
        if (allowed(c, "anim")) parts.add("anim (hop, wiggle, stretch, squish, spin_eyes, tilt, shake, purr, startle, bounce, wave_ears, flop)")
        if (allowed(c, "look")) parts.add("look (left, right, up, down, center)")
        if (allowed(c, "say")) parts.add("say (короткая фраза до 40 символов для облачка над Кики)")
        if (allowed(c, "move")) parts.add("move (left, right, jump, stop)")
        if (allowed(c, "sleep")) parts.add("sleep (1 или 0)")
        if (allowed(c, "skin")) parts.add("skin (classic, neon, snow)")
        if (parts.isEmpty()) return ""
        return " Ты можешь управлять собой. В самом начале ответа можно добавить ОДНУ служебную строку-тег вида <kiki mood=\"happy\" anim=\"hop\" say=\"Мур!\"/> (пользователь её не видит). Разрешённые поля: " +
            parts.joinToString(", ") + ". Используй теги к месту и не в каждом ответе. Сразу после тега пиши обычный ответ."
    }

    /** Возвращает текст без тегов и словарь указаний. */
    fun parse(text: String): Pair<String, Map<String, String>> {
        val map = HashMap<String, String>()
        for (m in tagRe.findAll(text)) {
            for (a in attrRe.findAll(m.groupValues[1])) map[a.groupValues[1].lowercase()] = a.groupValues[2].trim()
        }
        var clean = text.replace(tagRe, "").trim()
        if (clean.isEmpty()) clean = map["say"] ?: ""
        return Pair(clean, map)
    }
}
