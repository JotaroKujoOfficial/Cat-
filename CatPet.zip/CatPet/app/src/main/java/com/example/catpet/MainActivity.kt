package com.example.catpet

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

/** Панель помощника в стиле панели Pip: тёмная тема, оранжевый акцент, моноширинные подписи. */
class MainActivity : Activity() {
    private val BG = Color.parseColor("#0B0B0B")
    private val CARD = Color.parseColor("#141414")
    private val LINE = Color.parseColor("#2A2A2A")
    private val ORANGE = Color.parseColor("#FF4A1C")
    private val WHITE = Color.WHITE
    private val MUTED = Color.parseColor("#8A8A8A")

    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var avatar: CatView
    private lateinit var stateDot: TextView
    private lateinit var rowMood: TextView
    private lateinit var rowAi: TextView
    private lateinit var rowScreen: TextView
    private lateinit var rowOver: TextView
    private lateinit var runBtn: Button
    private val tabs = ArrayList<TextView>()
    private var tab = 0
    private var n = 0
    private var t = 0f
    private val h = Handler(Looper.getMainLooper())

    private val tickRun = object : Runnable {
        override fun run() {
            t += 0.1f
            n++
            avatar.lookX = sin(t * 0.8f) * 0.8f
            avatar.step(0.1f)
            if (n % 10 == 0) refreshStatus()
            h.postDelayed(this, 100)
        }
    }

    private fun dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun tv(text: String, size: Float, color: Int, mono: Boolean, bold: Boolean): TextView {
        val x = TextView(this)
        x.text = text
        x.textSize = size
        x.setTextColor(color)
        if (mono) x.typeface = Typeface.MONOSPACE
        if (bold) x.setTypeface(x.typeface, Typeface.BOLD)
        return x
    }

    private fun lp(top: Int): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        l.topMargin = dpi(top)
        return l
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dpi(14), dpi(8), dpi(14), dpi(8))
        val g = GradientDrawable()
        g.setColor(CARD)
        g.cornerRadius = dpi(14).toFloat()
        g.setStroke(dpi(1), LINE)
        l.background = g
        return l
    }

    private fun btn(text: String, primary: Boolean, f: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.setTextColor(WHITE)
        val g = GradientDrawable()
        g.setColor(if (primary) ORANGE else CARD)
        g.cornerRadius = dpi(12).toFloat()
        g.setStroke(dpi(1), if (primary) ORANGE else LINE)
        b.background = g
        b.setOnClickListener { f() }
        return b
    }

    private fun row(parent: LinearLayout, label: String): TextView {
        val r = LinearLayout(this)
        r.setPadding(0, dpi(3), 0, dpi(3))
        r.addView(tv(label, 10f, MUTED, true, false), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val v = tv("—", 11f, WHITE, true, false)
        r.addView(v)
        parent.addView(r)
        return v
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dpi(18), dpi(26), dpi(18), dpi(40))
        scroll.addView(root)
        setContentView(scroll)

        val head = LinearLayout(this)
        head.gravity = Gravity.BOTTOM
        head.addView(tv("КИКИ", 28f, WHITE, true, true))
        head.addView(tv("  ПАНЕЛЬ ПОМОЩНИКА", 10f, MUTED, true, false))
        root.addView(head)

        val st = card()
        st.orientation = LinearLayout.HORIZONTAL
        st.gravity = Gravity.CENTER_VERTICAL
        avatar = CatView(this)
        st.addView(avatar, LinearLayout.LayoutParams(dpi(120), dpi(120)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        stateDot = tv("", 15f, WHITE, false, true)
        col.addView(stateDot)
        rowMood = row(col, "НАСТРОЕНИЕ")
        rowAi = row(col, "ИИ")
        rowScreen = row(col, "ЭКРАН")
        rowOver = row(col, "ПОВЕРХ ЭКРАНА")
        st.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(st, lp(14))

        runBtn = btn("Запустить Кики", true) { toggleRun() }
        root.addView(runBtn, lp(12))
        root.addView(btn("Разрешить поверх экрана", false) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
        }, lp(8))
        root.addView(btn("Включить «Кики» в спец. возможностях", false) {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp(8))

        val tabBox = LinearLayout(this)
        val names = arrayOf("Настройки", "Дневник", "О Кики")
        for (i in names.indices) {
            val tt = tv(names[i], 14f, MUTED, true, false)
            tt.setPadding(dpi(4), dpi(10), dpi(14), dpi(10))
            tt.setOnClickListener { tab = i; showTab() }
            tabs.add(tt)
            tabBox.addView(tt)
        }
        root.addView(tabBox, lp(16))
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        root.addView(content, lp(4))
        showTab()
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        h.removeCallbacks(tickRun)
        h.post(tickRun)
    }

    override fun onPause() {
        h.removeCallbacks(tickRun)
        super.onPause()
    }

    private fun refreshStatus() {
        val svc = CatService.instance
        val running = svc != null
        stateDot.text = if (running) "● Работает" else "● Не запущен"
        stateDot.setTextColor(if (running) Color.parseColor("#3DDC84") else Color.parseColor("#FF5A5A"))
        rowMood.text = svc?.statusText() ?: "—"
        val prov = Prefs.i(this, "ai_provider")
        rowAi.text = when {
            prov == 0 -> "встроенные"
            Prefs.s(this, "ai_key").isBlank() -> "нет ключа"
            prov == 1 -> "Anthropic"
            else -> "OpenAI-совм."
        }
        rowScreen.text = if (SurfaceService.instance != null) "виден" else "не подключён"
        rowOver.text = if (Settings.canDrawOverlays(this)) "разрешено" else "нет"
        runBtn.text = if (running) "Остановить Кики" else "Запустить Кики"
    }

    private fun toggleRun() {
        if (CatService.instance != null) {
            stopService(Intent(this, CatService::class.java))
            h.postDelayed({ refreshStatus() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала разреши показ поверх экрана", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName)))
            return
        }
        startForegroundService(Intent(this, CatService::class.java))
        h.postDelayed({ refreshStatus() }, 600)
    }

    private fun showTab() {
        for (i in tabs.indices) {
            tabs[i].setTextColor(if (i == tab) ORANGE else MUTED)
            tabs[i].setTypeface(Typeface.MONOSPACE, if (i == tab) Typeface.BOLD else Typeface.NORMAL)
        }
        content.removeAllViews()
        when (tab) {
            0 -> buildSettings()
            1 -> buildJournal()
            else -> buildAbout()
        }
    }

    // ---------- настройки ----------

    private fun buildSettings() {
        for (s in SettingsDef.sections) {
            content.addView(tv("▌" + s.title, 11f, ORANGE, true, true), lp(18))
            val c = card()
            var first = true
            for (item in s.items) {
                if (!first) {
                    val line = View(this)
                    line.setBackgroundColor(LINE)
                    c.addView(line, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1))
                }
                first = false
                c.addView(itemView(item))
            }
            content.addView(c, lp(6))
        }
    }

    private fun paintSeg(v: TextView, on: Boolean) {
        val g = GradientDrawable()
        g.setColor(if (on) ORANGE else CARD)
        g.setStroke(dpi(1), if (on) ORANGE else LINE)
        g.cornerRadius = dpi(8).toFloat()
        v.background = g
    }

    private fun itemView(item: Item): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dpi(9), 0, dpi(9))
        when (item) {
            is Toggle -> {
                val rowL = LinearLayout(this)
                rowL.gravity = Gravity.CENTER_VERTICAL
                val col = LinearLayout(this)
                col.orientation = LinearLayout.VERTICAL
                col.addView(tv(item.title, 15f, WHITE, false, false))
                if (item.desc.isNotEmpty()) col.addView(tv(item.desc, 12f, MUTED, false, false))
                rowL.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                val sw = Switch(this)
                sw.isChecked = Prefs.b(this, item.key)
                sw.setOnCheckedChangeListener { _, v ->
                    Prefs.putB(this, item.key, v)
                    CatService.instance?.reloadPrefs()
                }
                rowL.addView(sw)
                box.addView(rowL)
            }
            is Choice -> {
                box.addView(tv(item.title, 15f, WHITE, false, false))
                if (item.desc.isNotEmpty()) box.addView(tv(item.desc, 12f, MUTED, false, false))
                val seg = LinearLayout(this)
                val views = ArrayList<TextView>()
                val cur = Prefs.i(this, item.key)
                for (i in item.options.indices) {
                    val o = tv(item.options[i], 12f, WHITE, true, false)
                    o.gravity = Gravity.CENTER
                    o.setPadding(dpi(6), dpi(8), dpi(6), dpi(8))
                    views.add(o)
                    o.setOnClickListener {
                        Prefs.putI(this, item.key, i)
                        for (j in views.indices) paintSeg(views[j], j == i)
                        CatService.instance?.reloadPrefs()
                        refreshStatus()
                    }
                    val sl = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    sl.rightMargin = dpi(4)
                    seg.addView(o, sl)
                }
                for (j in views.indices) paintSeg(views[j], j == cur)
                box.addView(seg, lp(8))
            }
            is Slider -> {
                val top = LinearLayout(this)
                top.addView(tv(item.title, 15f, WHITE, false, false), LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                val valT = tv("", 13f, ORANGE, true, true)
                top.addView(valT)
                box.addView(top)
                if (item.desc.isNotEmpty()) box.addView(tv(item.desc, 12f, MUTED, false, false))
                val sb = SeekBar(this)
                sb.max = item.max - item.min
                val cur = Prefs.i(this, item.key).coerceIn(item.min, item.max)
                sb.progress = cur - item.min
                valT.text = cur.toString() + item.unit
                sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        valT.text = (p + item.min).toString() + item.unit
                        if (fromUser) Prefs.putI(this@MainActivity, item.key, p + item.min)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { CatService.instance?.reloadPrefs() }
                })
                box.addView(sb, lp(4))
            }
            is Field -> {
                box.addView(tv(item.title, 15f, WHITE, false, false))
                if (item.desc.isNotEmpty()) box.addView(tv(item.desc, 12f, MUTED, false, false))
                val et = EditText(this)
                et.hint = item.hint
                et.setHintTextColor(Color.parseColor("#555555"))
                et.setTextColor(WHITE)
                et.setText(Prefs.s(this, item.key))
                if (item.secret) et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                et.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        Prefs.putS(this@MainActivity, item.key, (s?.toString() ?: "").trim())
                        refreshStatus()
                    }
                })
                box.addView(et)
            }
            is Info -> {
                box.addView(tv(item.title, 15f, WHITE, false, false))
                box.addView(tv(item.desc, 12f, MUTED, false, false))
            }
        }
        return box
    }

    // ---------- дневник ----------

    private fun buildJournal() {
        if (!Prefs.b(this, "journal_on")) {
            content.addView(tv("Дневник выключен. Включи его: Настройки → Экран и дневник.", 13f, MUTED, false, false), lp(8))
        }
        val bar = LinearLayout(this)
        val b1 = btn("Записать сейчас", false) { peekHere() }
        val b2 = btn("Очистить", false) { Journal.clear(this); showTab() }
        val l1 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        l1.rightMargin = dpi(6)
        bar.addView(b1, l1)
        bar.addView(b2, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(bar, lp(8))
        val list = Journal.all(this).reversed()
        if (list.isEmpty()) {
            content.addView(tv("Пока пусто.", 13f, MUTED, false, false), lp(12))
            return
        }
        val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
        for (e in list.take(100)) {
            val c = card()
            c.addView(tv(fmt.format(Date(e.time)) + "  " + e.app, 10f, ORANGE, true, false))
            c.addView(tv(e.text, 14f, WHITE, false, false))
            content.addView(c, lp(8))
        }
    }

    private fun peekHere() {
        val s = CatService.instance
        if (s == null) {
            Toast.makeText(this, "Сначала запусти Кики", Toast.LENGTH_SHORT).show()
        } else {
            s.peekNow()
            Toast.makeText(this, "Кики смотрит на экран…", Toast.LENGTH_SHORT).show()
            h.postDelayed({ showTab() }, 2500)
        }
    }

    // ---------- о Кики ----------

    private fun buildAbout() {
        val c = card()
        c.addView(tv("Кики", 18f, WHITE, true, true))
        c.addView(tv("Чёрный жидкий котик-помощник. Ходит по экрану, реагирует на твои действия и отвечает на вопросы.", 13f, MUTED, false, false), lp(4))
        c.addView(tv("Как пользоваться", 14f, ORANGE, true, true), lp(14))
        c.addView(tv("Тап по Кики открывает три окошка: «Разобрать задачу» (Кики читает экран и подсказывает решение), «Спросить» и «Удиви меня». Кики можно таскать пальцем. Если уронить его вниз экрана, он вернётся сверху.", 13f, WHITE, false, false), lp(4))
        c.addView(tv("Приватность", 14f, ORANGE, true, true), lp(14))
        c.addView(tv("Голос не слушается и не записывается. Текст экрана читается только по твоей просьбе или если ты сам включил заглядывание и дневник. Поля паролей не читаются никогда. Дневник хранится только на телефоне.", 13f, WHITE, false, false), lp(4))
        c.addView(tv("Версия 2.0", 11f, MUTED, true, false), lp(14))
        content.addView(c, lp(10))
    }
}
