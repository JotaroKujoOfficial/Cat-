package com.example.catpet

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

/** Панель Кики. Стиль видео про Pip: почти чёрный фон, оранжевый акцент; шрифты Tektur, Inter и Geist Mono; навигация снизу. */
class MainActivity : Activity() {
    private val BG = Color.parseColor("#060606")
    private val CARD = Color.parseColor("#0F0E11")
    private val LINE = Color.parseColor("#232227")
    private val FIELD = Color.parseColor("#09090B")
    private val ORANGE = Color.parseColor("#ED4A1D")
    private val OKC = Color.parseColor("#3DDC84")
    private val BAD = Color.parseColor("#FF5A5A")
    private val WHITE = Color.parseColor("#F2F2F4")
    private val MUTED = Color.parseColor("#8C8C94")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private lateinit var fReg: Typeface
    private lateinit var fSemi: Typeface
    private lateinit var fDisp: Typeface
    private lateinit var fMono: Typeface
    private lateinit var fMonoB: Typeface

    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private val navGlyph = ArrayList<TextView>()
    private val navLabel = ArrayList<TextView>()
    private var tab = 0
    private var sub = 0

    private var homeAvatar: CatView? = null
    private var avatarFrame: FrameLayout? = null
    private var stateChip: TextView? = null
    private var statMood: TextView? = null
    private var statAi: TextView? = null
    private var statScreen: TextView? = null
    private var runBtn: Button? = null
    private var setupBox: LinearLayout? = null
    private var previewCat: CatView? = null
    private var lastSig = ""
    private var relayMsg = ""
    private var relayOk = false
    private var n = 0
    private var t = 0f
    private val h = Handler(Looper.getMainLooper())

    private val tickRun = object : Runnable {
        override fun run() {
            t += 0.1f
            n++
            val a = homeAvatar
            if (a != null) { a.lookX = sin(t * 0.8f) * 0.8f; a.step(0.1f) }
            val pv = previewCat
            if (pv != null) { pv.lookX = sin(t * 0.6f) * 0.9f; pv.step(0.1f) }
            if (n % 10 == 0) refreshStatus()
            h.postDelayed(this, 100)
        }
    }

    // ---------- помощники ----------

    private fun dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** style: 0 текст, 1 полужирный, 2 заголовочный (Tektur), 3 моно, 4 моно жирный */
    private fun tv(text: String, size: Float, color: Int, style: Int = 0): TextView {
        val x = TextView(this)
        x.text = text
        x.textSize = size
        x.setTextColor(color)
        x.typeface = when (style) { 1 -> fSemi; 2 -> fDisp; 3 -> fMono; 4 -> fMonoB; else -> fReg }
        if (style >= 3) x.letterSpacing = 0.08f
        return x
    }

    private fun lpTop(top: Int): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(MATCH, WRAP)
        l.topMargin = dpi(top)
        return l
    }

    private fun shape(color: Int, stroke: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dpi(r).toFloat()
        if (stroke != 0) g.setStroke(dpi(1), stroke)
        return g
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dpi(18), dpi(16), dpi(18), dpi(16))
        l.background = shape(CARD, LINE, 20)
        return l
    }

    private fun label(text: String): TextView = tv(text, 10.5f, MUTED, 3)

    private fun pbtn(text: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 15f
        b.typeface = fSemi
        b.setTextColor(Color.WHITE)
        b.background = shape(ORANGE, 0, 14)
        b.stateListAnimator = null
        b.minHeight = dpi(52)
        b.setOnClickListener { f() }
        return b
    }

    private fun sbtn(text: String, small: Boolean, f: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = if (small) 13f else 14.5f
        b.typeface = fSemi
        b.setTextColor(WHITE)
        b.background = shape(FIELD, LINE, 14)
        b.stateListAnimator = null
        b.minHeight = dpi(if (small) 40 else 48)
        b.setOnClickListener { f() }
        return b
    }

    private fun field(hint: String, text: String, secret: Boolean): EditText {
        val et = EditText(this)
        et.hint = hint
        et.setHintTextColor(Color.parseColor("#5A5A62"))
        et.setTextColor(WHITE)
        et.typeface = fReg
        et.textSize = 14.5f
        et.setSingleLine(true)
        et.setText(text)
        et.setPadding(dpi(14), dpi(12), dpi(14), dpi(12))
        et.background = shape(FIELD, LINE, 12)
        et.inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
        return et
    }

    private fun tint(on: Int, off: Int): ColorStateList =
        ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(on, off))

    private fun toast(s: String) { Toast.makeText(this, s, Toast.LENGTH_LONG).show() }

    private fun clipText(): String? {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val t = cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim()
        return if (t.isNullOrEmpty()) null else t
    }

    private fun copyText(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Кики", text))
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Exception) {}
    }

    private fun pageTitle(title: String, subtitle: String) {
        content.addView(tv(title, 32f, WHITE, 2))
        content.addView(tv(subtitle, 10f, MUTED, 3))
    }

    // ---------- окно и навигация ----------

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        fReg = Fonts.regular(this)
        fSemi = Fonts.semibold(this)
        fDisp = Fonts.bold(this)
        fMono = Fonts.mono(this)
        fMonoB = Fonts.monoBold(this)
        window.statusBarColor = BG
        window.navigationBarColor = Color.parseColor("#0B0A0D")
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val root = FrameLayout(this)
        root.setBackgroundColor(BG)
        scroll = ScrollView(this)
        scroll.clipToPadding = false
        scroll.setPadding(0, 0, 0, dpi(84))
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dpi(18), dpi(24), dpi(18), dpi(24))
        scroll.addView(content)
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        val nav = LinearLayout(this)
        nav.setBackgroundColor(Color.parseColor("#0B0A0D"))
        nav.setPadding(0, dpi(8), 0, dpi(8))
        val glyphs = arrayOf("◉", "◐", "◈", "✦", "≡")
        for (i in SettingsDef.tabNames.indices) {
            val item = LinearLayout(this)
            item.orientation = LinearLayout.VERTICAL
            item.gravity = Gravity.CENTER_HORIZONTAL
            val g = TextView(this)
            g.text = glyphs[i]
            g.textSize = 20f
            g.gravity = Gravity.CENTER
            g.setPadding(dpi(18), dpi(4), dpi(18), dpi(4))
            val lb = tv(SettingsDef.tabNames[i], 10f, MUTED, 3)
            lb.gravity = Gravity.CENTER
            item.addView(g)
            item.addView(lb, lpTop(2))
            item.setOnClickListener { selectTab(i) }
            nav.addView(item, LinearLayout.LayoutParams(0, WRAP, 1f))
            navGlyph.add(g)
            navLabel.add(lb)
        }
        val nlp = FrameLayout.LayoutParams(MATCH, WRAP)
        nlp.gravity = Gravity.BOTTOM
        root.addView(nav, nlp)
        setContentView(root)
        selectTab(0)
    }

    private fun selectTab(i: Int) {
        tab = i
        sub = 0
        for (k in navGlyph.indices) {
            val on = k == i
            navGlyph[k].setTextColor(if (on) ORANGE else MUTED)
            navGlyph[k].background = if (on) shape(Color.parseColor("#2A1710"), 0, 16) else null
            navLabel[k].setTextColor(if (on) WHITE else MUTED)
        }
        rebuild()
        scroll.scrollTo(0, 0)
    }

    private fun rebuild() {
        previewCat = null
        homeAvatar = null
        avatarFrame = null
        stateChip = null
        statMood = null
        statAi = null
        statScreen = null
        runBtn = null
        setupBox = null
        lastSig = ""
        content.removeAllViews()
        content.alpha = 0f
        when (tab) {
            0 -> buildHome()
            1 -> buildSkins()
            2 -> { pageTitle("Поведение", "ХОД, СОН, РЕАКЦИИ"); addSections(2) }
            3 -> if (sub == 1) buildRelay() else buildAi()
            else -> buildMore()
        }
        content.animate().alpha(1f).setDuration(180).start()
        refreshStatus()
    }

    override fun onResume() {
        super.onResume()
        styleAvatar()
        refreshStatus()
        h.removeCallbacks(tickRun)
        h.post(tickRun)
    }

    override fun onPause() {
        h.removeCallbacks(tickRun)
        super.onPause()
    }

    // ---------- разрешения ----------

    private fun a11yOn(): Boolean {
        if (SurfaceService.instance != null) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName + "/")
    }

    private fun a11yConnected(): Boolean = SurfaceService.instance != null

    private fun notifOn(): Boolean =
        Build.VERSION.SDK_INT < 33 || checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED

    private fun batteryOk(): Boolean = try {
        (getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Exception) { true }

    private fun openAppInfo() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))) }
        catch (_: Exception) {}
    }

    private fun openOverlay() {
        try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))) }
        catch (_: Exception) { openAppInfo() }
    }

    private fun openA11y() {
        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        catch (_: Exception) { openAppInfo() }
    }

    private fun openBattery() {
        try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + packageName))) }
        catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (_: Exception) { openAppInfo() }
        }
    }

    private fun stepView(num: Int, title: String, desc: String, done: Boolean, doneText: String,
                         actions: List<Pair<String, () -> Unit>>): View {
        val row = LinearLayout(this)
        row.setPadding(0, dpi(12), 0, dpi(12))
        val badge = TextView(this)
        badge.text = if (done) "✓" else num.toString()
        badge.gravity = Gravity.CENTER
        badge.setTextColor(Color.WHITE)
        badge.typeface = fMonoB
        badge.textSize = 12f
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(if (done) OKC else ORANGE)
        badge.background = bg
        row.addView(badge, LinearLayout.LayoutParams(dpi(28), dpi(28)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv(title, 15f, if (done) OKC else WHITE, 2))
        col.addView(tv(if (done) doneText else desc, 13f, MUTED, 0), lpTop(4))
        if (!done) {
            for ((text, fn) in actions) col.addView(sbtn(text, true) { fn() }, lpTop(10))
        }
        val cl = LinearLayout.LayoutParams(0, WRAP, 1f)
        cl.leftMargin = dpi(14)
        row.addView(col, cl)
        return row
    }

    private fun buildSetup() {
        val box = setupBox ?: return
        box.removeAllViews()
        val overlay = Settings.canDrawOverlays(this)
        val a11y = a11yOn()
        val notif = notifOn()
        val battery = batteryOk()
        val lost = Prefs.b(this, "a11y_seen") && !a11y
        if (lost) {
            box.addView(tv("Чтение экрана выключилось", 15f, BAD, 2))
            box.addView(tv("Так бывает, когда система «чистит» приложения в фоне. Включи службу снова и выдай шаг «Не засыпать» ниже, тогда это случается реже.", 13f, MUTED, 0), lpTop(4))
        }
        if (overlay && a11y && a11yConnected() && notif && battery) {
            box.addView(tv("✓  Всё настроено", 14f, OKC, 3))
            return
        }
        box.addView(label("НАСТРОЙКА"))
        box.addView(stepView(1, "Поверх экрана", "Чтобы Кики мог гулять поверх других приложений.", overlay, "выдано",
            listOf(Pair<String, () -> Unit>("Выдать разрешение", { openOverlay() }))))
        val a11yActions = ArrayList<Pair<String, () -> Unit>>()
        a11yActions.add(Pair<String, () -> Unit>("Открыть настройки служб", { openA11y() }))
        if (Build.VERSION.SDK_INT >= 33) a11yActions.add(Pair<String, () -> Unit>("Сведения о приложении", { openAppInfo() }))
        val a11yDesc = if (Build.VERSION.SDK_INT >= 33)
            "Включи «Кики» в списке служб. Если переключатель серый: открой «Сведения о приложении», нажми ⋮ вверху справа, выбери «Разрешить ограниченные настройки», вернись и включи службу."
        else "Включи «Кики» в списке служб. Нужно, чтобы Кики ходил по кнопкам и разбирал задачи с экрана."
        val connected = a11yConnected()
        val a11yDone = a11y && connected
        val a11yText = if (a11y && !connected) "Служба включена в настройках, но не подключилась. Выключи «Кики» в списке служб и включи снова." else a11yDesc
        box.addView(stepView(2, "Чтение экрана", a11yText, a11yDone, "включено", a11yActions))
        var num = 3
        if (Build.VERSION.SDK_INT >= 33) {
            box.addView(stepView(num, "Уведомления", "Чтобы можно было позвать Кики из шторки.", notif, "разрешено",
                listOf(Pair<String, () -> Unit>("Разрешить", { requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1) }))))
            num++
        }
        box.addView(stepView(num, "Не засыпать", "Чтобы система не выключала Кики и чтение экрана. На Xiaomi, Huawei, Samsung и Oppo ещё включи «Автозапуск» и закрепи приложение в списке недавних.", battery, "разрешено",
            listOf(Pair<String, () -> Unit>("Разрешить работу в фоне", { openBattery() }))))
    }

    private fun refreshStatus() {
        val svc = CatService.instance
        val running = svc != null
        val chip = stateChip
        if (chip != null) {
            chip.text = if (running) "● РАБОТАЕТ" else "● НЕ ЗАПУЩЕН"
            chip.setTextColor(if (running) OKC else BAD)
            chip.background = shape(Color.parseColor(if (running) "#0E2318" else "#2A1214"), 0, 20)
        }
        statMood?.text = svc?.statusText() ?: "—"
        statAi?.text = if (Ai.ready(this)) Prefs.s(this, "ai_name").substringBefore(' ') else "встроенный"
        statScreen?.text = if (a11yConnected()) "виден" else if (a11yOn()) "ждёт" else "нет"
        runBtn?.text = if (running) "Остановить Кики" else "Запустить Кики"
        if (tab == 0) {
            val sig = "" + Settings.canDrawOverlays(this) + a11yOn() + a11yConnected() + notifOn() + batteryOk() + running
            if (sig != lastSig) { lastSig = sig; buildSetup(); styleAvatar() }
        }
    }

    private fun toggleRun() {
        if (CatService.instance != null) {
            stopService(Intent(this, CatService::class.java))
            h.postDelayed({ refreshStatus() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Сначала выдай разрешение «Поверх экрана» (шаг 1)")
            openOverlay()
            return
        }
        startForegroundService(Intent(this, CatService::class.java))
        h.postDelayed({ refreshStatus() }, 600)
    }

    private fun cmdCat(action: String) {
        if (CatService.instance == null) { toast("Сначала запусти Кики"); return }
        val i = Intent(this, CatService::class.java)
        i.action = action
        startService(i)
    }

    // ---------- главная ----------

    private fun statCell(parent: LinearLayout, labelText: String): TextView {
        val cell = LinearLayout(this)
        cell.orientation = LinearLayout.VERTICAL
        cell.setPadding(dpi(12), dpi(10), dpi(12), dpi(10))
        cell.background = shape(FIELD, LINE, 14)
        cell.addView(tv(labelText, 9.5f, MUTED, 3))
        val v = tv("—", 13f, WHITE, 2)
        cell.addView(v, lpTop(4))
        val l = LinearLayout.LayoutParams(0, WRAP, 1f)
        l.leftMargin = dpi(if (parent.childCount > 0) 8 else 0)
        parent.addView(cell, l)
        return v
    }

    private fun styleAvatar() {
        val av = homeAvatar ?: return
        val fr = avatarFrame ?: return
        val sk = Skins.current(this)
        av.applySkin(sk)
        val lum = (Color.red(sk.body) * 299 + Color.green(sk.body) * 587 + Color.blue(sk.body) * 114) / 1000
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (lum < 110) Color.parseColor("#E4E4E9") else Color.parseColor("#1A1A20"))
        g.setStroke(dpi(3), if (CatService.instance != null) ORANGE else Color.parseColor("#2C2C31"))
        fr.background = g
    }

    private fun buildHome() {
        val hero = card()
        val top = LinearLayout(this)
        top.gravity = Gravity.CENTER_VERTICAL
        val titleCol = LinearLayout(this)
        titleCol.orientation = LinearLayout.VERTICAL
        titleCol.addView(tv("Кики", 44f, WHITE, 2))
        titleCol.addView(tv("ИИ-ПОМОЩНИК НА ЭКРАНЕ", 10f, MUTED, 3))
        top.addView(titleCol, LinearLayout.LayoutParams(0, WRAP, 1f))
        val chip = tv("", 11.5f, WHITE, 3)
        chip.setPadding(dpi(12), dpi(7), dpi(12), dpi(7))
        stateChip = chip
        top.addView(chip)
        hero.addView(top)

        val frame = FrameLayout(this)
        frame.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) { outline.setOval(0, 0, view.width, view.height) }
        }
        frame.clipToOutline = true
        avatarFrame = frame
        val av = CatView(this)
        homeAvatar = av
        val fl = FrameLayout.LayoutParams(dpi(172), dpi(172))
        fl.gravity = Gravity.CENTER
        frame.addView(av, fl)
        val flp = LinearLayout.LayoutParams(dpi(150), dpi(150))
        flp.gravity = Gravity.CENTER_HORIZONTAL
        flp.topMargin = dpi(18)
        hero.addView(frame, flp)

        val stats = LinearLayout(this)
        statMood = statCell(stats, "НАСТРОЕНИЕ")
        statAi = statCell(stats, "ИИ")
        statScreen = statCell(stats, "ЭКРАН")
        hero.addView(stats, lpTop(18))
        val rb = pbtn("Запустить Кики") { toggleRun() }
        rb.minHeight = dpi(56)
        runBtn = rb
        hero.addView(rb, lpTop(16))
        content.addView(hero)

        val box = card()
        setupBox = box
        content.addView(box, lpTop(14))

        val qa = card()
        qa.addView(label("БЫСТРЫЕ ДЕЙСТВИЯ"))
        val row = LinearLayout(this)
        val l1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        l1.rightMargin = dpi(8)
        row.addView(sbtn("Позвать", false) { cmdCat(CatService.ACT_SHOW) }, l1)
        row.addView(sbtn("Спрятать", false) { cmdCat(CatService.ACT_HIDE) }, LinearLayout.LayoutParams(0, WRAP, 1f))
        qa.addView(row, lpTop(12))
        qa.addView(sbtn("Быстрый чат", false) {
            val s = CatService.instance
            if (s == null) toast("Сначала запусти Кики") else s.openQuickFromApp()
        }, lpTop(8))
        qa.addView(sbtn("Проверить чтение экрана", false) {
            val svc = CatService.instance
            if (svc == null) toast("Сначала запусти Кики") else svc.diagnose()
        }, lpTop(8))
        qa.addView(sbtn("Подключить ИИ", false) { selectTab(3) }, lpTop(8))
        content.addView(qa, lpTop(14))
        styleAvatar()
    }

    // ---------- общие настройки ----------

    private fun addSections(tabIdx: Int) {
        for (s in SettingsDef.sections) {
            if (s.tab != tabIdx) continue
            if (s.title == "РЕТРАНСЛЯТОР И ПРОКСИ ВРУЧНУЮ") addRelayEntry()
            val c = card()
            c.addView(label(s.title))
            for (item in s.items) {
                val line = View(this)
                line.setBackgroundColor(LINE)
                c.addView(line, LinearLayout.LayoutParams(MATCH, 1).also { it.topMargin = dpi(12) })
                c.addView(itemView(item))
            }
            content.addView(c, lpTop(14))
        }
    }

    private fun paintSeg(v: TextView, on: Boolean) {
        v.background = shape(if (on) ORANGE else FIELD, if (on) ORANGE else LINE, 12)
        v.setTextColor(if (on) Color.WHITE else MUTED)
    }

    private fun itemView(item: Item): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dpi(12), 0, dpi(2))
        when (item) {
            is Toggle -> {
                val rowL = LinearLayout(this)
                rowL.gravity = Gravity.CENTER_VERTICAL
                val col = LinearLayout(this)
                col.orientation = LinearLayout.VERTICAL
                col.addView(tv(item.title, 15f, WHITE, 1))
                if (item.desc.isNotEmpty()) col.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
                rowL.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
                val sw = Switch(this)
                sw.isChecked = Prefs.b(this, item.key)
                sw.thumbTintList = tint(Color.WHITE, Color.parseColor("#9A9AA2"))
                sw.trackTintList = tint(ORANGE, Color.parseColor("#2A2A30"))
                sw.setOnCheckedChangeListener { _, v ->
                    Prefs.putB(this, item.key, v)
                    CatService.instance?.reloadPrefs()
                    styleAvatar()
                    previewCat?.applySkin(Skins.current(this))
                }
                rowL.addView(sw)
                box.addView(rowL)
            }
            is Choice -> {
                box.addView(tv(item.title, 15f, WHITE, 1))
                if (item.desc.isNotEmpty()) box.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
                val seg = LinearLayout(this)
                val views = ArrayList<TextView>()
                val cur = Prefs.i(this, item.key)
                for (i in item.options.indices) {
                    val o = tv(item.options[i], 12.5f, WHITE, 1)
                    o.gravity = Gravity.CENTER
                    o.setPadding(dpi(6), dpi(11), dpi(6), dpi(11))
                    views.add(o)
                    o.setOnClickListener {
                        Prefs.putI(this, item.key, i)
                        for (j in views.indices) paintSeg(views[j], j == i)
                        CatService.instance?.reloadPrefs()
                    }
                    val sl = LinearLayout.LayoutParams(0, WRAP, 1f)
                    if (i > 0) sl.leftMargin = dpi(6)
                    seg.addView(o, sl)
                }
                for (j in views.indices) paintSeg(views[j], j == cur)
                box.addView(seg, lpTop(10))
            }
            is Slider -> {
                val top = LinearLayout(this)
                top.addView(tv(item.title, 15f, WHITE, 1), LinearLayout.LayoutParams(0, WRAP, 1f))
                val valT = tv("", 13f, ORANGE, 4)
                top.addView(valT)
                box.addView(top)
                if (item.desc.isNotEmpty()) box.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
                val sb = SeekBar(this)
                sb.max = item.max - item.min
                val cur = Prefs.i(this, item.key).coerceIn(item.min, item.max)
                sb.progress = cur - item.min
                sb.progressTintList = ColorStateList.valueOf(ORANGE)
                sb.thumbTintList = ColorStateList.valueOf(ORANGE)
                valT.text = cur.toString() + item.unit
                sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        valT.text = (p + item.min).toString() + item.unit
                        if (fromUser) Prefs.putI(this@MainActivity, item.key, p + item.min)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { CatService.instance?.reloadPrefs() }
                })
                box.addView(sb, lpTop(4))
            }
            is Field -> {
                box.addView(tv(item.title, 15f, WHITE, 1))
                if (item.desc.isNotEmpty()) box.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
                val et = field(item.hint, Prefs.s(this, item.key), item.secret)
                et.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        Prefs.putS(this@MainActivity, item.key, (s?.toString() ?: "").trim())
                    }
                })
                box.addView(et, lpTop(8))
            }
            is Info -> {
                box.addView(tv(item.title, 15f, WHITE, 1))
                box.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
            }
        }
        return box
    }

    // ---------- облик ----------

    private fun afterSkin() {
        CatService.instance?.reloadPrefs()
        styleAvatar()
        previewCat?.applySkin(Skins.current(this))
    }

    private fun swatchRow(current: Int, onPick: (Int) -> Unit): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        val colors = Skins.palette
        val dots = ArrayList<View>()
        fun refresh(sel: Int) {
            for (i in dots.indices) {
                val g = GradientDrawable()
                g.shape = GradientDrawable.OVAL
                g.setColor(colors[i])
                g.setStroke(dpi(if (colors[i] == sel) 3 else 1), if (colors[i] == sel) Color.WHITE else Color.parseColor("#3A3A42"))
                dots[i].background = g
            }
        }
        for (i in colors.indices) {
            val v = View(this)
            dots.add(v)
            val col = colors[i]
            v.setOnClickListener { onPick(col); refresh(col) }
            val l = LinearLayout.LayoutParams(dpi(36), dpi(36))
            l.rightMargin = dpi(8)
            row.addView(v, l)
        }
        refresh(current)
        hs.addView(row)
        return hs
    }

    private fun buildSkins() {
        pageTitle("Облик", "ФОРМА, ЦВЕТ, АКСЕССУАРЫ")
        val c = card()
        c.addView(label("ПРЕДПРОСМОТР"))
        val pvBox = FrameLayout(this)
        pvBox.background = shape(Color.parseColor("#9A9AA2"), 0, 16)
        val pv = CatView(this)
        pv.applySkin(Skins.current(this))
        previewCat = pv
        val pl = FrameLayout.LayoutParams(dpi(182), dpi(182))
        pl.gravity = Gravity.CENTER
        pvBox.addView(pv, pl)
        c.addView(pvBox, LinearLayout.LayoutParams(MATCH, dpi(190)).also { it.topMargin = dpi(12) })
        content.addView(c, lpTop(16))

        val c1 = card()
        c1.addView(label("СКИНЫ"))
        val cur = Prefs.i(this, "skin_id")
        var rowL: LinearLayout? = null
        for (i in Skins.names.indices) {
            if (i % 3 == 0) {
                val r = LinearLayout(this)
                c1.addView(r, lpTop(if (i == 0) 12 else 8))
                rowL = r
            }
            val tile = LinearLayout(this)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER_HORIZONTAL
            tile.setPadding(dpi(4), dpi(6), dpi(4), dpi(8))
            tile.background = shape(FIELD, if (cur == i) ORANGE else LINE, 14)
            val pad = FrameLayout(this)
            pad.background = shape(Color.parseColor("#9A9AA2"), 0, 10)
            val mini = CatView(this)
            mini.applySkin(Skins.preset(i))
            val ml = FrameLayout.LayoutParams(dpi(88), dpi(88))
            ml.gravity = Gravity.CENTER
            pad.addView(mini, ml)
            tile.addView(pad, LinearLayout.LayoutParams(MATCH, dpi(84)))
            val nm = tv(Skins.names[i], 11.5f, WHITE, 1)
            nm.gravity = Gravity.CENTER
            tile.addView(nm, lpTop(6))
            val idx = i
            tile.setOnClickListener { Skins.applyPreset(this, idx); afterSkin(); rebuild() }
            val l = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (i % 3 != 0) l.leftMargin = dpi(8)
            rowL?.addView(tile, l)
        }
        if (cur == Skins.CUSTOM) c1.addView(tv("Сейчас выбран твой набор цветов.", 12.5f, MUTED, 0), lpTop(10))
        content.addView(c1, lpTop(14))

        val c2 = card()
        c2.addView(label("СВОИ ЦВЕТА"))
        c2.addView(tv("Цвет каждой части. Форма остаётся выбранной, скин станет «своим».", 13f, MUTED, 0), lpTop(8))
        val parts = arrayOf(Pair("Тело", "skin_body"), Pair("Контур", "skin_outline"), Pair("Внутри ушей", "skin_inner"),
            Pair("Белки глаз", "skin_eye"), Pair("Зрачки", "skin_pupil"), Pair("Нос и рот", "skin_line"))
        for (pt in parts) {
            val key = pt.second
            c2.addView(tv(pt.first, 14f, WHITE, 1), lpTop(14))
            c2.addView(swatchRow(Skins.colorOf(this, key)) { col -> Skins.setCustom(this, key, col); afterSkin() }, lpTop(8))
        }
        content.addView(c2, lpTop(14))

        val c3 = card()
        c3.addView(label("АКСЕССУАРЫ"))
        c3.addView(itemView(Toggle("skin_collar_on", "Ошейник с бубенчиком", "Показывает ошейник на Кики", false)))
        c3.addView(tv("Цвет ошейника", 14f, WHITE, 1), lpTop(14))
        c3.addView(swatchRow(Skins.colorOf(this, "skin_collar")) { col -> Skins.setCustom(this, "skin_collar", col); afterSkin() }, lpTop(8))
        content.addView(c3, lpTop(14))
        addIconPicker()
        addSections(1)
    }

    // ---------- иконка приложения ----------

    private val iconAliases = arrayOf("IconClassic", "IconSmooth", "IconGrumpy", "IconGeo", "IconGeo2")
    private val iconNames = arrayOf("Классика", "Гладкий", "Хмурый", "Геометрия", "Геометрия II")
    private val iconRes = intArrayOf(R.drawable.icon_pv_0, R.drawable.icon_pv_1, R.drawable.icon_pv_2, R.drawable.icon_pv_3, R.drawable.icon_pv_4)

    private fun iconSel(): Int {
        val v = Prefs.i(this, "icon_sel")
        return if (v <= 0) 1 else v - 1
    }

    private fun setLauncherIcon(idx: Int) {
        try {
            for (i in iconAliases.indices) {
                val cn = ComponentName(packageName, "com.example.catpet." + iconAliases[i])
                packageManager.setComponentEnabledSetting(cn,
                    if (i == idx) PackageManager.COMPONENT_ENABLED_STATE_ENABLED else PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP)
            }
            Prefs.putI(this, "icon_sel", idx + 1)
            toast("Иконка сменится через несколько секунд. Если нет, закрой и открой приложение.")
        } catch (e: Exception) {
            toast("Не получилось сменить иконку на этом телефоне.")
        }
    }

    private fun addIconPicker() {
        val c = card()
        c.addView(label("ИКОНКА ПРИЛОЖЕНИЯ"))
        c.addView(tv("Выбери, как приложение выглядит на экране телефона.", 13f, MUTED, 0), lpTop(8))
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val row = LinearLayout(this)
        val cur = iconSel()
        for (i in iconAliases.indices) {
            val tile = LinearLayout(this)
            tile.orientation = LinearLayout.VERTICAL
            tile.gravity = Gravity.CENTER_HORIZONTAL
            tile.setPadding(dpi(8), dpi(8), dpi(8), dpi(8))
            tile.background = shape(FIELD, if (cur == i) ORANGE else LINE, 14)
            val img = ImageView(this)
            img.setImageResource(iconRes[i])
            tile.addView(img, LinearLayout.LayoutParams(dpi(64), dpi(64)))
            val nm = tv(iconNames[i], 11f, WHITE, 1)
            nm.gravity = Gravity.CENTER
            tile.addView(nm, lpTop(6))
            val idx = i
            tile.setOnClickListener { setLauncherIcon(idx); rebuild() }
            val l = LinearLayout.LayoutParams(dpi(92), WRAP)
            l.rightMargin = dpi(8)
            row.addView(tile, l)
        }
        hs.addView(row)
        c.addView(hs, lpTop(12))
        content.addView(c, lpTop(14))
    }

    // ---------- ИИ ----------

    private fun buildAi() {
        pageTitle("ИИ", "ПОДКЛЮЧЕНИЕ · УПРАВЛЕНИЕ")
        addAiCard()
        addKeySources()
        addSections(3)
    }

    private fun addAiCard() {
        val c = card()
        c.addView(label("ПОДКЛЮЧЕНИЕ"))
        val on = Ai.ready(this)
        c.addView(tv(
            if (on) "●  Подключено: " + Prefs.s(this, "ai_name") + " · " + Prefs.s(this, "ai_model")
            else "●  Не подключено. Пока работает встроенный помощник.",
            13f, if (on) OKC else MUTED, 3), lpTop(10))
        c.addView(tv("1. Скопируй ключ на сайте сервиса (ниже есть кнопки).\n2. Вернись сюда и нажми оранжевую кнопку.\nВсё остальное Кики сделает сам.", 13.5f, WHITE, 0), lpTop(10))

        val comp = field("Компания (необязательно)", Prefs.s(this, "ai_company"), false)
        val key = field("Ключ (API key)", Prefs.s(this, "ai_key"), true)
        val status = tv("", 13f, MUTED, 0)
        val details = tv("", 11.5f, MUTED, 3)
        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.VERTICAL
        val btns = ArrayList<Button>()

        val runConnect: () -> Unit = {
            val cmp = comp.text.toString()
            val k = key.text.toString()
            status.text = "Проверяю ключ…"
            status.setTextColor(MUTED)
            details.text = ""
            actions.removeAllViews()
            for (b in btns) b.isEnabled = false
            Thread {
                val r = try { Ai.connect(applicationContext, cmp, k) }
                catch (e: Exception) { AiResult(false, false, "Ошибка: " + (e.message ?: "неизвестно"), "", "other") }
                runOnUiThread {
                    for (b in btns) b.isEnabled = true
                    if (r.ok) {
                        toast(r.message)
                        rebuild()
                    } else {
                        status.text = "✕  " + r.message
                        status.setTextColor(BAD)
                        details.text = r.details
                        if (r.kind == "region" || r.kind == "net") {
                            actions.addView(pbtn("Настроить ретранслятор") { sub = 1; rebuild() }, lpTop(10))
                            actions.addView(sbtn("Взять ключ OpenRouter", true) { openUrl("https://openrouter.ai/keys") }, lpTop(8))
                        } else if (r.kind == "money") {
                            actions.addView(sbtn("Ключ Google Gemini", true) { openUrl("https://aistudio.google.com/apikey") }, lpTop(10))
                            actions.addView(sbtn("Ключ OpenRouter", true) { openUrl("https://openrouter.ai/keys") }, lpTop(8))
                        }
                    }
                }
            }.start()
        }

        val one = pbtn("Вставить ключ и подключить") {
            val t = clipText()
            if (t == null) toast("Сначала скопируй ключ на сайте сервиса")
            else { key.setText(t); runConnect() }
        }
        btns.add(one)
        c.addView(one, lpTop(14))

        c.addView(tv("или вручную", 11f, MUTED, 3), lpTop(16))
        val chips = HorizontalScrollView(this)
        chips.isHorizontalScrollBarEnabled = false
        val chipRow = LinearLayout(this)
        for (nm in arrayOf("DeepSeek", "OpenAI", "Gemini", "Groq", "Grok", "OpenRouter", "Claude", "Mistral")) {
            val b = sbtn(nm, true) { comp.setText(nm) }
            val l = LinearLayout.LayoutParams(WRAP, WRAP)
            l.rightMargin = dpi(6)
            chipRow.addView(b, l)
        }
        chips.addView(chipRow)
        c.addView(chips, lpTop(8))
        c.addView(comp, lpTop(10))
        c.addView(key, lpTop(8))
        val go = sbtn("Подключить", false) { runConnect() }
        btns.add(go)
        c.addView(go, lpTop(10))
        c.addView(status, lpTop(12))
        c.addView(details, lpTop(6))
        c.addView(actions)
        if (on) {
            c.addView(sbtn("Проверить управление Кики", true) { testControl() }, lpTop(12))
            c.addView(sbtn("Отключить ИИ", true) { Ai.disconnect(this); rebuild() }, lpTop(8))
        }
        content.addView(c, lpTop(16))
    }

    private fun testControl() {
        val svc = CatService.instance
        if (svc == null) { toast("Сначала запусти Кики"); return }
        toast("Прошу ИИ подпрыгнуть и помахать ушами…")
        Thread {
            val m = org.json.JSONArray().put(org.json.JSONObject().put("role", "user").put("content", "Покажи, что умеешь: порадуйся, подпрыгни и скажи привет."))
            val res = try { Ai.ask(applicationContext, m, 120) } catch (e: Exception) { "ERR:" + (e.message ?: "") }
            runOnUiThread {
                if (res.startsWith("ERR:")) { toast(res.removePrefix("ERR:")); return@runOnUiThread }
                val p = Control.parse(res)
                if (p.second.isEmpty()) toast("Модель не прислала команды для Кики, он будет реагировать по смыслу ответа. Эта модель плохо следует инструкциям.")
                else toast("Команды получены: " + p.second.keys.joinToString(", "))
                svc.applyDirectives(if (p.second.isEmpty()) Control.guess(p.first) else p.second)
            }
        }.start()
    }

    private fun addKeySources() {
        val c = card()
        c.addView(label("ГДЕ ВЗЯТЬ КЛЮЧ"))
        c.addView(tv("Ключ (API key) — длинная строка из раздела API keys на сайте сервиса. Подписка ChatGPT или Claude — не ключ. Стоимость, лимиты и доступность по странам у каждого сервиса свои и меняются: смотри на их сайте. Grok и ряд других могут открываться там, где другие закрыты.", 13f, MUTED, 0), lpTop(8))
        val rows = arrayOf(
            arrayOf("OpenRouter", "условия на сайте", "https://openrouter.ai/keys"),
            arrayOf("Google Gemini", "условия на сайте", "https://aistudio.google.com/apikey"),
            arrayOf("Groq", "условия на сайте", "https://console.groq.com/keys"),
            arrayOf("DeepSeek", "дёшево, нужен баланс", "https://platform.deepseek.com/api_keys"),
            arrayOf("OpenAI", "платно", "https://platform.openai.com/api-keys"),
            arrayOf("Claude", "платно", "https://platform.claude.com/settings/keys")
        )
        for (r in rows) {
            val row = LinearLayout(this)
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(0, dpi(12), 0, 0)
            val col = LinearLayout(this)
            col.orientation = LinearLayout.VERTICAL
            col.addView(tv(r[0], 14.5f, WHITE, 1))
            col.addView(tv(r[1], 12f, MUTED, 0))
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
            val url = r[2]
            row.addView(sbtn("Открыть", true) { openUrl(url) })
            c.addView(row)
        }
        content.addView(c, lpTop(14))
    }

    private fun addRelayEntry() {
        val c = card()
        c.addView(label("ЕСЛИ ИИ НЕ ОТКРЫВАЕТСЯ В ТВОЕЙ СТРАНЕ"))
        val on = Prefs.s(this, "ai_relay").isNotBlank()
        c.addView(tv(if (on) "●  Ретранслятор включён" else "●  Ретранслятор не настроен", 13f, if (on) OKC else MUTED, 3), lpTop(10))
        c.addView(tv("Некоторые сервисы ИИ закрыты для ряда стран. Можно сделать свой ретранслятор: пять коротких шагов с подсказками. Через него идут только запросы ИИ, не весь телефон.", 13f, MUTED, 0), lpTop(8))
        c.addView(pbtn("Настроить по шагам") { sub = 1; rebuild() }, lpTop(12))
        content.addView(c, lpTop(14))
    }

    // ---------- ретранслятор: пошаговая настройка ----------

    private fun wizStep(num: Int, title: String, desc: String, done: Boolean, actions: List<Pair<String, () -> Unit>>): View {
        val c = card()
        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        val badge = TextView(this)
        badge.text = if (done) "✓" else num.toString()
        badge.gravity = Gravity.CENTER
        badge.setTextColor(Color.WHITE)
        badge.typeface = fMonoB
        badge.textSize = 13f
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(if (done) OKC else ORANGE)
        badge.background = bg
        head.addView(badge, LinearLayout.LayoutParams(dpi(30), dpi(30)))
        val tt = tv(title, 17f, if (done) OKC else WHITE, 2)
        val tl = LinearLayout.LayoutParams(0, WRAP, 1f)
        tl.leftMargin = dpi(12)
        head.addView(tt, tl)
        c.addView(head)
        c.addView(tv(desc, 13.5f, MUTED, 0), lpTop(10))
        for ((text, fn) in actions) c.addView(sbtn(text, false) { fn() }, lpTop(12))
        return c
    }

    private fun buildRelay() {
        content.addView(sbtn("←  Назад к ИИ", true) { sub = 0; rebuild() }, LinearLayout.LayoutParams(WRAP, WRAP))
        val titleLp = lpTop(16)
        content.addView(tv("Ретранслятор", 32f, WHITE, 2), titleLp)
        content.addView(tv("ПЯТЬ КОРОТКИХ ШАГОВ · ОКОЛО 5 МИНУТ", 10f, MUTED, 3))
        val intro = card()
        intro.addView(tv("Что это", 15f, WHITE, 2))
        intro.addView(tv("Ретранслятор — твой личный посредник. Кики отправляет запрос ему, а он передаёт его сервису ИИ. Так сервис видит не твою страну, а место, где работает посредник.\n\nНе получится — не страшно: можно взять сервис, который открывается без ретранслятора (OpenRouter, DeepSeek).", 13.5f, MUTED, 0), lpTop(6))
        content.addView(intro, lpTop(16))

        val url = Prefs.s(this, "ai_relay")
        val copied = Prefs.b(this, "relay_copied")
        content.addView(wizStep(1, "Скопируй код",
            "Нажми кнопку: код ретранслятора окажется в буфере обмена. Больше с ним ничего делать не нужно.", copied,
            listOf(Pair<String, () -> Unit>("Скопировать код", { copyText(Relay.WORKER); Prefs.putB(this, "relay_copied", true); toast("Код скопирован"); rebuild() }))), lpTop(14))
        content.addView(wizStep(2, "Создай посредника",
            "Нажми «Открыть Cloudflare». Войди или зарегистрируйся: у Cloudflare есть бесплатный тариф, условия смотри на их сайте.\nПотом: слева Workers & Pages → кнопка Create → Create Worker → Deploy (синяя кнопка внизу).", false,
            listOf(Pair<String, () -> Unit>("Открыть Cloudflare", { openUrl("https://dash.cloudflare.com/") }))), lpTop(14))
        content.addView(wizStep(3, "Вставь код",
            "На странице нового воркера нажми Edit code. Нажми в окно с кодом, выдели всё и удали. Затем долгое нажатие и «Вставить». В конце нажми Deploy (справа вверху).\nЕсли ничего не вставляется, вернись к шагу 1 и скопируй код ещё раз.", false, emptyList()), lpTop(14))
        content.addView(wizStep(4, "Вставь адрес посредника",
            "Вверху страницы воркера виден адрес вида https://…workers.dev. Нажми на него и выбери «Копировать». Вернись сюда и нажми кнопку.", url.isNotBlank(),
            listOf(Pair<String, () -> Unit>("Вставить адрес из буфера", { pasteRelay() }))), lpTop(14))
        if (url.isNotBlank()) content.addView(tv(url, 11.5f, MUTED, 3), lpTop(8))

        val checkCard = wizStep(5, "Проверка",
            if (relayMsg.isNotEmpty()) relayMsg else "Нажми «Проверить связь»: Кики попробует достучаться до сервиса ИИ через твоего посредника.", relayOk,
            listOf(Pair<String, () -> Unit>("Проверить связь", { runRelayTest() })))
        content.addView(checkCard, lpTop(14))

        val foot = card()
        foot.addView(tv("Адрес вручную", 14f, WHITE, 1))
        val et = field("https://…workers.dev", url, false)
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { Prefs.putS(this@MainActivity, "ai_relay", (s?.toString() ?: "").trim()) }
        })
        foot.addView(et, lpTop(8))
        if (url.isNotBlank()) {
            foot.addView(sbtn("Отключить ретранслятор", true) { Prefs.putS(this, "ai_relay", ""); relayMsg = ""; relayOk = false; rebuild() }, lpTop(10))
        }
        foot.addView(tv("Ретранслятор видит твой ключ и вопросы, поэтому используй только свой. Заработает ли он в твоей стране и что разрешают правила сервиса ИИ, гарантировать нельзя.", 12f, MUTED, 0), lpTop(12))
        content.addView(foot, lpTop(14))
    }

    private fun pasteRelay() {
        val t = clipText()
        val m = if (t == null) null else Regex("https://[^\\s\"']+").find(t)
        if (m == null) { toast("В буфере нет адреса. Скопируй адрес воркера и нажми снова"); return }
        val u = m.value.trimEnd('/', '.', ',')
        if (u.contains("dash.cloudflare.com")) { toast("Это адрес панели Cloudflare, а нужен адрес воркера (…workers.dev)"); return }
        Prefs.putS(this, "ai_relay", u)
        relayMsg = "Проверяю…"
        relayOk = false
        rebuild()
        runRelayTest()
    }

    private fun runRelayTest() {
        val u = Prefs.s(this, "ai_relay")
        if (u.isBlank()) { toast("Сначала вставь адрес посредника (шаг 4)"); return }
        relayMsg = "Проверяю…"
        Thread {
            val r = Ai.testRelay(u)
            runOnUiThread {
                relayOk = r.first
                relayMsg = (if (r.first) "✓  " else "✕  ") + r.second
                if (tab == 3 && sub == 1) rebuild()
            }
        }.start()
    }

    // ---------- ещё ----------

    private fun buildMore() {
        pageTitle("Ещё", "ЭКРАН, ДНЕВНИК, ЭКОНОМИЯ, О КИКИ")
        addSections(4)
        addJournal()
        addAbout()
    }

    private fun addJournal() {
        val c = card()
        c.addView(label("ЗАПИСИ ДНЕВНИКА"))
        if (!Prefs.b(this, "journal_on")) {
            c.addView(tv("Дневник выключен. Включи его выше, в блоке «Дневник задач».", 13f, MUTED, 0), lpTop(10))
        }
        val bar = LinearLayout(this)
        val l1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        l1.rightMargin = dpi(8)
        bar.addView(sbtn("Записать сейчас", true) { peekHere() }, l1)
        bar.addView(sbtn("Очистить", true) { Journal.clear(this); rebuild() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        c.addView(bar, lpTop(12))
        val list = Journal.all(this).reversed()
        if (list.isEmpty()) {
            c.addView(tv("Пока пусто.", 13f, MUTED, 0), lpTop(12))
        } else {
            val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
            for (e in list.take(60)) {
                val line = View(this)
                line.setBackgroundColor(LINE)
                c.addView(line, LinearLayout.LayoutParams(MATCH, 1).also { it.topMargin = dpi(12) })
                c.addView(tv(fmt.format(Date(e.time)) + "  ·  " + e.app, 10.5f, ORANGE, 3), lpTop(10))
                c.addView(tv(e.text, 14f, WHITE, 0), lpTop(4))
            }
        }
        content.addView(c, lpTop(14))
    }

    private fun peekHere() {
        val s = CatService.instance
        if (s == null) {
            toast("Сначала запусти Кики")
        } else {
            s.peekNow()
            toast("Кики смотрит на экран…")
            h.postDelayed({ if (tab == 4) rebuild() }, 2500)
        }
    }

    private fun addAbout() {
        val c = card()
        c.addView(label("О КИКИ"))
        c.addView(tv("Кики — ИИ-помощник, который живёт на экране телефона: ходит по приложениям, реагирует на твои действия, отвечает на вопросы и разбирает задачи с экрана.", 13.5f, WHITE, 0), lpTop(10))
        c.addView(tv("Как пользоваться", 15f, WHITE, 2), lpTop(16))
        c.addView(tv("Тап по Кики показывает три кнопки: быстрый чат, разбор задачи с экрана и сюрприз. Долгое нажатие открывает быстрый чат. Кики можно таскать пальцем. Если опустить его к самому низу, он провалится и упадёт сверху.", 13f, MUTED, 0), lpTop(4))
        c.addView(tv("Позвать спрятанного Кики можно кнопкой в уведомлении.", 13f, MUTED, 0), lpTop(8))
        c.addView(tv("Версия 2.3 · Шрифты Tektur, Inter и Geist Mono (SIL OFL)", 11f, MUTED, 3), lpTop(16))
        content.addView(c, lpTop(14))
    }
}
