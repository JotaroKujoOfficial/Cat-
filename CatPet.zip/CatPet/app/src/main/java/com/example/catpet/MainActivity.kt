package com.example.catpet

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.SpannableString
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.sin

/** Панель помощника в стиле панели Pip из видео: почти чёрный фон, оранжевый акцент, подписи моноширинным шрифтом. */
class MainActivity : Activity() {
    private val BG = Color.parseColor("#060606")
    private val CARD = Color.parseColor("#0F0E11")
    private val LINE = Color.parseColor("#232227")
    private val FIELD = Color.parseColor("#09090B")
    private val ORANGE = Color.parseColor("#ED4A1D")
    private val OKC = Color.parseColor("#3DDC84")
    private val BAD = Color.parseColor("#FF5A5A")
    private val WHITE = Color.parseColor("#F2F2F4")
    private val MUTED = Color.parseColor("#8C8C94")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private lateinit var fReg: Typeface
    private lateinit var fSemi: Typeface
    private lateinit var fBold: Typeface
    private lateinit var fMono: Typeface
    private lateinit var fMonoB: Typeface

    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var setupBox: LinearLayout
    private lateinit var avatar: CatView
    private lateinit var stateText: TextView
    private lateinit var rowMood: TextView
    private lateinit var rowAi: TextView
    private lateinit var rowScreen: TextView
    private lateinit var rowOver: TextView
    private lateinit var runBtn: Button
    private val tabTv = ArrayList<TextView>()
    private val tabLn = ArrayList<View>()
    private var tab = 0
    private var n = 0
    private var t = 0f
    private var lastSig = ""
    private val h = Handler(Looper.getMainLooper())

    private val tickRun = object : Runnable {
        override fun run() {
            t += 0.1f
            n++
            avatar.lookX = sin(t * 0.8f) * 0.8f
            avatar.step(0.1f)
            if (n % 10 == 0) refreshStatus()
            h.postDelayed(this, 100)
        }
    }

    // ---------- помощники ----------

    private fun dpi(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    /** style: 0 текст, 1 полужирный, 2 жирный, 3 моно, 4 моно жирный */
    private fun tv(text: String, size: Float, color: Int, style: Int = 0): TextView {
        val x = TextView(this)
        x.text = text
        x.textSize = size
        x.setTextColor(color)
        x.typeface = when (style) { 1 -> fSemi; 2 -> fBold; 3 -> fMono; 4 -> fMonoB; else -> fReg }
        if (style >= 3) x.letterSpacing = 0.08f
        return x
    }

    private fun lpTop(top: Int): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(MATCH, WRAP)
        l.topMargin = dpi(top)
        return l
    }

    private fun shape(color: Int, stroke: Int, r: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dpi(r).toFloat()
        if (stroke != 0) g.setStroke(dpi(1), stroke)
        return g
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dpi(16), dpi(14), dpi(16), dpi(14))
        l.background = shape(CARD, LINE, 14)
        return l
    }

    private fun label(text: String, suffix: String): TextView {
        val sp = SpannableString(text + suffix)
        if (suffix.isNotEmpty()) sp.setSpan(ForegroundColorSpan(ORANGE), text.length, sp.length, 0)
        val x = tv("", 10.5f, MUTED, 3)
        x.text = sp
        return x
    }

    private fun pbtn(text: String, f: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = 14.5f
        b.typeface = fSemi
        b.setTextColor(Color.WHITE)
        b.background = shape(ORANGE, 0, 10)
        b.stateListAnimator = null
        b.minHeight = dpi(48)
        b.setOnClickListener { f() }
        return b
    }

    private fun sbtn(text: String, small: Boolean, f: () -> Unit): Button {
        val b = Button(this)
        b.text = text
        b.isAllCaps = false
        b.textSize = if (small) 13f else 14.5f
        b.typeface = fSemi
        b.setTextColor(WHITE)
        b.background = shape(FIELD, LINE, 10)
        b.stateListAnimator = null
        b.minHeight = dpi(if (small) 40 else 48)
        b.setOnClickListener { f() }
        return b
    }

    private fun field(hint: String, text: String, secret: Boolean): EditText {
        val et = EditText(this)
        et.hint = hint
        et.setHintTextColor(Color.parseColor("#5A5A62"))
        et.setTextColor(WHITE)
        et.typeface = fReg
        et.textSize = 14.5f
        et.setSingleLine(true)
        et.setText(text)
        et.setPadding(dpi(12), dpi(11), dpi(12), dpi(11))
        et.background = shape(FIELD, LINE, 10)
        et.inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD else InputType.TYPE_CLASS_TEXT
        return et
    }

    private fun tint(on: Int, off: Int): ColorStateList =
        ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(on, off))

    // ---------- окно ----------

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        fReg = Fonts.regular(this)
        fSemi = Fonts.semibold(this)
        fBold = Fonts.bold(this)
        fMono = Fonts.mono(this)
        fMonoB = Fonts.monoBold(this)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dpi(18), dpi(24), dpi(18), dpi(48))
        scroll.addView(root)
        setContentView(scroll)

        // шапка, как «Пип · панель брелка»
        val head = LinearLayout(this)
        head.gravity = Gravity.BOTTOM
        head.addView(tv("Кики", 30f, WHITE, 2))
        val sub = tv("ПАНЕЛЬ ПОМОЩНИКА", 10f, MUTED, 3)
        sub.setPadding(dpi(10), 0, 0, dpi(6))
        head.addView(sub)
        root.addView(head)

        // карточка состояния с круглым аватаром
        val st = card()
        st.orientation = LinearLayout.HORIZONTAL
        st.gravity = Gravity.CENTER_VERTICAL
        val frame = FrameLayout(this)
        frame.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#0A0A0C"))
            setStroke(dpi(2), Color.parseColor("#2C2C31"))
        }
        frame.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) { outline.setOval(0, 0, view.width, view.height) }
        }
        frame.clipToOutline = true
        avatar = CatView(this)
        val av = FrameLayout.LayoutParams(dpi(118), dpi(118))
        av.gravity = Gravity.CENTER
        frame.addView(avatar, av)
        st.addView(frame, LinearLayout.LayoutParams(dpi(92), dpi(92)))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        stateText = tv("", 14.5f, WHITE, 1)
        stateText.gravity = Gravity.END
        col.addView(stateText, LinearLayout.LayoutParams(MATCH, WRAP))
        rowMood = infoRow(col, "НАСТРОЕНИЕ")
        rowAi = infoRow(col, "ИИ")
        rowScreen = infoRow(col, "ЭКРАН")
        rowOver = infoRow(col, "ПОВЕРХ ЭКРАНА")
        val cl = LinearLayout.LayoutParams(0, WRAP, 1f)
        cl.leftMargin = dpi(16)
        st.addView(col, cl)
        root.addView(st, lpTop(18))

        runBtn = pbtn("Запустить Кики") { toggleRun() }
        root.addView(runBtn, lpTop(12))

        setupBox = card()
        root.addView(setupBox, lpTop(12))

        // вкладки с оранжевым подчёркиванием, как в панели Пипа
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val tabRow = LinearLayout(this)
        for (i in SettingsDef.tabNames.indices) {
            val box = LinearLayout(this)
            box.orientation = LinearLayout.VERTICAL
            val tt = tv(SettingsDef.tabNames[i], 14f, MUTED, 1)
            tt.setPadding(dpi(2), dpi(10), dpi(18), dpi(8))
            box.addView(tt)
            val ln = View(this)
            box.addView(ln, LinearLayout.LayoutParams(MATCH, dpi(2)))
            box.setOnClickListener { tab = i; showTab() }
            tabTv.add(tt)
            tabLn.add(ln)
            tabRow.addView(box)
        }
        hs.addView(tabRow)
        root.addView(hs, lpTop(20))
        val line = View(this)
        line.setBackgroundColor(LINE)
        root.addView(line, LinearLayout.LayoutParams(MATCH, 1))

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        root.addView(content, lpTop(4))
        showTab()
    }

    private fun infoRow(parent: LinearLayout, labelText: String): TextView {
        val r = LinearLayout(this)
        r.setPadding(0, dpi(7), 0, dpi(7))
        r.addView(tv(labelText, 10f, MUTED, 3), LinearLayout.LayoutParams(0, WRAP, 1f))
        val v = tv("—", 11.5f, WHITE, 3)
        r.addView(v)
        val sep = View(this)
        sep.setBackgroundColor(LINE)
        parent.addView(sep, LinearLayout.LayoutParams(MATCH, 1))
        parent.addView(r)
        return v
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
        h.removeCallbacks(tickRun)
        h.post(tickRun)
    }

    override fun onPause() {
        h.removeCallbacks(tickRun)
        super.onPause()
    }

    // ---------- разрешения ----------

    private fun a11yOn(): Boolean {
        if (SurfaceService.instance != null) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return s.contains(packageName + "/")
    }

    private fun notifOn(): Boolean =
        Build.VERSION.SDK_INT < 33 || checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED

    private fun openAppInfo() {
        try { startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + packageName))) }
        catch (_: Exception) {}
    }

    private fun openOverlay() {
        try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + packageName))) }
        catch (_: Exception) { openAppInfo() }
    }

    private fun openA11y() {
        try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        catch (_: Exception) { openAppInfo() }
    }

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Exception) {}
    }

    private fun stepView(num: Int, title: String, desc: String, done: Boolean, doneText: String,
                         actions: List<Pair<String, () -> Unit>>): View {
        val row = LinearLayout(this)
        row.setPadding(0, dpi(10), 0, dpi(10))
        val badge = TextView(this)
        badge.text = if (done) "✓" else num.toString()
        badge.gravity = Gravity.CENTER
        badge.setTextColor(Color.WHITE)
        badge.typeface = fMonoB
        badge.textSize = 12f
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(if (done) OKC else ORANGE)
        badge.background = bg
        row.addView(badge, LinearLayout.LayoutParams(dpi(26), dpi(26)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(tv("ШАГ " + num + " · " + title, 10.5f, if (done) OKC else WHITE, 3))
        col.addView(tv(if (done) doneText else desc, 13f, MUTED, 0), lpTop(4))
        if (!done) {
            for ((text, fn) in actions) col.addView(sbtn(text, true) { fn() }, lpTop(8))
        }
        val cl = LinearLayout.LayoutParams(0, WRAP, 1f)
        cl.leftMargin = dpi(12)
        row.addView(col, cl)
        return row
    }

    private fun buildSetup() {
        setupBox.removeAllViews()
        val overlay = Settings.canDrawOverlays(this)
        val a11y = a11yOn()
        val notif = notifOn()
        if (overlay && a11y && notif) {
            setupBox.addView(tv("✓  Все разрешения выданы", 13f, OKC, 3))
            return
        }
        setupBox.addView(label("НУЖНЫЕ РАЗРЕШЕНИЯ", ""))
        setupBox.addView(stepView(1, "ПОВЕРХ ЭКРАНА", "Чтобы Кики мог гулять поверх других приложений.", overlay, "выдано",
            listOf(Pair<String, () -> Unit>("Выдать разрешение", { openOverlay() }))))
        val a11yActions = ArrayList<Pair<String, () -> Unit>>()
        a11yActions.add(Pair<String, () -> Unit>("Открыть настройки служб", { openA11y() }))
        if (Build.VERSION.SDK_INT >= 33) a11yActions.add(Pair<String, () -> Unit>("Сведения о приложении", { openAppInfo() }))
        val a11yDesc = if (Build.VERSION.SDK_INT >= 33)
            "Включи «Кики» в списке служб. Если переключатель серый: открой «Сведения о приложении», нажми ⋮ вверху справа → «Разрешить ограниченные настройки», потом вернись и включи службу."
        else "Включи «Кики» в списке служб. Нужно, чтобы Кики ходил по кнопкам и разбирал задачи с экрана."
        setupBox.addView(stepView(2, "ЧТЕНИЕ ЭКРАНА", a11yDesc, a11y, "включено", a11yActions))
        if (Build.VERSION.SDK_INT >= 33) {
            setupBox.addView(stepView(3, "УВЕДОМЛЕНИЯ", "Чтобы можно было позвать Кики из шторки.", notif, "разрешено",
                listOf(Pair<String, () -> Unit>("Разрешить", { requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1) }))))
        }
        setupBox.addView(tv("Чтение экрана по желанию: без него Кики и чат работают, но Кики ходит только по низу.", 12f, MUTED, 0), lpTop(4))
    }

    private fun refreshStatus() {
        val svc = CatService.instance
        val running = svc != null
        stateText.text = if (running) "● Работает" else "● Не запущен"
        stateText.setTextColor(if (running) OKC else BAD)
        rowMood.text = svc?.statusText() ?: "—"
        rowAi.text = if (Ai.ready(this)) Prefs.s(this, "ai_name") else "встроенные"
        rowScreen.text = if (a11yOn()) "виден" else "не подключён"
        rowOver.text = if (Settings.canDrawOverlays(this)) "разрешено" else "нет"
        runBtn.text = if (running) "Остановить Кики" else "Запустить Кики"
        val sig = "" + Settings.canDrawOverlays(this) + a11yOn() + notifOn()
        if (sig != lastSig) { lastSig = sig; buildSetup() }
    }

    private fun toggleRun() {
        if (CatService.instance != null) {
            stopService(Intent(this, CatService::class.java))
            h.postDelayed({ refreshStatus() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Сначала выдай разрешение «Поверх экрана» (шаг 1)", Toast.LENGTH_LONG).show()
            openOverlay()
            return
        }
        startForegroundService(Intent(this, CatService::class.java))
        h.postDelayed({ refreshStatus() }, 600)
    }

    // ---------- вкладки ----------

    private fun showTab() {
        for (i in tabTv.indices) {
            tabTv[i].setTextColor(if (i == tab) WHITE else MUTED)
            tabLn[i].setBackgroundColor(if (i == tab) ORANGE else Color.TRANSPARENT)
        }
        content.removeAllViews()
        when (tab) {
            1 -> { addAiCard(); addFreeTips(); addSections(1) }
            2 -> { addSections(2); addJournal() }
            3 -> { addSections(3); addAbout() }
            else -> addSections(0)
        }
    }

    private fun addSections(tabIdx: Int) {
        for (s in SettingsDef.sections) {
            if (s.tab != tabIdx) continue
            val c = card()
            c.addView(label(s.title, ""))
            for (item in s.items) {
                val line = View(this)
                line.setBackgroundColor(LINE)
                c.addView(line, lpTop(10))
                c.addView(itemView(item))
            }
            content.addView(c, lpTop(14))
        }
    }

    private fun paintSeg(v: TextView, on: Boolean) {
        v.background = shape(if (on) ORANGE else FIELD, if (on) ORANGE else LINE, 9)
        v.setTextColor(if (on) Color.WHITE else MUTED)
    }

    private fun itemView(item: Item): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dpi(12), 0, dpi(2))
        when (item) {
            is Toggle -> {
                val rowL = LinearLayout(this)
                rowL.gravity = Gravity.CENTER_VERTICAL
                val col = LinearLayout(this)
                col.orientation = LinearLayout.VERTICAL
                col.addView(tv(item.title, 15f, WHITE, 1))
                if (item.desc.isNotEmpty()) col.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
                rowL.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))
                val sw = Switch(this)
                sw.isChecked = Prefs.b(this, item.key)
                sw.thumbTintList = tint(Color.WHITE, Color.parseColor("#9A9AA2"))
                sw.trackTintList = tint(ORANGE, Color.parseColor("#2A2A30"))
                sw.setOnCheckedChangeListener { _, v ->
                    Prefs.putB(this, item.key, v)
                    CatService.instance?.reloadPrefs()
                }
                rowL.addView(sw)
                box.addView(rowL)
            }
            is Choice -> {
                box.addView(tv(item.title, 15f, WHITE, 1))
                if (item.desc.isNotEmpty()) box.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
                val seg = LinearLayout(this)
                val views = ArrayList<TextView>()
                val cur = Prefs.i(this, item.key)
                for (i in item.options.indices) {
                    val o = tv(item.options[i], 12.5f, WHITE, 1)
                    o.gravity = Gravity.CENTER
                    o.setPadding(dpi(6), dpi(10), dpi(6), dpi(10))
                    views.add(o)
                    o.setOnClickListener {
                        Prefs.putI(this, item.key, i)
                        for (j in views.indices) paintSeg(views[j], j == i)
                        CatService.instance?.reloadPrefs()
                    }
                    val sl = LinearLayout.LayoutParams(0, WRAP, 1f)
                    if (i > 0) sl.leftMargin = dpi(6)
                    seg.addView(o, sl)
                }
                for (j in views.indices) paintSeg(views[j], j == cur)
                box.addView(seg, lpTop(8))
            }
            is Slider -> {
                val top = LinearLayout(this)
                top.addView(tv(item.title, 15f, WHITE, 1), LinearLayout.LayoutParams(0, WRAP, 1f))
                val valT = tv("", 13f, ORANGE, 4)
                top.addView(valT)
                box.addView(top)
                if (item.desc.isNotEmpty()) box.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
                val sb = SeekBar(this)
                sb.max = item.max - item.min
                val cur = Prefs.i(this, item.key).coerceIn(item.min, item.max)
                sb.progress = cur - item.min
                sb.progressTintList = ColorStateList.valueOf(ORANGE)
                sb.thumbTintList = ColorStateList.valueOf(ORANGE)
                valT.text = cur.toString() + item.unit
                sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        valT.text = (p + item.min).toString() + item.unit
                        if (fromUser) Prefs.putI(this@MainActivity, item.key, p + item.min)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) { CatService.instance?.reloadPrefs() }
                })
                box.addView(sb, lpTop(4))
            }
            is Field -> {
                box.addView(tv(item.title, 15f, WHITE, 1))
                if (item.desc.isNotEmpty()) box.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
                val et = field(item.hint, Prefs.s(this, item.key), item.secret)
                et.addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        Prefs.putS(this@MainActivity, item.key, (s?.toString() ?: "").trim())
                    }
                })
                box.addView(et, lpTop(8))
            }
            is Info -> {
                box.addView(tv(item.title, 15f, WHITE, 1))
                box.addView(tv(item.desc, 12.5f, MUTED, 0), lpTop(2))
            }
        }
        return box
    }

    // ---------- вкладка ИИ ----------

    private fun addAiCard() {
        val c = card()
        c.addView(label("ПОДКЛЮЧЕНИЕ ИИ", ""))
        val on = Ai.ready(this)
        val state = tv(
            if (on) "●  Подключено: " + Prefs.s(this, "ai_name") + " · " + Prefs.s(this, "ai_model")
            else "●  Не подключено. Пока работают встроенные ответы.",
            13f, if (on) OKC else MUTED, 3)
        c.addView(state, lpTop(10))
        c.addView(tv("Впиши название компании и ключ. Адрес и модель Кики определит сам.", 13f, MUTED, 0), lpTop(8))
        val comp = field("Компания: DeepSeek, OpenAI, Gemini, Groq, Claude…", Prefs.s(this, "ai_company"), false)
        c.addView(comp, lpTop(12))
        val key = field("Ключ (API key)", Prefs.s(this, "ai_key"), true)
        c.addView(key, lpTop(8))
        val status = tv("", 13f, MUTED, 0)
        val go = pbtn("Подключить") { }
        go.setOnClickListener {
            val cmp = comp.text.toString()
            val k = key.text.toString()
            status.text = "Проверяю ключ…"
            status.setTextColor(MUTED)
            go.isEnabled = false
            Thread {
                val r = try { Ai.connect(applicationContext, cmp, k) }
                catch (e: Exception) { AiResult(false, false, "Ошибка: " + (e.message ?: "неизвестно")) }
                runOnUiThread {
                    go.isEnabled = true
                    refreshStatus()
                    if (r.ok) {
                        showTab()
                    } else {
                        status.text = "✕  " + r.message
                        status.setTextColor(BAD)
                    }
                }
            }.start()
        }
        c.addView(go, lpTop(12))
        c.addView(status, lpTop(10))
        if (on) {
            c.addView(sbtn("Отключить ИИ", true) { Ai.disconnect(this); showTab(); refreshStatus() }, lpTop(10))
        }
        content.addView(c, lpTop(14))
    }

    private fun addFreeTips() {
        val c = card()
        c.addView(label("НЕТ КЛЮЧА?", ""))
        c.addView(tv("Ключ (API key) — длинная строка, которую выдаёт сайт сервиса в разделе API keys. Подписка ChatGPT или Claude — не ключ.", 13f, MUTED, 0), lpTop(10))
        c.addView(tv("Бесплатные ключи с лимитами выдают Google AI Studio (Gemini), Groq и OpenRouter. Условия и страны у сервисов меняются.", 13f, MUTED, 0), lpTop(8))
        c.addView(tv("Если пишет про лимит или баланс: ключ рабочий, но на аккаунте нет денег или закончился лимит.", 13f, MUTED, 0), lpTop(8))
        val row = LinearLayout(this)
        val names = arrayOf("Gemini", "Groq", "OpenRouter")
        val urls = arrayOf("https://aistudio.google.com/apikey", "https://console.groq.com/keys", "https://openrouter.ai/keys")
        for (i in 0..2) {
            val u = urls[i]
            val b = sbtn(names[i], true) { openUrl(u) }
            val l = LinearLayout.LayoutParams(0, WRAP, 1f)
            if (i > 0) l.leftMargin = dpi(6)
            row.addView(b, l)
        }
        c.addView(row, lpTop(12))
        content.addView(c, lpTop(14))
    }

    // ---------- дневник и о приложении ----------

    private fun addJournal() {
        val c = card()
        c.addView(label("ЗАПИСИ ДНЕВНИКА", ""))
        if (!Prefs.b(this, "journal_on")) {
            c.addView(tv("Дневник выключен. Включи его выше, в блоке «Дневник задач».", 13f, MUTED, 0), lpTop(10))
        }
        val bar = LinearLayout(this)
        val l1 = LinearLayout.LayoutParams(0, WRAP, 1f)
        l1.rightMargin = dpi(6)
        bar.addView(sbtn("Записать сейчас", true) { peekHere() }, l1)
        bar.addView(sbtn("Очистить", true) { Journal.clear(this); showTab() }, LinearLayout.LayoutParams(0, WRAP, 1f))
        c.addView(bar, lpTop(12))
        val list = Journal.all(this).reversed()
        if (list.isEmpty()) {
            c.addView(tv("Пока пусто.", 13f, MUTED, 0), lpTop(12))
        } else {
            val fmt = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
            for (e in list.take(60)) {
                val line = View(this)
                line.setBackgroundColor(LINE)
                c.addView(line, lpTop(12))
                c.addView(tv(fmt.format(Date(e.time)) + "  ·  " + e.app, 10.5f, ORANGE, 3), lpTop(10))
                c.addView(tv(e.text, 14f, WHITE, 0), lpTop(4))
            }
        }
        content.addView(c, lpTop(14))
    }

    private fun peekHere() {
        val s = CatService.instance
        if (s == null) {
            Toast.makeText(this, "Сначала запусти Кики", Toast.LENGTH_SHORT).show()
        } else {
            s.peekNow()
            Toast.makeText(this, "Кики смотрит на экран…", Toast.LENGTH_SHORT).show()
            h.postDelayed({ showTab() }, 2500)
        }
    }

    private fun addAbout() {
        val c = card()
        c.addView(label("О КИКИ", ""))
        c.addView(tv("Кики — ИИ-помощник, который живёт на экране телефона: ходит по приложениям, реагирует на твои действия, отвечает на вопросы и разбирает задачи с экрана.", 13.5f, WHITE, 0), lpTop(10))
        c.addView(tv("Как пользоваться", 14f, WHITE, 1), lpTop(16))
        c.addView(tv("Тап по Кики показывает три кнопки: быстрый чат, разбор задачи с экрана и сюрприз. Долгое нажатие открывает быстрый чат. Кики можно таскать пальцем. Если опустить его к самому низу, он провалится и упадёт сверху.", 13f, MUTED, 0), lpTop(4))
        c.addView(tv("Позвать спрятанного Кики можно кнопкой в уведомлении.", 13f, MUTED, 0), lpTop(8))
        c.addView(tv("Версия 2.1 · Шрифты Inter и JetBrains Mono (SIL OFL)", 11f, MUTED, 3), lpTop(16))
        content.addView(c, lpTop(14))
    }
}
