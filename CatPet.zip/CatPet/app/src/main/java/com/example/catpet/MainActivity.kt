package com.example.catpet

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        val d = resources.displayMetrics.density
        val p = (20 * d).toInt()
        val prefs = getSharedPreferences("cat", MODE_PRIVATE)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(p, p, p, p); setBackgroundColor(Color.parseColor("#0B0B0B"))
        }
        fun add(v: View) = root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = (12 * d).toInt() })

        add(TextView(this).apply { text = "КОТИК"; textSize = 28f; setTextColor(Color.WHITE); typeface = Typeface.MONOSPACE })
        val key = EditText(this).apply {
            hint = "Ключ Anthropic API"; setText(prefs.getString("key", ""))
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        add(key)
        fun btn(t: String, f: () -> Unit) = add(Button(this).apply {
            text = t; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#FF4A1C")); setOnClickListener { f() }
        })
        btn("1. Сохранить ключ") {
            prefs.edit().putString("key", key.text.toString().trim()).apply()
            Toast.makeText(this, "Сохранено", Toast.LENGTH_SHORT).show()
        }
        btn("2. Разрешить поверх экрана") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("3. Включить «Котик» в спец. возможностях") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("4. Запустить котика") {
            if (!Settings.canDrawOverlays(this)) Toast.makeText(this, "Сначала шаг 2", Toast.LENGTH_SHORT).show()
            else startForegroundService(Intent(this, CatService::class.java))
        }
        btn("Остановить котика") { stopService(Intent(this, CatService::class.java)) }
        setContentView(root)
    }
}
