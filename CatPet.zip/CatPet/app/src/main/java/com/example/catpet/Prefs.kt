package com.example.catpet

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("cat", Context.MODE_PRIVATE)

    fun b(c: Context, k: String): Boolean = sp(c).getBoolean(k, (SettingsDef.defaults[k] as? Boolean) ?: false)
    fun i(c: Context, k: String): Int = sp(c).getInt(k, (SettingsDef.defaults[k] as? Int) ?: 0)
    fun s(c: Context, k: String): String {
        val d = (SettingsDef.defaults[k] as? String) ?: ""
        val v = sp(c).getString(k, null)
        if (v == null && k == "ai_key") return sp(c).getString("key", d) ?: d
        return v ?: d
    }

    fun putB(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun putI(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
    fun putS(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
}
