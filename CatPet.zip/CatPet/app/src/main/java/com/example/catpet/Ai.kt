package com.example.catpet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

class Prov(val name: String, val aliases: List<String>, val base: String, val style: Int)
class ApiErr(val code: Int, val body: String) : Exception("HTTP " + code)
class AiResult(val ok: Boolean, val keyOk: Boolean, val message: String)

/**
 * Подключение к ИИ по двум полям: название компании и ключ.
 * Кики сам находит адрес, спрашивает у сервиса список моделей, выбирает подходящую
 * и проверяет, что ответ приходит. Поддерживаются Anthropic и все OpenAI-совместимые сервисы.
 */
object Ai {
    val providers = listOf(
        Prov("Anthropic (Claude)", listOf("anthropic", "claude", "клод", "антропик"), "https://api.anthropic.com", 1),
        Prov("OpenAI (ChatGPT)", listOf("openai", "chatgpt", "gpt", "чатгпт", "опенаи", "опенэй"), "https://api.openai.com/v1", 0),
        Prov("DeepSeek", listOf("deepseek", "дипсик", "дипсек"), "https://api.deepseek.com", 0),
        Prov("Google Gemini", listOf("gemini", "google", "гугл", "гемини", "джемини", "aistudio"), "https://generativelanguage.googleapis.com/v1beta/openai", 0),
        Prov("Groq", listOf("groq"), "https://api.groq.com/openai/v1", 0),
        Prov("OpenRouter", listOf("openrouter", "опенроутер"), "https://openrouter.ai/api/v1", 0),
        Prov("xAI (Grok)", listOf("xai", "grok", "грок"), "https://api.x.ai/v1", 0),
        Prov("Mistral", listOf("mistral", "мистраль", "мистрал"), "https://api.mistral.ai/v1", 0),
        Prov("Together", listOf("together"), "https://api.together.xyz/v1", 0),
        Prov("Perplexity", listOf("perplexity", "перплексити"), "https://api.perplexity.ai", 0),
        Prov("Moonshot (Kimi)", listOf("kimi", "moonshot", "кими"), "https://api.moonshot.ai/v1", 0),
        Prov("Qwen (Alibaba)", listOf("qwen", "alibaba", "dashscope", "квен", "алибаба"), "https://dashscope-intl.aliyuncs.com/compatible-mode/v1", 0)
    )

    fun ready(c: Context): Boolean = Prefs.b(c, "ai_ok") && Prefs.s(c, "ai_key").isNotBlank()

    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun byName(start: String): Prov? = providers.firstOrNull { it.name.startsWith(start) }

    /** По названию компании (и по виду ключа) определяет, куда подключаться. */
    fun resolve(company: String, key: String): List<Prov> {
        val raw = company.trim()
        val out = ArrayList<Prov>()
        if (raw.startsWith("http://") || raw.startsWith("https://")) {
            out.add(Prov(raw, emptyList(), raw.trimEnd('/'), 0))
            return out
        }
        val n = norm(raw)
        if (n.isNotEmpty()) {
            for (p in providers) {
                val hit = p.aliases.any { a ->
                    val na = norm(a)
                    n.contains(na) || (n.length >= 3 && na.contains(n))
                }
                if (hit) out.add(p)
            }
            if (out.isNotEmpty()) return out
            if (raw.contains('.') && !raw.contains(' ')) {
                var base = "https://" + raw.trimEnd('/')
                if (!raw.contains('/')) base = base + "/v1"
                out.add(Prov(raw, emptyList(), base, 0))
                return out
            }
        }
        val k = key.trim()
        val guess = ArrayList<Prov?>()
        when {
            k.startsWith("sk-ant-") -> guess.add(byName("Anthropic"))
            k.startsWith("AIza") -> guess.add(byName("Google"))
            k.startsWith("gsk_") -> guess.add(byName("Groq"))
            k.startsWith("sk-or-") -> guess.add(byName("OpenRouter"))
            k.startsWith("xai-") -> guess.add(byName("xAI"))
            k.startsWith("pplx-") -> guess.add(byName("Perplexity"))
            k.startsWith("sk-proj-") -> guess.add(byName("OpenAI"))
            k.startsWith("sk-") -> { guess.add(byName("OpenAI")); guess.add(byName("DeepSeek")); guess.add(byName("Moonshot")) }
            else -> {}
        }
        for (g in guess) if (g != null) out.add(g)
        return out
    }

    private fun http(method: String, url: String, headers: Map<String, String>, body: String?): Pair<Int, String> {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        if (body != null) {
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.readText() ?: ""
        conn.disconnect()
        return Pair(code, text)
    }

    private fun headers(p: Prov, key: String): Map<String, String> {
        val m = HashMap<String, String>()
        m["content-type"] = "application/json"
        if (p.style == 1) {
            m["x-api-key"] = key
            m["anthropic-version"] = "2023-06-01"
        } else {
            m["Authorization"] = "Bearer " + key
        }
        return m
    }

    private fun listModels(p: Prov, key: String): List<String> {
        val url = if (p.style == 1) p.base + "/v1/models" else p.base + "/models"
        val (code, text) = http("GET", url, headers(p, key), null)
        if (code !in 200..299) throw ApiErr(code, text)
        val j = JSONObject(text)
        val arr = j.optJSONArray("data") ?: j.optJSONArray("models") ?: JSONArray()
        val ids = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i)
            val id = if (o != null) o.optString("id", "") else arr.optString(i, "")
            if (id.isNotEmpty()) ids.add(id.removePrefix("models/"))
        }
        return ids
    }

    private val bad = listOf("embed", "whisper", "tts", "audio", "image", "video", "moderation", "rerank",
        "guard", "realtime", "transcribe", "dall", "vision", "ocr", "speech", "safeguard")

    private fun pickModels(p: Prov, ids: List<String>): List<String> {
        val g = ids.filter { id -> bad.none { id.lowercase().contains(it) } }
        val pool = if (g.isEmpty()) ids else g
        val n = p.name
        val ordered: List<String> = when {
            n.startsWith("Anthropic") -> pool.filter { it.contains("sonnet") } + pool.filter { it.contains("haiku") } + pool
            n.startsWith("OpenAI") -> {
                val gpt = pool.filter { it.startsWith("gpt-") && !it.contains("instruct") && !it.contains("search") && !it.contains("codex") }
                gpt.filter { it.contains("mini") }.sortedDescending() + gpt.sortedDescending() + pool
            }
            n.startsWith("DeepSeek") -> pool.filter { it.contains("flash") } + pool.filter { it.contains("chat") } + pool
            n.startsWith("Google") -> {
                val fl = pool.filter { it.contains("flash") }
                fl.filter { !it.contains("lite") && !it.contains("live") && !it.contains("preview") }.sortedDescending() + fl.sortedDescending() + pool
            }
            n.startsWith("Groq") -> pool.filter { it.contains("llama-3.3-70b") } + pool.filter { it.contains("llama") && (it.contains("instant") || it.contains("versatile")) } + pool
            n.startsWith("OpenRouter") -> {
                val free = pool.filter { it.endsWith(":free") }
                free.filter { it.contains("llama") || it.contains("gemini") || it.contains("deepseek") || it.contains("qwen") } + free + pool
            }
            n.startsWith("Mistral") -> pool.filter { it.contains("small-latest") } + pool.filter { it.contains("medium-latest") } + pool
            n.startsWith("xAI") -> pool.filter { it.contains("mini") } + pool
            else -> pool
        }
        return ordered.distinct().take(4)
    }

    private fun fallbackModels(p: Prov): List<String> = when {
        p.name.startsWith("Perplexity") -> listOf("sonar")
        p.name.startsWith("Anthropic") -> listOf("claude-sonnet-5-5", "claude-haiku-5-5")
        p.name.startsWith("OpenAI") -> listOf("gpt-4o-mini")
        p.name.startsWith("DeepSeek") -> listOf("deepseek-flash", "deepseek-chat")
        p.name.startsWith("Google") -> listOf("gemini-2.5-flash")
        p.name.startsWith("Groq") -> listOf("llama-3.3-70b-versatile")
        p.name.startsWith("Mistral") -> listOf("mistral-small-latest")
        else -> emptyList()
    }

    private fun parseChat(text: String): String {
        val msg = JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        return msg.optString("content", "")
    }

    /** Один запрос. Для OpenAI-совместимых сервисов сам подбирает параметр лимита ответа. */
    private fun chatOnce(p: Prov, key: String, model: String, system: String, messages: JSONArray, maxTok: Int): String {
        if (p.style == 1) {
            val body = JSONObject()
            body.put("model", model).put("max_tokens", maxTok).put("system", system).put("messages", messages)
            val (code, text) = http("POST", p.base + "/v1/messages", headers(p, key), body.toString())
            if (code !in 200..299) throw ApiErr(code, text)
            return JSONObject(text).getJSONArray("content").getJSONObject(0).optString("text", "")
        }
        val all = JSONArray()
        all.put(JSONObject().put("role", "system").put("content", system))
        for (i in 0 until messages.length()) all.put(messages.getJSONObject(i))
        val base = JSONObject()
        base.put("model", model).put("messages", all)
        var mode = 0
        for (attempt in 0..2) {
            val b = JSONObject(base.toString())
            if (mode == 0) b.put("max_tokens", maxTok)
            if (mode == 1) b.put("max_completion_tokens", maxTok)
            val (code, text) = http("POST", p.base + "/chat/completions", headers(p, key), b.toString())
            if (code in 200..299) return parseChat(text)
            val low = text.lowercase()
            val tokParam = low.contains("max_tokens") || low.contains("max_completion_tokens")
            if (code == 400 && mode < 2 && tokParam) {
                mode = if (mode == 0 && low.contains("max_completion_tokens")) 1 else 2
                continue
            }
            throw ApiErr(code, text)
        }
        throw ApiErr(400, "")
    }

    fun isMoney(e: ApiErr): Boolean {
        val low = e.body.lowercase()
        return e.code == 402 || low.contains("insufficient") || low.contains("quota") || low.contains("balance") ||
            low.contains("billing") || low.contains("credit") || low.contains("exceeded your current")
    }

    fun human(e: ApiErr, name: String): String {
        return when {
            isMoney(e) -> "На аккаунте " + name + " нет денег или закончился лимит. Ключ рабочий, но сервис не даёт отвечать. Пополни баланс или возьми бесплатный ключ (Google Gemini, Groq или OpenRouter)."
            e.code == 401 || e.code == 403 -> "Ключ не подошёл к " + name + ". Проверь, что он скопирован полностью, без пробелов, и выдан именно этим сервисом. Если ключ точно верный, сервис может быть недоступен в твоей стране: тогда нужен VPN."
            e.code == 404 -> "Сервис " + name + " не нашёл модель или адрес. Нажми «Подключить» ещё раз."
            e.code == 429 -> "Слишком много запросов к " + name + ". Подожди минуту."
            e.code >= 500 -> name + " сейчас недоступен. Попробуй позже."
            else -> "Сервис " + name + " ответил ошибкой " + e.code + "."
        }
    }

    private fun netMsg(e: IOException): String =
        "Нет связи с сервисом. Проверь интернет. Некоторые сервисы в ряде стран работают только через VPN."

    private fun system(c: Context): String {
        val tone = when (Prefs.i(c, "ai_tone")) {
            1 -> "Говори спокойно и мягко."
            2 -> "Говори по делу, без лишних слов."
            3 -> "Добавляй немного дружелюбного сарказма."
            else -> "Будь игривым, иногда мяукай."
        }
        return "Ты Кики, чёрный котик-ИИ-помощник, который живёт на экране телефона. Отвечай по-русски, коротко и по существу. " + tone
    }

    private fun saved(c: Context): Prov = Prov(Prefs.s(c, "ai_name"), emptyList(), Prefs.s(c, "ai_url"), Prefs.i(c, "ai_style"))

    /** Ответ ИИ. Блокирующий вызов, запускать не из главного потока. Ошибки приходят понятным текстом. */
    fun ask(c: Context, messages: JSONArray, maxTokens: Int = 0): String {
        if (!ready(c)) throw IllegalStateException("ИИ не подключён. Открой вкладку «ИИ» в приложении.")
        val p = saved(c)
        val tok = if (maxTokens > 0) maxTokens else Prefs.i(c, "ai_len")
        try {
            val r = chatOnce(p, Prefs.s(c, "ai_key").trim(), Prefs.s(c, "ai_model"), system(c), messages, tok)
            if (r.isBlank()) throw IllegalStateException("Модель ответила пустотой. Попробуй ещё раз.")
            return r
        } catch (e: ApiErr) {
            throw IllegalStateException(human(e, p.name))
        } catch (e: IOException) {
            throw IllegalStateException(netMsg(e))
        }
    }

    fun summarize(c: Context, screenText: String): String {
        val m = JSONArray().put(JSONObject().put("role", "user").put("content",
            "Вот текст с экрана телефона. Опиши ОДНОЙ короткой строкой, чем занят пользователь или какая у него задача:\n" + screenText))
        return ask(c, m, 80).replace('\n', ' ')
    }

    private fun save(c: Context, company: String, key: String, p: Prov, model: String) {
        Prefs.putS(c, "ai_company", company)
        Prefs.putS(c, "ai_key", key)
        Prefs.putS(c, "ai_url", p.base)
        Prefs.putS(c, "ai_model", model)
        Prefs.putS(c, "ai_name", p.name)
        Prefs.putI(c, "ai_style", p.style)
        Prefs.putB(c, "ai_ok", true)
    }

    fun disconnect(c: Context) {
        Prefs.putB(c, "ai_ok", false)
        Prefs.putS(c, "ai_key", "")
    }

    /** Подключение: проверяет ключ, выбирает модель, делает пробный запрос. Запускать не из главного потока. */
    fun connect(c: Context, company: String, keyRaw: String): AiResult {
        val key = keyRaw.trim()
        if (key.isEmpty()) return AiResult(false, false, "Вставь ключ.")
        val cands = resolve(company, key)
        if (cands.isEmpty()) {
            return AiResult(false, false, "Не знаю такую компанию. Впиши, например: DeepSeek, OpenAI, Gemini, Groq, OpenRouter, Claude, Mistral. Или вставь адрес API.")
        }
        var lastMsg = ""
        var keyWorked = false
        val ping = JSONArray().put(JSONObject().put("role", "user").put("content", "Привет"))
        for (p in cands) {
            try {
                var ids: List<String> = emptyList()
                try {
                    ids = listModels(p, key)
                } catch (e: ApiErr) {
                    if (e.code == 401 || e.code == 403) throw e
                }
                val models = if (ids.isEmpty()) fallbackModels(p) else pickModels(p, ids)
                if (models.isEmpty()) { lastMsg = "Не удалось определить модель у " + p.name + "."; continue }
                var lastErr: ApiErr? = null
                for (m in models) {
                    try {
                        chatOnce(p, key, m, "Ответь одним словом.", ping, 32)
                        save(c, company, key, p, m)
                        return AiResult(true, true, "Подключено: " + p.name + " · " + m)
                    } catch (e: ApiErr) {
                        lastErr = e
                        if (e.code == 401 || e.code == 403 || isMoney(e)) throw e
                    }
                }
                if (lastErr != null) throw lastErr
            } catch (e: ApiErr) {
                lastMsg = human(e, p.name)
                if (e.code != 401 && e.code != 403) keyWorked = true
                if (isMoney(e)) break
            } catch (e: IOException) {
                lastMsg = netMsg(e)
            } catch (e: Exception) {
                lastMsg = "Не получилось: " + (e.message ?: "неизвестная ошибка")
            }
        }
        return AiResult(false, keyWorked, if (lastMsg.isEmpty()) "Не получилось подключиться." else lastMsg)
    }
}
