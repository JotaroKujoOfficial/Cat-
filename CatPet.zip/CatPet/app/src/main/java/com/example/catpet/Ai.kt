package com.example.catpet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.Authenticator
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.PasswordAuthentication
import java.net.Proxy
import java.net.URL

class Prov(val name: String, val aliases: List<String>, val base: String, val style: Int)
class ApiErr(val code: Int, val body: String) : Exception("HTTP " + code)
class AiResult(val ok: Boolean, val keyOk: Boolean, val message: String, val details: String = "", val kind: String = "")

/**
 * Подключение к ИИ по двум полям: название компании и ключ.
 * Кики сам находит адрес, спрашивает у сервиса список моделей, выбирает подходящую и проверяет ответ.
 * Если сервис недоступен в стране, запросы можно пустить через свой ретранслятор или прокси (только трафик ИИ).
 */
object Ai {
    val providers = listOf(
        Prov("Anthropic (Claude)", listOf("anthropic", "claude", "клод", "антропик"), "https://api.anthropic.com", 1),
        Prov("OpenAI (ChatGPT)", listOf("openai", "chatgpt", "gpt", "чатгпт", "опенаи", "опенэй"), "https://api.openai.com/v1", 0),
        Prov("DeepSeek", listOf("deepseek", "дипсик", "дипсек"), "https://api.deepseek.com", 0),
        Prov("Google Gemini", listOf("gemini", "google", "гугл", "гемини", "джемини", "aistudio"), "https://generativelanguage.googleapis.com/v1beta/openai", 0),
        Prov("Groq", listOf("groq"), "https://api.groq.com/openai/v1", 0),
        Prov("OpenRouter", listOf("openrouter", "опенроутер"), "https://openrouter.ai/api/v1", 0),
        Prov("xAI (Grok)", listOf("xai", "grok", "грок"), "https://api.x.ai/v1", 0),
        Prov("Mistral", listOf("mistral", "мистраль", "мистрал"), "https://api.mistral.ai/v1", 0),
        Prov("Together", listOf("together"), "https://api.together.xyz/v1", 0),
        Prov("Perplexity", listOf("perplexity", "перплексити"), "https://api.perplexity.ai", 0),
        Prov("Moonshot (Kimi)", listOf("kimi", "moonshot", "кими"), "https://api.moonshot.ai/v1", 0),
        Prov("Qwen (Alibaba)", listOf("qwen", "alibaba", "dashscope", "квен", "алибаба"), "https://dashscope-intl.aliyuncs.com/compatible-mode/v1", 0)
    )

    private var relay = ""
    private var proxy: Proxy? = null

    fun ready(c: Context): Boolean = Prefs.b(c, "ai_ok") && Prefs.s(c, "ai_key").isNotBlank()

    /** Читает настройки ретранслятора и прокси. Они действуют только на запросы ИИ из этого приложения. */
    private fun loadNet(c: Context) {
        relay = Prefs.s(c, "ai_relay").trim()
        if (!relay.startsWith("https://")) relay = ""
        proxy = null
        val hp = Prefs.s(c, "ai_proxy").trim().removePrefix("socks5://").removePrefix("http://")
        val parts = hp.split(":")
        val port = parts.getOrNull(1)?.trim()?.toIntOrNull()
        if (parts[0].isNotBlank() && port != null) {
            val type = if (Prefs.i(c, "ai_proxy_type") == 1) Proxy.Type.SOCKS else Proxy.Type.HTTP
            proxy = Proxy(type, InetSocketAddress.createUnresolved(parts[0].trim(), port))
        }
        val auth = Prefs.s(c, "ai_proxy_auth").trim()
        if (proxy != null && auth.contains(':')) {
            val user = auth.substringBefore(':')
            val pass = auth.substringAfter(':')
            Authenticator.setDefault(object : Authenticator() {
                override fun getPasswordAuthentication(): PasswordAuthentication? {
                    return if (requestorType == Authenticator.RequestorType.PROXY) PasswordAuthentication(user, pass.toCharArray()) else null
                }
            })
        } else {
            Authenticator.setDefault(null)
        }
    }

    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }

    private fun byName(start: String): Prov? = providers.firstOrNull { it.name.startsWith(start) }

    /** По виду ключа угадывает сервис. Второе значение: уверенно ли (по понятному началу ключа). */
    private fun guessByKey(key: String): Pair<List<Prov>, Boolean> {
        val k = key.trim()
        fun one(n: String): Pair<List<Prov>, Boolean> {
            val p = byName(n)
            return Pair(if (p == null) emptyList() else listOf(p), true)
        }
        return when {
            k.startsWith("sk-ant-") -> one("Anthropic")
            k.startsWith("AIza") -> one("Google")
            k.startsWith("gsk_") -> one("Groq")
            k.startsWith("sk-or-") -> one("OpenRouter")
            k.startsWith("xai-") -> one("xAI")
            k.startsWith("pplx-") -> one("Perplexity")
            k.startsWith("sk-proj-") -> one("OpenAI")
            Regex("^sk-[0-9a-f]{32}$").matches(k) -> Pair(listOfNotNull(byName("DeepSeek"), byName("OpenAI")), true)
            k.startsWith("sk-") -> Pair(listOfNotNull(byName("OpenAI"), byName("DeepSeek"), byName("Moonshot")), false)
            else -> Pair(emptyList(), false)
        }
    }

    /** Название сервиса по ключу в буфере обмена или null, если не похоже на ключ. */
    fun looksLikeKey(text: String): String? {
        val k = text.trim()
        if (k.length < 20 || k.contains(' ') || k.contains('\n')) return null
        val (list, strong) = guessByKey(k)
        if (list.isNotEmpty() && strong) return list[0].name
        if (k.startsWith("sk-") && list.isNotEmpty()) return "ключ API"
        return null
    }

    /** По названию компании и по виду ключа определяет, куда подключаться. Начало ключа важнее названия. */
    fun resolve(company: String, key: String): List<Prov> {
        val raw = company.trim()
        if (raw.startsWith("http://") || raw.startsWith("https://")) {
            return listOf(Prov(raw, emptyList(), raw.trimEnd('/'), 0))
        }
        val byCompany = ArrayList<Prov>()
        val n = norm(raw)
        if (n.isNotEmpty()) {
            for (p in providers) {
                val hit = p.aliases.any { a ->
                    val na = norm(a)
                    n.contains(na) || (n.length >= 3 && na.contains(n))
                }
                if (hit) byCompany.add(p)
            }
            if (byCompany.isEmpty() && raw.contains('.') && !raw.contains(' ')) {
                var base = "https://" + raw.trimEnd('/')
                if (!raw.contains('/')) base = base + "/v1"
                byCompany.add(Prov(raw, emptyList(), base, 0))
            }
        }
        val (kg, strong) = guessByKey(key)
        val out = ArrayList<Prov>()
        if (strong) out.addAll(kg)
        out.addAll(byCompany)
        if (!strong) out.addAll(kg)
        return out.distinctBy { it.name }
    }

    private fun http(method: String, url: String, headers: Map<String, String>, body: String?): Pair<Int, String> {
        val target = if (relay.isNotEmpty()) relay.trimEnd('/') + "/" + url else url
        val u = URL(target)
        val px = proxy
        val conn = (if (px != null) u.openConnection(px) else u.openConnection()) as HttpURLConnection
        conn.requestMethod = method
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        if (body != null) {
            conn.doOutput = true
            conn.outputStream.use { it.write(body.toByteArray()) }
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.readText() ?: ""
        conn.disconnect()
        return Pair(code, text)
    }

    private fun headers(p: Prov, key: String): Map<String, String> {
        val m = HashMap<String, String>()
        m["content-type"] = "application/json"
        m["Accept"] = "application/json"
        m["User-Agent"] = "Kiki/2.3 (Android)"
        if (p.style == 1) {
            m["x-api-key"] = key
            m["anthropic-version"] = "2023-06-01"
        } else {
            m["Authorization"] = "Bearer " + key
        }
        return m
    }

    private fun listModels(p: Prov, key: String): List<String> {
        val url = if (p.style == 1) p.base + "/v1/models" else p.base + "/models"
        val (code, text) = http("GET", url, headers(p, key), null)
        if (code !in 200..299) throw ApiErr(code, text)
        val j = JSONObject(text)
        val arr = j.optJSONArray("data") ?: j.optJSONArray("models") ?: JSONArray()
        val ids = ArrayList<String>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i)
            val id = if (o != null) o.optString("id", "") else arr.optString(i, "")
            if (id.isNotEmpty()) ids.add(id.removePrefix("models/"))
        }
        return ids
    }

    private val bad = listOf("embed", "whisper", "tts", "audio", "image", "video", "moderation", "rerank",
        "guard", "realtime", "transcribe", "dall", "vision", "ocr", "speech", "safeguard")

    private fun pickModels(p: Prov, ids: List<String>): List<String> {
        val g = ids.filter { id -> bad.none { id.lowercase().contains(it) } }
        val pool = if (g.isEmpty()) ids else g
        val n = p.name
        val ordered: List<String> = when {
            n.startsWith("Anthropic") -> pool.filter { it.contains("sonnet") } + pool.filter { it.contains("haiku") } + pool
            n.startsWith("OpenAI") -> {
                val gpt = pool.filter { it.startsWith("gpt-") && !it.contains("instruct") && !it.contains("search") && !it.contains("codex") }
                gpt.filter { it.contains("mini") }.sortedDescending() + gpt.sortedDescending() + pool
            }
            n.startsWith("DeepSeek") -> pool.filter { it.contains("flash") } + pool.filter { it.contains("chat") } + pool
            n.startsWith("Google") -> {
                val fl = pool.filter { it.contains("flash") }
                fl.filter { !it.contains("lite") && !it.contains("live") && !it.contains("preview") }.sortedDescending() + fl.sortedDescending() + pool
            }
            n.startsWith("Groq") -> pool.filter { it.contains("llama-3.3-70b") } + pool.filter { it.contains("llama") && (it.contains("instant") || it.contains("versatile")) } + pool
            n.startsWith("OpenRouter") -> {
                val free = pool.filter { it.endsWith(":free") }
                free.filter { it.contains("llama") || it.contains("gemini") || it.contains("deepseek") || it.contains("qwen") } + free + pool
            }
            n.startsWith("Mistral") -> pool.filter { it.contains("small-latest") } + pool.filter { it.contains("medium-latest") } + pool
            n.startsWith("xAI") -> pool.filter { it.contains("mini") } + pool
            else -> pool
        }
        return ordered.distinct().take(4)
    }

    private fun fallbackModels(p: Prov): List<String> = when {
        p.name.startsWith("Perplexity") -> listOf("sonar")
        p.name.startsWith("Anthropic") -> listOf("claude-sonnet-5-5", "claude-haiku-5-5")
        p.name.startsWith("OpenAI") -> listOf("gpt-4o-mini")
        p.name.startsWith("DeepSeek") -> listOf("deepseek-flash", "deepseek-chat")
        p.name.startsWith("Google") -> listOf("gemini-2.5-flash")
        p.name.startsWith("Groq") -> listOf("llama-3.3-70b-versatile")
        p.name.startsWith("Mistral") -> listOf("mistral-small-latest")
        p.name.startsWith("xAI") -> listOf("grok-3-mini")
        else -> emptyList()
    }

    private fun parseChat(text: String): String {
        val msg = JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        return msg.optString("content", "")
    }

    /** Один запрос. Для OpenAI-совместимых сервисов сам подбирает параметр лимита ответа. */
    private fun chatOnce(p: Prov, key: String, model: String, system: String, messages: JSONArray, maxTok: Int): String {
        if (p.style == 1) {
            val body = JSONObject()
            body.put("model", model).put("max_tokens", maxTok).put("system", system).put("messages", messages)
            val (code, text) = http("POST", p.base + "/v1/messages", headers(p, key), body.toString())
            if (code !in 200..299) throw ApiErr(code, text)
            return JSONObject(text).getJSONArray("content").getJSONObject(0).optString("text", "")
        }
        val all = JSONArray()
        all.put(JSONObject().put("role", "system").put("content", system))
        for (i in 0 until messages.length()) all.put(messages.getJSONObject(i))
        val base = JSONObject()
        base.put("model", model).put("messages", all)
        var mode = 0
        for (attempt in 0..2) {
            val b = JSONObject(base.toString())
            if (mode == 0) b.put("max_tokens", maxTok)
            if (mode == 1) b.put("max_completion_tokens", maxTok)
            val (code, text) = http("POST", p.base + "/chat/completions", headers(p, key), b.toString())
            if (code in 200..299) return parseChat(text)
            val low = text.lowercase()
            val tokParam = low.contains("max_tokens") || low.contains("max_completion_tokens")
            if (code == 400 && mode < 2 && tokParam) {
                mode = if (mode == 0 && low.contains("max_completion_tokens")) 1 else 2
                continue
            }
            throw ApiErr(code, text)
        }
        throw ApiErr(400, "")
    }

    fun isMoney(e: ApiErr): Boolean {
        val low = e.body.lowercase()
        return e.code == 402 || low.contains("insufficient") || low.contains("quota") || low.contains("balance") ||
            low.contains("billing") || low.contains("credit") || low.contains("exceeded your current")
    }

    fun isRegion(e: ApiErr): Boolean {
        val low = e.body.lowercase()
        return low.contains("location is not supported") || low.contains("unsupported_country") ||
            low.contains("not available in your") || low.contains("not supported in your") ||
            low.contains("country, region") || (e.code == 403 && low.contains("region"))
    }

    fun human(e: ApiErr, name: String): String {
        return when {
            isRegion(e) -> name + " не работает в твоей стране: сервис закрыт для твоего региона. Ключ тут ни при чём. Попробуй другой сервис (OpenRouter, DeepSeek) или настрой ретранслятор."
            isMoney(e) -> "На аккаунте " + name + " нет денег или закончился лимит. Ключ рабочий, но сервис не даёт отвечать. Пополни баланс или возьми ключ другого сервиса."
            e.code == 401 || e.code == 403 -> "Ключ не подошёл к " + name + ". Проверь, что он скопирован полностью, без пробелов, и выдан именно этим сервисом. Если ключ точно верный, сервис может быть недоступен в твоей стране: тогда настрой ретранслятор или прокси ниже."
            e.code == 404 -> "Сервис " + name + " не нашёл модель или адрес. Нажми «Подключить» ещё раз."
            e.code == 429 -> "Слишком много запросов к " + name + ". Подожди минуту."
            e.code >= 500 -> name + " сейчас недоступен. Попробуй позже."
            else -> "Сервис " + name + " ответил ошибкой " + e.code + "."
        }
    }

    private fun netMsg(name: String): String =
        "Нет связи с " + name + ". Скорее всего, сервис недоступен в твоей стране или заблокирован у провайдера. Открой блок «Если ИИ не подключается» ниже: там можно указать свой ретранслятор или прокси."

    private fun system(c: Context): String {
        val tone = when (Prefs.i(c, "ai_tone")) {
            1 -> "Говори спокойно и мягко."
            2 -> "Говори по делу, без лишних слов."
            3 -> "Добавляй немного дружелюбного сарказма."
            else -> "Будь игривым, иногда мяукай."
        }
        return "Ты Кики, чёрный котик-ИИ-помощник, который живёт на экране телефона. Отвечай по-русски, коротко и по существу. " +
            tone + Control.prompt(c)
    }

    private fun saved(c: Context): Prov = Prov(Prefs.s(c, "ai_name"), emptyList(), Prefs.s(c, "ai_url"), Prefs.i(c, "ai_style"))

    /** Ответ ИИ. Блокирующий вызов, запускать не из главного потока. Ошибки приходят понятным текстом. */
    fun ask(c: Context, messages: JSONArray, maxTokens: Int = 0): String {
        if (!ready(c)) throw IllegalStateException("ИИ не подключён. Открой вкладку «ИИ» в приложении.")
        loadNet(c)
        val p = saved(c)
        val tok = if (maxTokens > 0) maxTokens else Prefs.i(c, "ai_len")
        try {
            val r = chatOnce(p, Prefs.s(c, "ai_key").trim(), Prefs.s(c, "ai_model"), system(c), messages, tok)
            if (r.isBlank()) throw IllegalStateException("Модель ответила пустотой. Попробуй ещё раз.")
            return r
        } catch (e: ApiErr) {
            throw IllegalStateException(human(e, p.name))
        } catch (e: IOException) {
            throw IllegalStateException(netMsg(p.name))
        }
    }

    fun summarize(c: Context, screenText: String): String {
        val m = JSONArray().put(JSONObject().put("role", "user").put("content",
            "Вот текст с экрана телефона. Опиши ОДНОЙ короткой строкой, чем занят пользователь или какая у него задача:\n" + screenText))
        return Control.parse(ask(c, m, 80)).first.replace('\n', ' ')
    }

    private fun save(c: Context, company: String, key: String, p: Prov, model: String) {
        Prefs.putS(c, "ai_company", company)
        Prefs.putS(c, "ai_key", key)
        Prefs.putS(c, "ai_url", p.base)
        Prefs.putS(c, "ai_model", model)
        Prefs.putS(c, "ai_name", p.name)
        Prefs.putI(c, "ai_style", p.style)
        Prefs.putB(c, "ai_ok", true)
    }

    fun disconnect(c: Context) {
        Prefs.putB(c, "ai_ok", false)
        Prefs.putS(c, "ai_key", "")
    }

    /** Проверка ретранслятора: обращается через него к ИИ-серверу без ключа. Ответ 401 значит, что связь работает. */
    fun testRelay(relayUrl: String): Pair<Boolean, String> {
        val r = relayUrl.trim()
        if (!r.startsWith("https://")) return Pair(false, "Адрес должен начинаться с https://")
        val oldRelay = relay
        val oldProxy = proxy
        relay = r
        proxy = null
        try {
            val (code, text) = http("GET", "https://api.openai.com/v1/models", HashMap<String, String>(), null)
            val low = text.lowercase()
            return when {
                code == 401 -> Pair(true, "Ретранслятор работает: запрос дошёл до сервиса ИИ.")
                low.contains("unsupported_country") || low.contains("region") ->
                    Pair(true, "Ретранслятор работает, но этот сервис закрыт для места, откуда он выходит. Другие сервисы (DeepSeek, OpenRouter, Mistral) могут открыться.")
                code == 403 && low.contains("не разрешён") -> Pair(false, "Ретранслятор запущен, но код вставлен не целиком. Вставь код заново и нажми Deploy.")
                code == 404 || code == 400 -> Pair(false, "Адрес похож на неверный. Проверь, что скопирован адрес воркера целиком (…workers.dev).")
                code in 500..599 -> Pair(false, "Ретранслятор ответил ошибкой " + code + ". Открой воркер в Cloudflare и проверь, что нажато Deploy.")
                else -> Pair(true, "Ретранслятор ответил (" + code + "). Попробуй подключить ИИ.")
            }
        } catch (e: IOException) {
            val why = if (e is java.net.UnknownHostException) "адрес не находится (провайдер может блокировать workers.dev или адрес с ошибкой)"
            else if (e is java.net.SocketTimeoutException) "нет ответа (возможно, адрес заблокирован провайдером)"
            else e.javaClass.simpleName
            return Pair(false, "Не достучался до ретранслятора: " + why + ". Открой адрес воркера в браузере телефона: если страница не открывается, этот способ у тебя не заработает.")
        } catch (e: Exception) {
            return Pair(false, "Не получилось проверить: " + (e.message ?: "неизвестная ошибка"))
        } finally {
            relay = oldRelay
            proxy = oldProxy
        }
    }

    /**
     * Подключение: проверяет ключ, выбирает модель, делает пробный запрос.
     * Если ключ принят и модель найдена, подключает, даже когда пробный ответ не получен.
     * В details по шагам видно, что сработало, а что нет; kind подсказывает, что делать дальше. Запускать не из главного потока.
     */
    fun connect(c: Context, company: String, keyRaw: String): AiResult {
        loadNet(c)
        val key = keyRaw.trim()
        if (key.isEmpty()) return AiResult(false, false, "Вставь ключ.", "", "key")
        val cands = resolve(company, key)
        if (cands.isEmpty()) {
            return AiResult(false, false, "Не понял, какой это сервис. Нажми на название выше или впиши адрес API.", "", "other")
        }
        val log = StringBuilder()
        if (relay.isNotEmpty()) log.append("Через ретранслятор\n")
        if (proxy != null) log.append("Через прокси\n")
        var lastMsg = ""
        var lastKind = "other"
        var keyWorked = false
        val ping = JSONArray().put(JSONObject().put("role", "user").put("content", "Привет"))
        for (p in cands) {
            log.append("Сервис: ").append(p.name).append('\n')
            try {
                var ids: List<String> = emptyList()
                try {
                    ids = listModels(p, key)
                    log.append("✓ ключ принят, моделей: ").append(ids.size).append('\n')
                } catch (e: ApiErr) {
                    if (e.code == 401 || e.code == 403 || isRegion(e)) throw e
                    log.append("· список моделей недоступен (").append(e.code).append(")\n")
                }
                val models = if (ids.isEmpty()) fallbackModels(p) else pickModels(p, ids)
                if (models.isEmpty()) {
                    lastMsg = "Не удалось определить модель у " + p.name + "."
                    lastKind = "other"
                    log.append("✕ модель не найдена\n")
                    continue
                }
                var lastErr: ApiErr? = null
                for (m in models) {
                    try {
                        chatOnce(p, key, m, "Ответь одним словом.", ping, 32)
                        log.append("✓ пробный ответ получен: ").append(m)
                        save(c, company, key, p, m)
                        return AiResult(true, true, "Подключено: " + p.name + " · " + m, log.toString(), "ok")
                    } catch (e: ApiErr) {
                        lastErr = e
                        log.append("✕ ").append(m).append(": ошибка ").append(e.code).append('\n')
                        if (e.code == 401 || e.code == 403 || isMoney(e) || isRegion(e)) throw e
                    }
                }
                if (ids.isNotEmpty()) {
                    save(c, company, key, p, models[0])
                    return AiResult(true, true, "Подключено: " + p.name + " · " + models[0] + ". Пробный ответ не получен, проверь в чате.", log.toString(), "ok")
                }
                if (lastErr != null) throw lastErr
            } catch (e: ApiErr) {
                lastMsg = human(e, p.name)
                lastKind = when {
                    isRegion(e) -> "region"
                    isMoney(e) -> "money"
                    e.code == 401 || e.code == 403 -> "key"
                    else -> "other"
                }
                if (lastKind != "key" && lastKind != "region") keyWorked = true
                if (lastKind == "money") break
            } catch (e: IOException) {
                lastMsg = netMsg(p.name)
                lastKind = "net"
                log.append("✕ нет связи с сервисом\n")
            } catch (e: Exception) {
                lastMsg = "Не получилось: " + (e.message ?: "неизвестная ошибка")
                lastKind = "other"
            }
        }
        return AiResult(false, keyWorked, if (lastMsg.isEmpty()) "Не получилось подключиться." else lastMsg, log.toString().trim(), lastKind)
    }
}
