package com.example.catpet

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Подключение к ИИ: Anthropic или любой OpenAI-совместимый сервис. */
object Ai {
    fun ready(c: Context): Boolean = Prefs.i(c, "ai_provider") != 0 && Prefs.s(c, "ai_key").isNotBlank()

    private fun system(c: Context): String {
        val tone = when (Prefs.i(c, "ai_tone")) {
            1 -> "Говори спокойно и мягко."
            2 -> "Говори по делу, без лишних слов."
            3 -> "Добавляй немного дружелюбного сарказма."
            else -> "Будь игривым, иногда мяукай."
        }
        return "Ты Кики, чёрный котик-ИИ-помощник, который живёт на экране телефона. Отвечай по-русски, коротко и по существу. " + tone
    }

    /** Одна короткая строка о том, что делает пользователь. Вызывать не из главного потока. */
    fun summarize(c: Context, screenText: String): String {
        val m = JSONArray().put(JSONObject().put("role", "user").put("content",
            "Вот текст с экрана телефона. Опиши ОДНОЙ короткой строкой, чем занят пользователь или какая у него задача:\n" + screenText))
        return ask(c, m, 80).replace('\n', ' ')
    }

    /** Блокирующий запрос. messages: массив {role, content}. Вызывать не из главного потока. */
    fun ask(c: Context, messages: JSONArray, maxTokens: Int = 0): String {
        val provider = Prefs.i(c, "ai_provider")
        val key = Prefs.s(c, "ai_key").trim()
        if (provider == 0 || key.isEmpty()) throw IllegalStateException("Ключ не задан")
        var base = Prefs.s(c, "ai_url").trim().trimEnd('/')
        var model = Prefs.s(c, "ai_model").trim()
        val maxTok = if (maxTokens > 0) maxTokens else Prefs.i(c, "ai_len")
        val url: String
        val body = JSONObject()
        if (provider == 1) {
            if (base.isEmpty()) base = "https://api.anthropic.com"
            if (model.isEmpty()) model = "claude-sonnet-5-5"
            url = base + "/v1/messages"
            body.put("model", model).put("max_tokens", maxTok).put("system", system(c)).put("messages", messages)
        } else {
            if (base.isEmpty()) base = "https://api.openai.com/v1"
            if (model.isEmpty()) throw IllegalStateException("Укажи модель в настройках ИИ")
            url = base + "/chat/completions"
            val all = JSONArray().put(JSONObject().put("role", "system").put("content", system(c)))
            for (i in 0 until messages.length()) all.put(messages.getJSONObject(i))
            body.put("model", model).put("max_tokens", maxTok).put("messages", all)
        }
        if (!url.startsWith("https://")) throw IllegalStateException("Адрес должен начинаться с https://")

        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.doOutput = true
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.setRequestProperty("content-type", "application/json")
        if (provider == 1) {
            conn.setRequestProperty("x-api-key", key)
            conn.setRequestProperty("anthropic-version", "2023-06-01")
        } else {
            conn.setRequestProperty("Authorization", "Bearer " + key)
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = conn.responseCode in 200..299
        val resp = (if (ok) conn.inputStream else conn.errorStream)?.bufferedReader()?.readText() ?: ""
        if (!ok) throw RuntimeException("сервис ответил " + conn.responseCode + ": " + resp.take(160))
        val json = JSONObject(resp)
        return if (provider == 1) {
            json.getJSONArray("content").getJSONObject(0).getString("text")
        } else {
            json.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
        }
    }
}
