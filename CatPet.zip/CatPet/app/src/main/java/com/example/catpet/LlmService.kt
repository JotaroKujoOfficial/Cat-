package com.example.catpet

import android.app.Service
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import com.google.mediapipe.tasks.genai.llminference.LlmInference

/** Нейросеть на телефоне. Работает в отдельном процессе (:llm): если ей не хватит памяти, падает она, а не Кики. */
class LlmService : Service() {
    private var llm: LlmInference? = null
    private var loadedPath = ""
    private var loadedCtx = 0
    private val worker = HandlerThread("kiki-llm")
    private lateinit var work: Handler
    private lateinit var messenger: Messenger

    override fun onCreate() {
        super.onCreate()
        worker.start()
        work = Handler(worker.looper)
        messenger = Messenger(Handler(Looper.getMainLooper()) { msg ->
            if (msg.what == 1) {
                val data = msg.data
                val reply = msg.replyTo
                work.post { handle(data, reply) }
            }
            true
        })
    }

    override fun onBind(i: Intent?): IBinder? = messenger.binder

    private fun handle(d: Bundle, reply: Messenger?) {
        val out = Bundle()
        try {
            val path = d.getString("path") ?: ""
            val ctx = d.getInt("ctx", 1280)
            if (llm == null || path != loadedPath || ctx != loadedCtx) {
                llm?.close()
                llm = null
                val opts = LlmInference.LlmInferenceOptions.builder().setModelPath(path).setMaxTokens(ctx)
                    .setPreferredBackend(LlmInference.Backend.CPU).build()
                llm = LlmInference.createFromOptions(this, opts)
                loadedPath = path
                loadedCtx = ctx
            }
            out.putString("text", llm!!.generateResponse(d.getString("prompt") ?: ""))
        } catch (t: Throwable) {
            out.putString("error", t.javaClass.simpleName + ": " + (t.message ?: ""))
        }
        try {
            val m = Message.obtain(null, 2)
            m.data = out
            reply?.send(m)
        } catch (_: Throwable) {}
    }

    override fun onDestroy() {
        try { llm?.close() } catch (_: Throwable) {}
        worker.quitSafely()
        super.onDestroy()
    }
}
