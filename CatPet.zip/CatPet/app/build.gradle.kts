plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.catpet"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.catpet"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    signingConfigs {
        create("kiki") {
            storeFile = file("kiki-debug.keystore")
            storePassword = "kikikiki"
            keyAlias = "kiki"
            keyPassword = "kikikiki"
        }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("kiki") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
}
