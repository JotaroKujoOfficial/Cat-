# Кики (Android, Kotlin), версия 2.3

Сборка без Android Studio: загрузи CatPet.zip в репозиторий GitHub, добавь файл .github/workflows/build.yml.
Готовый APK появится в разделе Releases.

Подпись сборок теперь одинаковая (файл app/kiki-debug.keystore), поэтому новые версии ставятся поверх старых
и разрешения не сбрасываются. Первый раз после этой версии старое приложение нужно удалить.
Для публикации в Google Play понадобится отдельный ключ загрузки.

Название для Google Play: «Кики: ИИ-помощник на экране».
Шрифты: Tektur, Inter, Geist Mono (SIL Open Font License). Ретранслятор для ИИ: папка relay.
