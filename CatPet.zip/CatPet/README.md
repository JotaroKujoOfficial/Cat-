# Кики (Android, Kotlin), версия 2.2

Сборка без Android Studio: загрузи CatPet.zip в репозиторий GitHub, добавь файл .github/workflows/build.yml.
Готовый APK появится в разделе Releases.

Название для Google Play: «Кики: ИИ-помощник на экране».
Шрифты: Inter, Inter Display, Geist Mono (SIL Open Font License).
Ретранслятор для ИИ: папка relay.
