# Кики (Android, Kotlin), версия 2.1

Сборка без Android Studio: загрузи CatPet.zip в репозиторий GitHub, добавь файл .github/workflows/build.yml.
Готовый APK появится в разделе Releases.

Название для Google Play: «Кики: ИИ-помощник на экране».
Шрифты: Inter и JetBrains Mono (SIL Open Font License).
